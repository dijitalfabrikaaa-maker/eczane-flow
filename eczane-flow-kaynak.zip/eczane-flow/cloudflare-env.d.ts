/** Minimal runtime binding contracts used by this application. */
interface Fetcher {
 fetch(input: Request | string | URL, init?: RequestInit): Promise<Response>;
}
interface D1Result<T = Record<string, unknown>> {
 success: boolean;
 results: T[];
 meta: { changes: number; last_row_id: number; duration: number; rows_read: number; rows_written: number; size_after: number; changed_db: boolean };
}
interface D1PreparedStatement {
 bind(...values: unknown[]): D1PreparedStatement;
 first<T = Record<string, unknown>>(column?: string): Promise<T | null>;
 all<T = Record<string, unknown>>(): Promise<D1Result<T>>;
 run<T = Record<string, unknown>>(): Promise<D1Result<T>>;
 raw<T = unknown[]>(): Promise<T[]>;
}
interface D1Database {
 prepare(query: string): D1PreparedStatement;
 batch<T = Record<string, unknown>>(statements: D1PreparedStatement[]): Promise<D1Result<T>[]>;
 exec(query: string): Promise<{count: number; duration: number}>;
}
interface PharmacyImageBucket {
 delete(key:string):Promise<void>;
 put(key:string,value:Uint8Array,options:{httpMetadata:{contentType:string}}):Promise<unknown>;
 get(key:string):Promise<{body:ReadableStream<Uint8Array>;httpMetadata?:{contentType?:string}}|null>;
}
declare module 'cloudflare:workers'  {
 export const env: {DB: D1Database; ASSETS: Fetcher; BUCKET: PharmacyImageBucket};
}
