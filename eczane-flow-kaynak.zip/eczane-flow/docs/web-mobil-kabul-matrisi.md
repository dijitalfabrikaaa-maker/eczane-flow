# Eczane Flow — web ve mobil kabul matrisi

9 Eylül 2026. Bu belge test planıdır; aşağıdaki gerçek oturum/cihaz testleri henüz yürütülmedi. Kullanıcı üretim verisine geçmeden kendi test kayıtlarıyla sınayacak. Mevcut site erişimi değiştirilmedi. İkinci kişinin siteye erişimi ve firma üyeliği sağlandığında iki ayrı oturum kullanılmalı; sahte kimlik başlıkları gerçek kabul yerine geçmez.

| Adım | İşlem | Beklenen sonuç | Durum |
| --- | --- | --- | --- |
| 1 | iPhone/Android: QR, DataMatrix ve çizgili barkod; dikey/yatay | Kamera ekranı kaplar, sonuç alanları görünür, doğru biçim ayrıştırılır | Cihaz kabulü açık |
| 2 | USB/Bluetooth: Enter ve Tab, GS ayırıcı | Cihaz kontrolü ham/veri alanlarını gösterir, test stok değiştirmez | Okuyucu kabulü açık |
| 3 | Bilinmeyen ürün okut, kart aç, kabulü beklet | GTIN/lot/seri/miat korunur; kart aşamasında stok artmaz | Mobil/web kabulü açık |
| 4 | Aynı seriyi iki kez okut | İkinci kutu eklenmez; miktar bir kalır | Mobil/web kabulü açık |
| 5 | Bilinen seriye farklı lot/miat okut | Karşılaştırma açılır; eski kayıt değişmez | Mobil/web kabulü açık |
| 6 | Serili sayımda eksik ve fazla bırak, onayla | Fark ve seri kanıtı kaydedilir; yetki/onay uygulanır | Mobil/web kabulü açık |
| 7 | İki raftaki ürünü belirli raftan sat/iade et | Sadece seçilen raf azalır, hareket/para bir kez kaydolur | Mobil/web kabulü açık |
| 8 | Karantina, geri çağırma, miadı dolmuş lotla satış dene | Satış engellenir; gerekçeli hasar/kayıp ayrı işlem olur | Mobil/web kabulü açık |
| 9 | Siparişin kısmi tesliminde fiyatı değiştir | Fark görülür, onaysız kayıt reddedilir, fazla adet kabul edilmez | Mobil/web kabulü açık |
| 10 | Şube transferinde eksik/hasarlı/fazla kaydı | Teslim edilen miktar ve fark kapanır; fazla kayıt stok üretmez | İki şube kabulü açık |
| 11 | Aynı kullanıcının iki cihazında aynı taslağı değiştir | Eski sürüm üzerine yazmaz; iki sürüm karşılaştırılır | İki cihaz kabulü açık |
| 12 | Yöneticinin ikinci kullanıcıya yetki vermesi/kaldırması | İzin değişimi yeni istekte uygulanır, eski ekranla yazma engellenir | Gerçek iki kullanıcı açık |
| 13 | İkinci kullanıcıya sadece bir şube aç | Diğer şubenin verisi/işlemi erişilemez | Gerçek iki kullanıcı açık |
| 14 | Son kutuyu iki oturumda aynı anda sat | Tek satış kaydolur; diğeri güncel stokla yeniden kontrol ister | Gerçek iki kullanıcı açık |
| 15 | İki yetkili aynı onay isteğini sonuçlandırsın | Stok/para bir kez değişir; onaylayan kaydedilir | Gerçek iki kullanıcı açık |
| 16 | Görev ata; vadesini bekle; oku/tamamla | Yetkili kişi görür, okunmamış sayı düşer; tamamlanan görev uyarıdan kalkar | Gerçek oturum açık |
| 17 | Kısmi satış/iade/tahsilat, POS/banka dönemini karşılaştır | Borç, geri ödeme ve mutabakat aynı belge zincirindedir | Mobil/web kabulü açık |
| 18 | Yedek oluştur, sınama düğmesini çalıştır | Bütünlük sonucu görünür; sınama canlı veriyi değiştirmez | Barındırılan ortam açık |
| 19 | Yedekten dönüşü ayrılmış test firmasında dene | Seçilen kayıtlar döner, önceki durum yedeklenir, tekrar istek çift yazmaz | Barındırılan ortam açık |
| 20 | Büyük katalogda arama, okutma, liste ve kayıt sürelerini ölç | Cihaz/ağ/kayıt sayısı ve gecikme raporlanır; kapasite varsayılmaz | Canlı kapasite açık |

## Otomatik kontrol kanıtı

90 test geçti. Yerel SQLite testleri firma, çalışan, şube/taslak sürümü, kaldırılan üyelik ve eski revizyon korumalarını sınar. Saf işlem testleri stok/para tutarlılığı, onay, seriler, raflar, transfer farkları ve yedek dönüşünü sınar. Bunlar yukarıdaki gerçek oturum ve kamera kabulünün yerine geçmez.

## Dış hizmet koşulları

Push/e-posta için sağlayıcı, sunucu zamanlayıcı ve alıcı aboneliği henüz bağlanmadı. Mevcut görevler uygulama içindedir. Resmî İTS/MEDULA/e-fatura ve AI sağlayıcı erişimi bu 30 maddelik okutma paketinde aktive edilmiş sayılmaz.
