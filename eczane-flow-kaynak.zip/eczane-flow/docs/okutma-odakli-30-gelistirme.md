# Eczane Flow — Okutma odaklı 30 geliştirme

9 Eylül 2026. Mevcut uygulama geliştirilir; çalışan süreçler sıfırdan yapılmaz.
Bu liste, kodda görülen eksikleri ve mevcut akışları sağlamlaştıracak işleri içerir. Her satır mevcut özelliğin tamamen bozuk olduğu anlamına gelmez.

Öncelik: okut → içeriği anla → doğru ürün/lot/seri → doğru işlem → kalıcı kayıt.
1–26 ve 28 için uygulama mevcut. 27 için görev/öncelik/uygulama içi zamanlama eklendi; dış kanal bağlı değil. 29 için otomatik yetki/yarış kontrolleri ve gerçek kullanıcı kabul matrisi hazır; iki gerçek oturumla kabul yapılmadı. 30 için bütünlük, yedek sınama ve yerel hacim kontrolü eklendi; barındırılan ortam kapasitesi ölçülmedi. Fiziksel cihaz kabulü ayrıca yürütülür.

| Sıra | Geliştirme | Kabul ölçütü | Bu tur |
| --- | --- | --- | --- |
| 1 | Okunan kod için GTIN, seri, lot ve miat kontrol ekranı | Kullanıcı ham, anlaşılmaz metin yerine alanları görür; devam demeden işlem ekranına geçilmez. | Uygulandı |
| 2 | Otomatik / ilaç karekodu / çizgili barkod / QR tarama türleri | Seçim çözümleyicinin aradığı formatları gerçekten değiştirir. | Uygulandı |
| 3 | İlgisiz QR ve bozuk içerik kontrolü | Web/Wi-Fi/vCard kodu ürüne dönüşmez, bağlantı açılmaz; kamera açık kalır. | Uygulandı ve test edildi |
| 4 | Okuyucu önekleri ve GS1 ayırıcı uyumluluğu | Desteklenen AIM önekleri ve açık GS gösterimleri aynı alanlara çözülür; eksik ayırıcı tahmin edilmez. | Uygulandı ve test edildi |
| 5 | Döndürülmüş ve uzaktan çekilmiş kodlarda ek çözümleme | Canlı görüntüde sınırlı sıklıkla döndürme/merkez bölge; fotoğrafta dört açı ve tam/merkez görüntü denenir. | Uygulandı; telefon kabulü açık |
| 6 | Kameradan fotoğraf ve galeriden seçim ayrımı | İki ayrı düğme; fotoğraf seçiciden dönüşte kod kaybolmaz. | Uygulandı; cihaz kabulü açık |
| 7 | Donanım destekliyorsa flaş | Destek sunmayan cihazda kontrol gösterilmez; başarısız açma taramayı bozmaz. | Uygulandı; donanım kabulü açık |
| 8 | Arka plana geçiş ve kamera oturumu yönetimi | Gizlenen sayfada kamera durur; eski oturumdan sonuç kabul edilmez; kullanıcı devam edebilir. | Uygulandı; cihaz kabulü açık |
| 9 | Tam ekran tarama ve sonuç ekranının ortak mobil yerleşimi | Alt navigasyonun üzerinde, okunur alanlar ve yatay/dikey düzen; tarama türü menüsü kamera arkasında kalmaz. | Uygulandı; görsel/cihaz kabulü açık |
| 10 | Tekrarlanabilir optik ve veri çözümleme testleri | QR/DataMatrix gerçek piksel matrisleri dört yönde çözülür; hatalı ve ilgisiz payload reddedilir. | Otomatik testler geçti; gerçek ilaç örnekleri açık |
| 11 | Kamera kapanmadan seri mal kabulü / satış okutma | Her kabul edilen kutu görünür listeye eklenir; sonlandırmada özet alınır. | Uygulandı; fiziksel kamera kabulü açık |
| 12 | Seri okutma için görünür çift okutma uyarısı ve sayaç | Aynı serili kutu engellenir; seri içermeyen üründe miktar artırma ayrı ve anlaşılırdır. | Uygulandı; fiziksel kamera kabulü açık |
| 13 | Kamera/lens seçimi, yakınlaştırma ve odak yardımı | Cihazın bildirdiği yeteneklere göre çalışır; desteklenmeyen kontrol gösterilmez. | Uygulandı; gerçek cihaz kabulü açık |
| 14 | Fotoğrafta kullanıcı tarafından kod bölgesi seçimi | Birden fazla kod veya küçük kod içeren fotoğrafta hedef bölge belirlenir. | Uygulandı; gerçek cihaz kabulü açık |
| 15 | USB/Bluetooth okuyucu kurulum ve sınama ekranı | Enter/Tab bitişi, klavye düzeni ve FNC1 aktarımı test edilir; stok değişmez. | Uygulandı; fiziksel okuyucu kabulü açık |
| 16 | GTIN kontrol basamağı ve eski katalog uyumluluğu | Yanlış kod uyarılır; mevcut iç ürün kodları kontrolsüz bozulmaz. | Uygulandı; fiziksel okuyucu kabulü açık |
| 17 | GS1 Digital Link içeren ürün QR desteği | Standart veri alanları ayrıştırılır; rastgele URL çalıştırılmaz veya ürün sayılmaz. | Uygulandı; fiziksel okuyucu kabulü açık |
| 18 | Bilinmeyen üründe okutulan bilgilerle kontrollü kart oluşturma | Barkod, lot, seri, miat formda korunur; kart oluşturmak tek başına stok eklemez. | Mevcut kontrollü kart ve taslak akışı doğrulandı; kart tek başına stok eklemez |
| 19 | Lot/seri/miat uyuşmazlığını açıklayan çözüm ekranı | Genel hata yerine karşılaştırma ve düzeltilecek alan gösterilir. | Uygulandı; lot/miat karşılaştırması ve yeniden okutma |
| 20 | Serili kutuları tek tek okutarak stok sayımı | Beklenen/okunan/eksik/fazla seriler karşılaştırılır; yetkili onayla sonuçlanır. | Uygulandı ve otomatik test edildi; seri farkları ve geri alma kaydı |
| 21 | Çıkışta gerçek raf seçimi | Kutu hangi raftan çıktıysa o raf azalır; otomatik tahsis azaltımına bağımlılık kalkar. | Uygulandı ve otomatik test edildi; satış, çıkış, transfer ve tedarikçi iadesi |
| 22 | Miadı dolmuş, geri çağrılmış ve karantinadaki ürün ayrımı | Kullanılabilir stoktan ayrılır; gerekçe, sorumlu ve geri alma kaydı tutulur. | Uygulandı ve otomatik test edildi; satış blokesi, gerekçe ve sorumlu kaydı |
| 23 | Hasar/kayıp/numune gibi stok çıkış nedenleri | Satıştan ayrılır; gerekli onay ve rapor sınıflaması uygulanır. | Uygulandı ve otomatik test edildi; hareket filtresi ve CSV alanları |
| 24 | Şube transferinde eksik/fazla/hasarlı teslim | Yoldaki miktar, teslim farkı ve kapatma onayı mutabık kalır. | Uygulandı ve otomatik test edildi; fark kaydı stok oluşturmaz |
| 25 | Sipariş–teslimat–fatura fark karşılaştırması | Miktar ve fiyat farkları görünür; fazla teslim sessizce kabul edilmez. | Uygulandı ve otomatik test edildi; fiyat farkı onayı ve miktar sınırı |
| 26 | Çevrimdışı taslak çatışmasını karşılaştırarak kurtarma | İki cihazdaki satırlar gösterilir; eski taslak sessizce üzerine yazılmaz. | Uygulandı; cihaz/sunucu karşılaştırması, sürüm koruması; iki cihaz kabulü açık |
| 27 | Bildirim önceliği, görev sahibi ve zamanlanmış gönderim | Hangi kişiye, ne zaman, hangi kanaldan gönderildiği izlenir; dış kanal erişimi gerekir. | Kısmen: görev, sahibi, öncelik, uygulama içi hatırlatma; dış gönderim bağlı değil |
| 28 | İade, tahsilat ve kasa/banka mutabakat ekranı | Belge bazındaki borç ve para hareketleri birlikte kontrol edilir. | Uygulandı ve otomatik test edildi; belge bakiyeleri ve dönem mutabakatı |
| 29 | Gerçek iki kullanıcıyla şube ve yetki kabul matrisi | Yetki kaldırma, eşzamanlı satış ve onay yarışları gerçek oturumlarla sınanır. | Otomatik DB/yetki/çakışma testleri geçti; gerçek iki kullanıcı kabulü açık |
| 30 | Hacim, yedekten dönüş ve yayın sonrası hata izleme | Ölçülen kapasite, geri yükleme kanıtı ve hata takibi kaydedilir; sınırsız ölçek varsayılmaz. | Bütünlük ve yedek sınama eklendi; yerel hacim testi geçti; canlı kapasite kabulü açık |

## İlk uygulama diliminin sınırları

- Optik testlerde sentetik, kontrollü QR ve DataMatrix görüntüleri kullanıldı; ambalaj parlaması, telefon odak mesafesi ve fiziksel barkod kalitesi doğrulanmadı.
- Kodun çözülmesi ürünün resmî kaynaktan doğrulandığı anlamına gelmez. Mevcut katalog ve sunucudaki lot/seri/izin kontrolleri son aşamada uygulanır.
- Okutma kontrol ekranı stok veya para kaydı yapmaz. Mevcut işlemin kaydı ayrıca onaylanır.
- Arka plan push, resmî İTS/MEDULA/e-fatura ve gerçek AI aktivasyonu önceki plandaki sağlayıcı koşullarını korur.
- Tarama türleri, kameraya yeni izin verme zorunluluğunu ortadan kaldırdığını iddia etmez; izin kalıcılığı tarayıcı/cihaz ayarına bağlıdır.

## Teknik dayanak

- GS1 alan tanımları: https://ref.gs1.org/ai/
- Mevcut tarayıcı kitaplığının kaynak/API açıklaması: https://github.com/zxing-js/browser
- Testler: tests/scan-result.test.mjs. DataMatrix test şekilleri tam modül boyunda büyütülür ve etrafında beyaz boşluk korunur.

## Seri okutma dilimi

11–12: Mal kabulü, stok çıkışı ve hızlı satışta seri okutma seçeneği eklendi. Kamera açık kalır; kabul edilen kutu işlem taslağına eklenir. Son üç kayıt ve oturum sayacı gösterilir. Serisiz kodlarda her kutu için açık ekleme gerekir. Raf kodları bu modda işlenmez. Bilinmeyen veya lot/miadı eksik mal kabulü tekli işleme yönlendirilir. Stok ve tahsilat son onaya kadar değişmez. Oturum başına 200 kutu sınırı vardır. Gerçek cihaz kabulü açık.

13–14: İzin sonrası cihazın bildirdiği kameralar seçilebilir. Donanım destekliyorsa yakınlaştırma ve sürekli odak kontrolü sunulur. Fotoğrafın kod bölgesi dört erişilebilir sürgüyle seçilir; seçilen alan yerel olarak çözülür. Fotoğraf seçimi seri moddan tekli doğrulamaya geçer; mevcut taslak korunur. Fiziksel telefon ve görsel kabul açık.

15–17: Cihaz kontrolünde klavye modunda USB/Bluetooth test alanı, Enter/Tab, ham metin ve GS görünümü eklendi. GTIN kontrol basamağı doğrulanır; eski sayısal iç kodlar korunur, tekli kamera uyarısı ve seri modda durdurma vardır. Digital Link desteği sıkıştırılmamış /01/GTIN, isteğe bağlı /10/lot, /21/seri ve ?17=miat alt kümesini kapsar. Ek sayısal alanlar ve sıkıştırılmış URI henüz desteklenmez. URL açılmaz veya sorgulanmaz. Kontrol basamağının geçmesi ürünün resmî kaynaktan doğrulandığı anlamına gelmez.
Kaynak: https://ref.gs1.org/standards/digital-link/uri-syntax/

## Son uygulama paketi: 18–30

- Kontrol sonucu: 90 otomatik test, TypeScript kontrolü ve üretim derlemesi geçti. Yayın sonucu Sites üzerinden ayrıca doğrulanır.
- Yeni testler: `tests/stock-controls.test.mjs`, `tests/capacity-restore.test.mjs`.
- Sayım seri listelerini, eksik/fazla farkını ve önceki serileri saklar. Yetki ve onay politikası mevcut sunucu akışında uygulanır.
- Raf seçimi olmadan ayrılmış stoktan çıkış reddedilir; seçilen raf azalır. Satış iadesi yeniden yerleştirilene kadar tahsis edilmemiş stoktur. Sayım sonrası fiziksel raf kontrolü gereklidir.
- Karantina/geri çağırma satış ve normal çıkışı durdurur. Hasar/kayıp çıkışı gerekçe ile ayrı kaydedilir. Kullanılabilir stok önerileri bloke lotları içermez.
- Transfer farkları yetkili tarafından kaydedilir. Eksik/hasarlı miktar kullanılabilir stoğa eklenmez. Fazla teslim ayrıca sevk/iade gerektirir; fark kaydı yeni stok üretmez.
- Taslak çatışması otomatik kaydı durdurur. Kullanıcı cihazdaki ve sunucudaki sürümü karşılaştırıp birini seçer; birleştirme kendiliğinden yapılmaz.
- Görevler yönetim/firma bölümündedir. Görev sahibine ve yetkili yöneticiye uygulama içinde görünür; açık, görünür uygulamada boşta 60 saniyede güncellenir. Push/e-posta gönderim altyapısı kurulmadığından kapalı uygulamaya gönderildiği iddia edilmez.
- Cihaz kontrolünde veri bütünlüğü; yedekler bölümünde canlı veriyi değiştirmeyen yedek sınaması vardır. Bozuk miktar/seri/raf ilişkili yedeğin geri yüklenmesi reddedilir.
- Yerel ölçüm: 500 ürün, 1.000 lot, 5.000 hareket, 903.618 bayt; tekil çalışmada bütünlük 11 ms, geri yükleme 24 ms, çıkış 44 ms. Eşzamanlı test paketi altında 29/45/78 ms. Bu ölçüm D1/R2, ağ ve gerçek eşzamanlı kullanıcı kapasitesini kanıtlamaz.
- Yayın öncesi son 60 dakika sunucu hata sorgusunda olay dönmedi; bu, hiç hata oluşmayacağı anlamına gelmez.

Gerçek kullanıcı kabul adımları: `docs/web-mobil-kabul-matrisi.md`. Tüm satırlar geliştirme açısından ele alındı; sağlayıcı ve gerçek oturum gerektiren kabul adımları nedeniyle **30/30 kabul tamamlandı** olarak işaretlenmedi.
