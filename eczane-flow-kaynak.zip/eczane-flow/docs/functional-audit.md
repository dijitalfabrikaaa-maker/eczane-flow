# İşlev incelemesi — 9 Eylül 2026

İnceleme kaynak kod, işlem kuralları, 36 otomatik test ve üretim hata kayıtları üzerinden yapıldı. Son 120 dakikalık hata sorgusu boş döndü; bu, fotoğraf yüklemenin çalıştığını kanıtlamaz. Tarayıcı eczane rotasına erişimi önceki denemede ortam politikasıyla engellendi. Gerçek iPhone/PWA kamera, klavye ve fotoğraf testi tamamlanmış değildir.

## Bu güncellemede yapılanlar

| Konu | Bulgular ve değişiklik |
|---|---|
| Bildirim sayacı | Sayaç tüm aktif stok koşullarını sayıyordu. Okunmuş anahtarlar hesaba kaydediliyor. Panel açılınca okundu işaretleniyor, stok koşulları listede kalıyor. Stok miktarı/minimum değişimi ve miadın dolması yeni uyarı oluşturur. |
| Fotoğraflar | WebP canvas çıktısına zorunluluk kaldırıldı; JPEG işleme ve sunucu kabulü eklendi. Depolanan MIME türü görüntü yanıtında kullanılıyor. Dosya seçicinin dokunma alanı düzeltildi. iPhone'da yeniden doğrulanmalı; HEIC çözümü tarayıcı desteğine bağlı. |
| Serili çıkış | Kayıtlı seri, girişte mükerrer sayılmalı fakat çıkışta seçilebilmeliydi. Yalnızca okutulan seri çıkarılır; tekrar işlem stoktan ikinci kez düşmez. Seri okutulmadan seri stok tüketilemez. |
| Lotsuz barkod | Çıkışta önce uygun ve miadı yakın stok seçilir; seri olmayan satırlarda lot seçimi açılır. EAN ve sıfır dolgulu GTIN eşleştirilir. |
| Tedarikçi | Mal kabul satırında kayıtlı tedarikçi seçilir. İşlem geçmişine o andaki tedarikçi adı yazılır. Eski notlardan otomatik şirket tahmin edilmez. |
| Maliyet ve satış | Ürün kartında son birim alış maliyeti ve satış fiyatı düzenlenir. Kabulde maliyet, çıkışta satış seçimi ve fiyat girilir. Tutarlar kuruş/qəpik tamsayısıdır. Geçmiş tutarlar değişmez. Vergi, tahsilat veya mali belge oluşturulmaz. |
| Raporlar | Dönem satış toplamı, maliyeti girilmiş alış toplamı, maliyeti eksik alış satırı gösterilir. CSV hareketleri tedarikçi/fiyat/para birimi/seri içerir. Eksik maliyet sıfır maliyet veya hesaplanmış kâr olarak sunulmaz. |
| Ana ekran | Grafik onaylanmış kutuları hesaplıyor; kart açmak stok yaratmıyor. Yeni kart artık kabul taslağına eklenir; lot, miat ve miktar doğrulanıp onaylanınca grafik güncellenir. |
| Dışa aktarma | Stok CSV ve PDF eylemleri aynı araç alanında. Stok CSV görünür ürün filtresine uyar. |

Mobil alt bardaki Okut düğmesi, boş stok çıkışı/sayım ekranında mal kabule yönlendiriyordu. Mevcut işlem türünü koruyacak şekilde düzeltildi.

## Doğrulama

36 test geçti: stok değişimi, yetersiz stok, işlem atomikliği, mükerrer işlem, seri bazlı çıkış, tarih filtreleri, CSV/XLSX, taslak, fiyat/supplier doğrulaması, geçmiş maliyetin korunması, bildirim okundu kayıtları. TypeScript ve üretim derlemesi ayrıca kontrol edilir. Fiziksel kamera/yazıcı testleri bu kapsamda değildir.

## Kalan kapsam ve üretim engelleri

- Gerçek firma, personel, şube üyeliği ve sunucuda rol/yetki kontrolü yok. Yetki şablonları erişim kontrolü değildir. Uygulama mevcut hesap sahibine göre ayrılan çalışma alanı kullanır.
- Seri bazlı stok çıkışı var; seri envanterinin toplu sayım mutabakatı henüz yok. Serili lotların adetle toplu değiştirilmesi bilinçli olarak engellenir.
- Satış kaydı iç operasyon kaydıdır. Tahsilat, kasa/POS, vergi, iade, mali fatura/fiş ve mutabakat tamamlanmadı.
- Maliyet son alış maliyetidir; lot bazlı FIFO/ağırlıklı maliyet ve muhasebe kârı hesaplanmaz.
- İTS, MEDULA, DVTİS, e-fatura ve cihaz bağlantıları yok. Yetkili pilot işletme, servis belgeleri/test erişimi ve sağlayıcı kurulumu gerekli.
- Stok uyarıları uygulama içidir. Arka planda otomatik push gönderimi yok.
- Mevcut veri modeli kullanıcı başına JSON çalışma alanıdır. Firma/şube geçişinde normalleştirilmiş veri modeli, mevcut veriyi koruyan geçiş ve çapraz kurum erişim testleri gerekli. Kullanıcı sayısı yük testi olmadan taahhüt edilemez.
- Üretim kabulü için iPhone/Android PWA, kamera izinleri, fotoğraf ve klavye senaryoları, eşzamanlı stok, yedekten geri dönüş, yük testi ve izleme doğrulanmalı.

Önerilen sıra: mevcut stok akışlarının cihaz doğrulaması → firma/şube/personel ve veri modeli → kasa/tahsilat/iade → bir ülkede yetkili servis pilotu → ölçülmüş kapasiteyle açılış.

## Raf kayıtları ve QR etiketleri — 2026-09-09

- Kalıcı raf kaydı: benzersiz numara, ad/açıklama, bölüm/depo; mevcut ürün konumundan kayıt oluşturma.
- Ürün kartı ve yeni ürün ekranında tanımlı raf seçimi; raf ekranında çoklu ürün yerleştirme.
- Raf QR içeriği sabit raf kimliğini taşır. Kamera/fotoğraf okuyucusu ve üst arama alanı bunu ürün barkodundan ayrı çözer; yalnızca mevcut hesabın rafını açar.
- Numara değişikliği bağlı ürün konumlarını birlikte günceller; önceden basılan QR çalışmaya devam eder. Başka raf/konumla birleştiren çakışmalar reddedilir.
- A4 veya 80 × 50 mm raf QR etiketi, 1–20 kopya, tarayıcı yazdır/PDF akışı. Eski ürün etiketi ekranı ayrı sekmede korunur.
- Raf değişikliği stok adetlerini ve mal kabul/çıkış geçmişini değiştirmez. Bu sürümde her ürün kartının tek raf konumu vardır; lot başına çoklu raf miktarı veya şubeler arası transfer değildir.
- Doğrulama: raf kayıt/atama/yeniden adlandırma, atomik hata ve çakışma kontrolü; üretilen QR'ın ZXing ile çözülmesi. Fiziksel telefon ve etiket yazıcısı testi bu çalışma sırasında yapılmadı.

## İşletme temeli — firma, personel, denetim ve finans

Uygulama `İşletme` ekranında firma kaydı, personel, satış, belgeli kabul, kasa, cari hesap, denetim, yedekler ve cihaz kontrolü içerir.

- Firma kayıtlarının anahtarı mevcut hesap sahibidir; eski envanter değiştirilmeden korunur. Üyelikler firma/kullanıcı ilişkisidir. İleri modüller henüz sunulmaz; eczane erişimi firma üyeliğiyle denetlenir.
- Kimlik Sites/ChatGPT oturumundan gelir. Personel kendi kayıt kimliğini sahibine iletir; sahip bu kimlikle yetki verir. Site paylaşımı ayrıca gereklidir. Uygulama personel eklerken dışarıya mesaj göndermez veya Site erişim politikasını değiştirmez.
- Komutlar sunucuda yetki kontrolünden geçer. Firma dışında yazma, eski sürümle yazma, işlem sırasında iptal edilen üyelikle yazma engellenir. Mali alanlar yetkisiz yanıtlardan çıkarılır. Anahtar rol şablonu uygulama UI'sında gerçek personel izinlerine aktarılabilir.
- Her envanter/finans değişikliğinden önce R2'ye durum yedeği alınır. Yedek bağlantısı, denetim kaydı ve yeni durum D1 batch içinde aynı sürüm kontrolüne bağlıdır. Geri yükleme öncesi mevcut durum ayrıca korunur; üyelikler ve denetim geçmişi geri alınmaz. JSON dışa aktarımı belge/resim baytlarını içermez; mevcut firma R2 nesneleri korunur.
- Satışta stok ve tahsilat aynı değişimde kaydedilir. Geleneksel stok çıkışı ekranındaki satış seçimi de yöntem alanıyla deftere bağlanır. Nakit/kart/banka kayıtları harici ödeme çekimi değildir.
- Kasa sayımı, beklenen/sayılan/fark, nakit giriş/çıkış ve takip eden dönem açılışı içerir. Bu iç kasa kapanışıdır; mali Z raporu değildir.
- Belgeli kabul tedarikçi, belge numarası, vade, PDF/fotoğraf eki ve satır maliyetleriyle stoğu ve cari borcu günceller. Aynı tedarikçi/belge numarasının tekrar kabulü engellenir. Eski belgesiz kabuller otomatik borca dönüştürülmez.
- Cari hesap tedarikçi toplam borç ve ödeme kaydı tutar; ödemeler tek tek faturaya dağıtılmaz. Nakit ödeme kasaya da yansır.
- Düzeltmeler karşı kayıt oluşturur; ilk kayıt silinmez. Genel stok düzeltmesi yalnızca ilgili lotun en son hareketi için yapılır; işletme satış/alış kayıtları bağlı stok/para etkileriyle düzeltilir. Bu süreç müşteri iadesi modülü değildir.
- Cihaz merkezi internet/oturum/sunucu bağlantısı, PWA durumu, kamera/kod testi, fotoğraf çözme ve mevcut bildirim testini birleştirir. Fiziksel iOS/Android ve yazıcı kabulü henüz yapılmadı.
- Doğrulama: satış/kasa/cari atomikliği, tekrar gönderim, belge tekrarı, karşı kayıt, yedek dönüşü, mali veri ayıklama; gerçek SQLite üzerinde eklemeli migrasyon, eski veri koruma, firma ayrımı, iptal edilmiş üyelik ve sürüm çakışması kontrolleri.
- Yük testi, bağımsız güvenlik incelemesi, kurum servisleri ve gerçek ödeme/mali belge entegrasyonları bu sürümde tamamlanmış kabul edilmez. Büyük veri kümelerinde mevcut JSON durum modelinin normalleştirilmesi gerekir.


## Faz 1 uygulama dilimi — 2026-09-09

Son onaylanan 20 madde `docs/gelisim-fazlari.md` içinde beş faza bağlandı. İlk dilim menü, satış sepeti ve okutma yaşam döngüsünü değiştirir; diğer fazların tamamlandığını iddia etmez. Satış/mal kabul/kasa/cari düzeltme zinciri ve sepet lot/seri kontrolleri dahil 52 test geçti. Kamera sonucu tek kez teslim edilir ve sepet uygulama içi gezinmede korunur. Fiziksel telefon, görsel tarayıcı QA ve ikinci personel kabulü yapılmadı.
