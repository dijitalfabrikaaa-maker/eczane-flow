# 20 yeni madde — uygulama ve devam kaydı

Kullanıcı 20 maddenin tamamını onayladı. Önceki üretim sürümü 30'dur; bu belgedeki yeni kaynak kodu henüz yayımlanmadı.

## Hazırlanan kaynak kodu

- 7: Tedarikçi teklif kaydı ve ürün bazlı geçerli teklif karşılaştırması. Fiyat/vade/teslim süresi birlikte görünür; mali veriler finans okuma yetkisiyle sınırlandırılır.
- 13: 30/60/90/180 günlük hareketsiz stok, bilinen maliyet ve eksik maliyetli kutular. Geçmişi olmayan ürün eskiden beri hareketsiz olarak varsayılmaz.
- 19: Lot ve dolap bağlantılı manuel sıcaklık kaydı; ölçüm aralığı aşımı, kayıt zamanı ve kullanıcı. Sensör bağlantısı veya otomatik karantina değildir.
- Konum: İşletme → Yönetim → Operasyon araçları. TR/AZ/RU metinler hazırlandı.
- Yeni kayıtlar mevcut şirket/şube bağlamı, revizyon kontrolü, yedek ve denetim işlemleriyle kaydedilir. Tekrar istek aynı kimlikle uygulanmaz.
- `node --test tests/operations.test.mjs`: 3/3 başarılı. Bunlar tarayıcı ve tam derleme testi değildir.

## Blokaj

Kaynak, workspace bakımından sonra mevcut Sites deposundan geri alındı. Resmî bağımlılık kurulumunun ağ onay süreci `network approval was cancelled before a decision was returned` sonucu ile sona erdi. TypeScript ve üretim derleme bağımlılıkları kurulu değil. Aynı ağ işlemi farklı yöntemle denenmedi. Bu nedenle değişiklikler üretime yayımlanmadı.

## Kalan sıra

1. Ortam kurulumu, tam tip kontrolü ve mevcut testlerin çalıştırılması; yeni dilimin yayımlanması.
2. Raf toplama rotası (1), raf kapasitesi (3), planlı raf sayımı (4).
3. Rezervasyon (2): tüm satış/çıkış/iade/transfer yollarında kullanılabilir miktar kontrolü; süre, iptal ve atomik tüketim.
4. Okutma kalite günlüğü (5) ve fatura OCR taslağı (6); OCR sağlayıcı anahtarı ayrıca gerekli.
5. Sipariş bölme (8), tedarikçi performansı (9), alım bütçesi (10).
6. Tarihli fiyat (11), düşük marj onayı (12), şube dengeleme (14), sezon hedefleri (15).
7. Vardiya devri (16), konsinye stok (17), kart birleştirme (18), birim dönüşümü (20).

17 madde henüz uygulanmadı; 7/13/19 kaynak kodu hazırlığı da üretim kabulü anlamına gelmez.

## Resend

Resend bağlantısı doğrulandı. Doğrulanmış ve gönderime açık alan adları medivra.net ve medrapor.net. Eczane ürünü için gönderici alan adı henüz seçilmedi. Başka ürünün alan adı kendiliğinden seçilmedi; yeni API anahtarı oluşturulmadı, e-posta gönderilmedi. Sites'a e-posta servis anahtarı tanımlandığı doğrulanmış değil.

Gerçek telefon/USB/Bluetooth, iki gerçek kullanıcı, barındırılan test firmasında geri yükleme ve resmî entegrasyon kabulü önceki açık durumunu korur.

## 10 Eylül devam paketi

Önceki kurulum engeli resmî kurulumun başarıyla tamamlanmasıyla çözüldü. Önceki üç modülün tip kontrolünde bulunan hatalar giderildi.

- 1: Raf numarasına göre sıralanan toplama listesi, ürün bazında toplandı onayı ve tamamlanma kontrolü. Stok düşmez; rezervasyon yerine geçmez.
- 3: Raf kapasitesi, doluluk, kalan yer ve kapasite üstü uyarısı. Yeni yerleştirmede kapasite sınırı sunucuda uygulanır.
- 4: Tarihli raf sayım planı ve gözlenen miktarlar. Stok değişirse eski gözlem reddedilir. Sayım farkı otomatik uygulanmaz; stok sayımı ekranında ayrıca düzeltilir.
- 7/13/19: Önceki kaynak hazırlığı bu pakete dahil.
- PWA: Güvenli alan viewport desteği, yeni sürüm bildirimi, işlem ortasında zorunlu yenilememe, çevrimdışı aynı sayfaya dönüş, önbellek bulunamazsa anlaşılır yanıt, bildirimden açık uygulamaya odaklanma.
- Doğrulama: 112 otomatik test başarılı; TypeScript tip kontrolü başarılı. PWA testleri service worker davranışını izole ortamda doğrular, fiziksel telefon testinin yerine geçmez.

Bu paketle altı maddenin belirtilen kapsamı uygulanmıştır. Kalan 14 madde: 2, 5, 6, 8, 9, 10, 11, 12, 14, 15, 16, 17, 18, 20. Önce rezervasyon ve okutma kalite günlüğü, ardından belge ve tedarikçi süreçleri ilerletilecek.

Resend: Kullanıcının son kararı ayrı alan adı açılana kadar e-posta entegrasyonunu bekletmektir. Mevcut iki alan adı kullanılmayacak.

Gerçek iPhone/Android PWA, kamera/okuyucu, iki kullanıcı ve geri yükleme kabul testleri açık. Önceki tarayıcı güvenlik engeli aşılmadı. Yayımlama sonucu sohbetin dağıtım kaydından doğrulanmalıdır.

## Sıradaki paket — rezervasyon ve okutma kalite günlüğü

- 2: Lot bazında, sipariş referanslı stok rezervasyonu. En fazla 30 günlük süre; süre dolunca sunucu hesaplamasında otomatik serbest kalır. İptal ve satışla atomik tamamlama; yetki, firma/şube, revizyon ve tekrar istek koruması.
- Satış, normal çıkış, sayım, transfer, tedarikçi iadesi ve geri alma ayrılan stoğu korur. Rezervasyon seri numarası ayırmaz; seri, miat, karantina ve raf kontrolleri satışta devam eder. Tam miktar teslim edilir; kısmi rezervasyon teslimi bu pakette yoktur.
- Kullanım: İşletme → Yönetim → Operasyon araçları → Rezervasyonlar. Teslim için Hızlı satışta rezervasyon seçilir ve ilgili lotun tüm ayrılan kutuları okutulur.
- 5: Kamera ilk sonucu, 20 saniyede kod bulunamaması, izin/başlatma hatası, fotoğraf sonucu, manuel giriş ve USB/Bluetooth test sonuçları. Süre ve tür kaydı; ham kod/fotoğraf tutulmaz. Kesintisiz modda her kare/ürün ayrı olay değildir; ilk sonuç bir denemeyi temsil eder.
- Günlük: İşletme → Cihaz kontrolü. Son 30 günün en fazla 500 satırı; tarih/sonuç filtresi. Rapor okuma yetkisi şubeyi, diğer personel yalnız kendi kayıtlarını görür. Ayrı tanılama tablosu stok revizyonunu değiştirmez.
- Çevrimdışı tanılama kuyruğu yoktur. Kaydetme hatası okutmayı durdurmaz. Fiziksel okuyucu türü otomatik tespit edilmez; okuyucu testi klavye modundaki girdiyi ölçer.
- Resend ayrı alan adı açılana kadar bekletilmeye devam ediyor.

Kurulum bu turda önce ağ onayı sonucu oluşmadan iptal edildi; aynı resmî kurulumun ikinci denemesi proxy bağlantı zaman aşımıyla sona erdi. Üç test dosyası kurulamayan Excel/karekod bağımlılıkları nedeniyle çalıştırılamadı. Sekiz yeni davranış testi geçti; stok hata türündeki bir gerileme giderildi. Yayın ve tam derleme sonucu ayrıca doğrulanmalıdır; kod hazırlığı canlı kabul anlamına gelmez.

## Satın alma paketi — 8, 9 ve 10

- 8: Tek ihtiyaç listesini tedarikçilere göre ayrı siparişlere bölme. En fazla 20 tedarikçi ve 100 satır; tamamı tek stok revizyonunda kaydedilir. Hatalı tedarikçi/satırda hiçbir sipariş oluşmaz. Gönderim değil, sistem içi hazırlıktır.
- 9: Sipariş bazında teslim edilen/bekleyen miktar, beklenen teslim gününe göre gecikme, bağlı mal kabullerinde fiyat farkı. Tarihi bulunmayan eski siparişler için gecikme uydurulmaz; bekleyen miktar kesin eksik teslim olarak adlandırılmaz.
- 10: Şube ve ay bazında bütçe. Belgeli alışlar ve o ayki açık sipariş taahhütleri birlikte sayılır. Siparişten teslimde aynı tutar iki kez eklenmez. Limit aşan personel isteği Onay merkezine gider; firma sahibi açık bütçe aşım onayı verir. Maliyetsiz/stok amaçlı mal kabul ve sayım mali harcama değildir.
- Kullanım: İşletme → Günlük işler → Satın alma planı; teslimler Belgeli kabulden, incelemeler Onay merkezinden.
- Doğrulama: Önceki kurulum sorunu giderildi. Önceden çalıştırılamayan üç dosya dahil 122 testin tümü geçti; TypeScript kontrolü geçti. Gerçek cihaz ve iki gerçek kullanıcı kabulü hâlâ açık.
- Bu paket sonrası kod kapsamı tamamlanan 11 madde, bekleyen 9 madde var: 6, 11, 12, 14, 15, 16, 17, 18, 20.
- Resend ayrı alan adına kadar beklemede; fatura OCR sağlayıcı bağlantısı henüz yok.

## Fiyat ve marj paketi — 11, 12; ürün detay düzeni

- 11: Firma sahibi Yönetim → Fiyat ve marj alanında şube için ürün bazında veya yüzdeyle toplu fiyat hazırlayabilir. Eski/yeni fiyat önizlemesi zorunlu; en fazla 100 ürün ve 366 gün ileri plan. Bekleyen plan iptal edilebilir. Tarihi gelen plan sunucu okumasında hesaplanır, sonraki başarılı yazmada durumu kalıcılaşır; bağımsız zamanlayıcı veya e-posta değildir. Açık sepet ve geçmiş satış fiyatları değiştirilmez. Cihazın yerel saati ISO zamana çevrilir.
- 12: Firma sahibi şube marj eşiğini belirler. Satılan lotun bilinen maliyeti kullanılır; bilinmeyen maliyet sıfır sayılmaz. Eşiğin altındaki personel satışı genel onay ayarı kapalı olsa bile onaya gider. Firma sahibi açık onay verir. Hızlı satış ve satış işaretli stok çıkışı aynı sunucu kontrolünden geçer. Onay beklerken stok ve kasa değişmez; inceleyen kişi kendi talebini onaylayamaz.
- Ürün detayı: 420 px sınırı kaldırıldı. Masaüstünde en fazla 1200 px geniş, ortalanmış pencere; hareketler ve ürün bilgileri iki sütun. 768 px altında tam ekran ve tek sütun. Sabit başlık, tek kaydırma yüzeyi; tarih alanları yan yana sığabilir. Fotoğraf/fiyat/raf/lot ve dışa aktar işlevleri korundu.
- Doğrulama: 126 otomatik test, TypeScript ve üretim derlemesi geçti. Gerçek telefonda görsel kabul ve canlı iki kullanıcı testi yapılmadı; önceki tarayıcı erişim engeli nedeniyle görsel doğrulama açık.
- Kod kapsamı tamamlanan 13 madde; kalan 7: 6 (OCR), 14, 15, 16, 17, 18, 20. Resend ayrı alan adı için bekliyor.
