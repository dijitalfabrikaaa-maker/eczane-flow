# Öncelikli hata düzeltmeleri ve kabul durumu

## 1–5: Düzeltildi; otomatik testler geçti

1. Kamera, stok işlemi ve taslak için ortak 100 satır sınırı. 101. seri reddedilir; ilk 100 kayıt korunur.
2. Finans yetkisi olmayan personelin taramasına fiyat alanları eklenmez. Finans yetki kontrolü kaldırılmadı.
3. Seçili raf tükenince yeni tarama ayrı satır açar; başka raf seçilebilir. Satış ve stok çıkışı kapsanır.
4. Karantinalı ürünün fatura bağlantılı tedarikçi iadesi yetkili onayla yapılabilir. Normal çıkış ve satış engeli korunur.
5. Birbirini götüren fiyat farkları satır bazında gösterilir ve açık kabul gerektirir.

## 6–9: Kabul kapsamı

6. Boş sunucu taslağı eski satırları temizler. Tamamlanmış komut yeniden canlanmaz. Belirsiz yerel taslak sessizce silinmez; karşılaştırma sunulur. Kurtarma kararları otomatik testten geçti; gerçek iki cihaz testi açık.
7. Okundu kaydı, kişisel tercihler, ödeme kapanınca uyarının düşmesi ve görev vadeleri mevcut testlerden geçti. Gerçek oturumda panel/sayaç testi açık. Dış push ve e-posta sağlayıcısı bağlı değil.
8. Şirket/şube kapsamı, iptal edilmiş üyelik, eski sürümle yazma ve mükerrer onay testleri geçti. Bunlar yerel testlerdir; iki gerçek kullanıcının eşzamanlı kabulü değildir.
9. Yönetilen önizlemede ana sayfa açıldı. Eczane modülüne geçiş test ortamının URL güvenlik politikası tarafından engellendi. Alternatif erişimle aşılmadı. Telefon kamerası, klavye, yön değiştirme ve arka plandan dönüş kabulü açık.

## Doğrulama

- `node --test tests/*.test.mjs`: 99 başarılı, 0 başarısız.
- `npx tsc --noEmit`: başarılı.
- Bu sonuçlar cihaz testi, kapasite garantisi veya resmi entegrasyon onayı değildir.

## Gerçek kullanımda sıradaki kabul

- İki cihazda aynı taslağı aç, birinde bitir, diğerinde tekrar kaydetmeyi dene: stok ikinci kez değişmemeli.
- İki yetkili personelle aynı stok üzerinde işlem yap: eski kayıt çakışması görünmeli; yetkisi kaldırılan kişi kayıt yapamamalı.
- Bildirimi oku ve yeniden giriş yap: kişisel okunmamış sayısı korunmalı; başka personelin okundu durumu değişmemeli.
- Telefonda QR/DataMatrix/çizgisel barkod, tam ekran kamera, klavye ve arka plana geçişi ayrı ayrı dene.

## Devam paketi — bildirim ve kamera yaşam döngüsü

- Bildirim okundu isteği sırasında kayıt durumu gösterilir. Başarısızlıkta panel içinde yeniden deneme açıklaması kalır; okundu sayısı iyimser biçimde düşürülmez. Aynı anda ikinci okundu isteği gönderilmez.
- Kişisel görev/okundu görünürlüğü sunucunun kullandığı ortak işlev üzerinden sınandı. Bir personelin okuduğu kayıt diğer personelin sayacını etkilemez; tamamlanan görev aktif uyarılardan kalkar.
- Kamera açılırken ekran kapatılır veya uygulama arka plana giderse eski başlatma sonucunun güncel ekranı değiştirmesi engellendi.
- Fotoğraf seçiminde boyut sınırı aşılırsa durdurulmuş kamera için devam düğmesi gösterilir. Kırpma ekranından arka plana geçip dönünce fotoğrafı yeniden çözümleme yolu korunur.
- Otomatik test toplamı: 101 başarılı, 0 başarısız. TypeScript kontrolü başarılı.
- Bu paket gerçek telefon/okuyucu, iki gerçek oturum veya barındırılan ortamda yedek dönüşü kabulünü tamamlamaz. Önceki URL politika engeli nedeniyle tarayıcı erişimi başka yoldan denenmedi. Dış push/e-posta ve resmî servis bağlantıları hâlâ açık.

## Yedekten dönüş devam paketi

- Geri yükleme penceresi tekrar denemelerde aynı işlem kimliğini korur. Tamamlanmış isteğin eski revizyonla tekrarı başarı olarak tanınır; yeni bir eski revizyonlu işlem çakışma verir.
- İş verisi eski yedekten alınırken güncel şube erişimleri ve rol şablonları korunur. Açık erişim reddi, eski yedekle tekrar erişime dönüşmez. Yedekte bulunmayan şubeye izin otomatik başka şubeye taşınmaz.
- 104 otomatik test ve TypeScript kontrolü geçti. Canlı veriye geri yükleme uygulanmadı; gerçek oturum/cihaz kabulü açık.
- Yeni öneri listesi: `2026-09-10-yeni-20-oneri.md`.
