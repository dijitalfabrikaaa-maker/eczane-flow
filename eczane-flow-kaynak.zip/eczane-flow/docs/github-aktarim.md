# GitHub aktarım ve geliştirme düzeni

## Aktarım kapsamı

Mevcut Git geçmişi, kaynak kodu, testler, statik dosyalar, paket kilidi, README ve `docs/` altındaki tüm Markdown dosyaları aktarılır. GitHub hedefi özel bir depo olmalıdır. Depodaki belgeler dışındaki, yalnız sohbet dosyalarında bulunan ek yol haritaları aktarılmış sayılmaz; gerekirse ayrıca bulunup eklenir.

Canlı D1/R2 içeriği, API anahtarları, yerel ortam dosyaları, bağımlılıklar ve derlenmiş çıktılar kaynak aktarımına dahil değildir.

## İşlem sırası

1. GitHub hesabında hedef depo ve erişim yetkisi belirlenir. Boş depo tercih edilir; README veya lisansla başlangıç yapılmaz.
2. Git geçmişinde hassas dosya ve anahtar örüntüleri kontrol edilir. Otomatik tarama kapsamlı güvenlik incelemesinin yerine geçmez.
3. GitHub ayrı bir uzak depo olarak eklenir. Mevcut Sites bağlantısı korunur; force push yapılmaz.
4. Kaynak geçmişi ana dala aktarılır; hedef SHA ve README/doküman ağacı doğrulanır. Başlangıç dosyaları varsa önce farkları incelenir.
5. Bundan sonraki değişiklikler özellik dalı ve inceleme isteği üzerinden yürütülür. Otomatik test/yayın iş akışı ayrıca kurulup doğrulanır; şu an yapılandırılmış olduğu varsayılmaz.

## Barındırma

GitHub'a aktarım mevcut canlı siteyi, alan adını ve veri depolarını taşımaz. Başka bir barındırmaya geçiş; kimlik doğrulama, D1/R2 uyarlaması, veri yedeği, sır yönetimi ve geri dönüş planıyla ayrı yapılmalıdır. İki kaynağın farklılaşmaması için her sürümün GitHub ve Sites SHA eşlemesi izlenir.

## İlk aktarım durumu

GitHub hesabı doğrulandı; bağlantının erişebildiği depo listesi boş. Hedef depo oluşturulup bağlantıya erişim verilmeden aktarım tamamlanmış değildir. README güncellendi; mevcut yedi yol haritası/denetim dosyası korundu ve bu aktarım belgesi eklendi.
