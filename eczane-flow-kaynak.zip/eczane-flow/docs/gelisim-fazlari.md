# Eczane Flow — 20 maddelik gelişim planı

Onay: 9 Eylül 2026. Numaralar, kullanıcının son onayladığı 20 maddelik listeye aittir.
Her faz bağımsız bir kullanılabilir sürüm olarak yayımlanır. Tamamlanmamış ve cihazda doğrulanmamış işler tamamlandı sayılmaz.

| Faz | Maddeler | Kapsam | Kabul ölçütü |
| --- | --- | --- | --- |
| 1 — Günlük kullanım | 1, 2, 3, 13 | İşlem doğruluğu; günlük iş/yönetim ayrımı; satış sepeti ve sabit özet; güvenilir okutma | Mal kabul–satış–kasa–düzeltme rakamları tutar; seri/miktar/lot hataları kaydı engeller; tekrar deneme çift kayıt üretmez. Mobil tam ekran ve kamera fiziksel cihazda ayrıca doğrulanır. |
| 2 — Ticaret zinciri | 4, 5, 6, 7, 8, 9, 18 | Parçalı tahsilat; iadeler; maliyet/kâr; ürün geçmişi; belge bazında borç; siparişten kabul; raporlar | Kısmi iade kalan miktarı aşamaz; tahsilat ve iade kasa/cari ile tutar; rapor, belge ve dışa aktarma aynı hesapları kullanır. |
| 3 — Şubeler ve denetim | 10, 11, 12, 16 | Şube stok/kasa ayrımı; sevk–teslim transferi; raf miktarları; personel onay zinciri | Şube verisi ve yetkiler sunucuda ayrılır; sevk edilen miktar iki kez satılamaz; onaylayan ve uygulayan kaydedilir. |
| 4 — Mobil ve veri akışı | 14, 15, 17, 19 | Fotoğraf; işlem bağlantılı bildirim; önizlemeli veri aktarımı; PWA bağlantı/taslak kurtarma | Yükleme ve ağ hataları veri kaybetmez; tekrar deneme çift işlem üretmez; bildirim sayacı tutar; hatalı aktarım onaysız stok değiştirmez. |
| 5 — AI ve yayın hazırlığı | 20; tüm fazların kabulü | Kaynağı gösteren AI önerileri; tüm akışların cihaz ve çok kullanıcılı kontrolü | AI hesapların dayanağını gösterir ve onaysız işlem yapmaz; gerçek cihaz, ikinci kullanıcı ve geri yükleme senaryoları doğrulanır. |

## Uygulama durumu

- Faz 1: ilk kullanılabilir uygulama dilimi tamamlandı; otomatik kontroller geçti. Gerçek cihaz ve ikinci personelle kabul kontrolü açık.
- Faz 2–4: aşağıdaki uygulama tamamlandı; 68 otomatik kontrol ve tip kontrolü geçti. Fiziksel cihaz ve gerçek ikinci kullanıcı kabulü açık.
- Faz 5: kural tabanlı danışman ve gerçek AI sağlayıcı bağlantısı kodu hazır. AI anahtarı/model yapılandırılmadığından canlı AI yanıtı doğrulanmadı. Tüm fazlar için nihai üretim kabulü tamamlandı sayılmıyor.
- Resmî İTS/MEDULA/e-fatura, gerçek kart tahsilatı ve yeni modül satın alma bu 20 maddenin çalışıyor kabul edilen parçaları değildir. Sağlayıcı erişimi ve sözleşmeleri netleştirilmeden bağlı gösterilmez.

## Her sürüm için kayıt

Değişiklikler, otomatik test kanıtı, cihazda doğrulanamayan noktalar ve kalan işler bu dosyaya eklenir. Yayımlanmış sürüm ile üretime hazır olduğu doğrulanmış sürüm farklı değerlendirilir.


## Faz 1 — İlk uygulama dilimi (9 Eylül 2026)

- Günlük satış/kasa/cari işlemleri yönetim sekmelerinden ayrıldı; sol menüden doğrudan erişim eklendi.
- Satışta ürün arama, görsel ve raf, mevcut lottan seçim, miktar, fiyat, satır toplamı ve masaüstünde sabit işlem özeti eklendi. Mobilde toplam/tamamla çubuğu alt navigasyonun üzerinde durur.
- Ürün tekrarlı okutulunca aynı lot/fiyat satırında miktar artar; lot tükenince sıradaki uygun lot seçilir. Seri, lot ve miat birlikte eşleşir. Seri okutulmadan serili stok anonim satılmaz.
- Sepet, uygulama içinde başka bir ekrana gidip dönünce korunur. Sayfayı kapatmada uyarı vardır. Yenilemeden kalıcı kurtarma henüz Faz 4 kapsamındadır.
- Belirsiz ağ sonucunda aynı işlem kimliği ve değişmez içerikle tekrar kontrol yapılır. Çift tıklama eşzamanlı ikinci gönderim başlatmaz.
- Kamera kendi görünür ekran ölçülerini kullanır. Canlı kamera, fotoğraf ve manuel kod aynı tek-seferlik sonuç kapısından geçer; eski tarama oturumundan gelen sonuç reddedilir ve kabul sonrası kamera durur.
- Satış ekranındayken mobil merkez Okut düğmesi mal kabule yönlendirmek yerine satış sepetine okutmayı açar.
- 52 otomatik test geçti: mevcut testler ve 4 yeni sepet/işlem zinciri senaryosu. Statik tip kontrolü geçti.

### Açık kabul kontrolleri

1. Fiziksel iPhone/Android: PWA ve tarayıcı, yatay/dikey kamera, klavye açılması ve fotoğraftan okuma.
2. İkinci gerçek personel: aynı stokla eşzamanlı satış, yetki kaldırma, doğru hata mesajı.
3. Görsel tarayıcı kontrolü bu dilimde yapılmadı; ekran yerleşimi kaynak düzeyinde düzenlendi.
4. İade süreci bu dilimde yeni eklenmedi. Mevcut kontrollü düzeltme testi, Faz 2'deki belgeye bağlı kısmi iadenin yerine geçmez.


## Faz 2–5 uygulaması — 9 Eylül 2026

| Madde | Uygulanan davranış | Kullanım / sınır |
| --- | --- | --- |
| 1 | Stok, tahsilat ve hareketler aynı yetkili işlemde kaydedilir; eski revizyon ve tekrar işlem reddedilir. | Otomatik veri modeli ve SQL yarış kontrolü var; yük/gerçek çoklu oturum kabulü yapılmadı. |
| 2 | Günlük işlemler ve yönetim ayrıldı; yeni ticari ve yönetim ekranları ilgili gruplara eklendi. | Kirli sepet tamamlanmadan şube değiştirilmez. |
| 3 | Seri/lot kontrollü satış sepeti, fiyat, miktar ve mobil toplam. | Satış kaydı gerçek banka/POS çekimi değildir. |
| 4 | Nakit, kart ve banka parçalı tahsilat; müşteri adıyla kalan borç, sonraki tahsilat ve para üstü. | Girilmiş nakit toplamın altındaysa parçalı ödeme istenir. |
| 5 | Orijinal belge/satır üzerinden kısmi ve tam iade; kalan miktar ve para iadesi sınırı. | Eski satır dökümü olmayan kayıtlar kontrollü düzeltme ister. Miadı dolmuş tedarikçi iadesi desteklenir; miadı dolmuş satış engellenir. |
| 6 | Lot maliyeti, satıştaki fiyat/indirim anlık kaydı ve brüt kâr. | İndirim katalog fiyatını değiştirmez. Eksik maliyet sıfır kabul edilmez; kâr eksik gösterilir. Lot maliyeti ağırlıklı ortalamadır. |
| 7 | Ürün detayında tarih filtreli hareket, lot, seri, tedarikçi, belge, maliyet ve satış fiyatı; PDF/CSV. | Eski kayıtta bulunmayan belge/satır ilişkisi üretilmez. |
| 8 | Belge bazlı ödeme, açık bakiye ve tedarikçi alacağı. | Önceden genel cari ödeme olarak girilen tutarlar ve fazla alacak en eski açık belgeye yansıtılır. Yeni belge ödemesinde doğrudan bağ kaydedilir. |
| 9 | Sipariş kaydı, siparişten belgeli kabul, kalan teslim miktarı ve kısmi/tam kapanış. | Gerçek lot/miat alıcı tarafından doğrulanır. |
| 10 | Firma içinde şube seçimi, ayrı stok ve kasa, kişiye izin verilen şubeler. | Yeni şubeye katalog/tedarikçi kopyası alınır; stok sıfır başlar. Personel firma izinleri ve şube erişimi sunucuda denetlenir. |
| 11 | Sevkte kaynaktan düşüm, yolda miktar, hedefte kısmi/tam teslim ve yeniden deneme koruması. | Kaybolan/hasarlı sevk için ayrı uyuşmazlık kapatma henüz eklenmedi; sevk geri dönüşü ayrı kontrollü transfer ister. |
| 12 | Lot bazında birden çok rafa miktar yerleştirme; raf kapasitesi stoğu aşamaz; QR içeriği yerleştirilen miktarı gösterir. | Stok azalınca aşan raf miktarı otomatik azaltılır; fiziksel raf dağılımı yeniden kontrol edilir. Seri bazında raf tahsisi yok. |
| 13 | Mevcut tam ekran tarayıcı ve tek seferlik okutma sonucu korunur. | Fiziksel iPhone/Android kamera ve izin testi açık; tüm barkodların okunduğu iddia edilmez. |
| 14 | Kamera/galeri, JPEG sıkıştırma, merkezden kare kırpma, yükleme yüzdesi ve tekrar denemede önizleme. | Cihazın çözemediği HEIC için desteklenen görsel seçilir; gerçek cihaz kabulü açık. |
| 15 | Kullanıcıya özel okundu bilgisi ve stok/miat/ödeme tercihleri; vadesi gelen belgeye yönlendirme. | Bunlar uygulama içi bildirimlerdir. Sunucudan zamanlanmış push/e-posta gönderimi bağlı değildir. |
| 16 | Gerçek personel izinleri, genişletilmiş rol şablonları, stok/finans onay kuralı, onaylayan/gerekçe kaydı. | Talep sahibi kendi işlemini onaylayamaz; onay anında stok ve yetki tekrar kontrol edilir. Firma/şube erişimi değişikliği ve tüm firma yedeği yalnız sahibindir. Sites görüntüleme paylaşımı ayrıca gerekir. |
| 17 | Excel/CSV eşleme, önizleme, hatalı satır raporu, yeniden içeri alma parmak izi ve atomik kayıt. | Koruma yeni sürümde alınan aynı içerik için geçerli; önceki aktarımlar geriye dönük parmak izine sahip değildir. |
| 18 | Şube bağlamı ve tarih filtreli stok/ticaret raporları; aynı satırlardan PDF, CSV ve yazdırma. | Mevcut stok anlık görüntüdür; tarih filtresi hareket ve ticaret dönemine uygulanır. |
| 19 | Satış, belgeli kabul, mal kabul, sayım ve çıkış için kullanıcı/şube/işlem bazlı sunucu taslağı; bağlantı kesilince yerel kopya, sürüm çakışması ve değişmeyen yeniden deneme kimliği. | Çevrimdışı kesin stok/kasa kaydı yapılmaz; çevrimdışı ilk açılış uygulama yerine bağlantı ekranı gösterir. Açık sayfada taslak korunur. |
| 20 | Kaynak ürün/hareketleri gösteren stok danışmanı; ihtiyaç, miat ve maliyet eksikleri. Gerçek Responses API çağrısı, 20 istek/firma/gün sınırı, zaman aşımı ve onaysız işlem yapmama. | OPENAI_API_KEY ve OPENAI_MODEL sunucu ortamında yapılandırılmadı. Kural tabanlı öneriler çalışır; gerçek AI yorumlama dış bağımlılık olarak açık. |

### Doğrulama kanıtı

- 68 otomatik test başarılı; tip kontrolü başarılı.
- Şube sevk → kısmi kabul → tam kabul miktar korunumu; yetkisiz şube, fazla tahsis, tekrar kabul ve yedek kimliği test edildi.
- Onay bekleyen satışın sıfır etkisi, yetkisiz/kendi kendini onaylama reddi, onay anında değişmiş stok ve ret senaryoları test edildi.
- Taslaklarda kullanıcı/şube/işlem ayrımı ve aynı sürüme iki cihaz yazmasının çakışması SQLite üzerinde test edildi.
- Tahsilat → iade → borç ve kasa, eski genel ödeme → belge bakiyesi, indirim/katalog ayrımı, maliyet eksikliği, siparişten kısmi kabul test edildi.
- Fotoğraf ve kamera için fiziksel cihaz, tarayıcı görsel etkileşim, gerçek ikinci personel ve kapasite/yük testi bu turda yapılmadı. Bunlar geçmeden “tam üretim kabulü” denmez.

### Etkinleştirme ve işletim koşulları

1. AI: yönetilen sunucu ortamında OPENAI_API_KEY ve OPENAI_MODEL; mevcut yayın bunları istemcide saklamaz. Bağlantı kurulduktan sonra gerçek yanıt, hata, maliyet ve kota kabulü yapılır. Kaynak: https://developers.openai.com/api/docs/guides/text .
2. Site mevcut özel erişim düzeyini korur. Personel uygulamaya atanmasının yanında Site görüntüleme erişimine de sahip olmalıdır.
3. Resmî İTS/MEDULA/ÜTS/e-fatura, gerçek banka/POS tahsilatı ve zamanlanmış dış bildirimler için sağlayıcı erişimleri ayrı projelendirilir; hiçbir bağlantı varmış gibi gösterilmez.
4. Mevcut depolama firma başına revizyon kontrollü kayıt ve tam yedek yaklaşımını korur. Belirsiz yüksek kullanıcı/işlem hacminde sınırsız ölçek garantisi verilmez; kapasite testi ve gerekirse tablo bazlı işlem deposuna geçiş gerekir.
5. Raf azaltımı yerleştirme toplamını stokla tutarlı tutar; gerçek kutunun hangi raftan alındığını operatör doğrular. İade ve transfer fiziksel teslim kanıtının yerini almaz.
