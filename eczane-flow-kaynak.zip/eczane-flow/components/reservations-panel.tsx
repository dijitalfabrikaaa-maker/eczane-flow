'use client';
import {useEffect,useState} from 'react';
import {Button} from '@/components/ui/button';
import {Input} from '@/components/ui/input';
import {activeReservation,availableQuantity,reservedQuantity} from '@/lib/reservations';
import type {Inventory} from '@/lib/inventory';
export function ReservationsPanel({data,lang,busy,can,save}:{data:Inventory;lang:string;busy:boolean;can:(p:string)=>boolean;save:(p:Record<string,unknown>)=>Promise<void>}){
 const t=(a:string,b:string,c:string)=>lang==='az'?b:lang==='ru'?c:a;
 const [batch,setBatch]=useState(''),[qty,setQty]=useState('1'),[reference,setReference]=useState(''),[expires,setExpires]=useState(''),[now,setNow]=useState(new Date());
 useEffect(()=>{const id=setInterval(()=>setNow(new Date()),15000);return()=>clearInterval(id)},[]);
 return <><h2>{t('Stok rezervasyonları','Stok rezervləri','Резервы запасов')}</h2><p>{t('Sipariş referansıyla kutu ayırın. Süre dolunca kullanılabilir miktar otomatik serbest kalır. Teslimde Hızlı satış ekranından rezervasyonu seçip ilgili lotun tam miktarını okutun.','Sifariş istinadı ilə qutu ayırın. Müddət bitdikdə stok azad olur. Satışda rezervi seçib lotun tam sayını oxudun.','Резервируйте упаковки по номеру заказа. По истечении срока запас освобождается. При продаже выберите резерв и отсканируйте полное количество партии.')}</p>
 {can('out.write')&&<form onSubmit={e=>{e.preventDefault();void save({kind:'reservation-create',batchId:batch,qty:Number(qty),reference,expiresAt:new Date(expires).toISOString()})}}><fieldset disabled={busy}><legend>{t('Yeni rezervasyon','Yeni rezerv','Новый резерв')}</legend>
 <label>{t('Ürün / lot','Məhsul / lot','Товар / партия')}<select required value={batch} onChange={e=>setBatch(e.target.value)}><option value="">—</option>{data.batches.filter(b=>b.qty>0).map(b=><option key={b.id} value={b.id}>{data.products.find(p=>p.id===b.productId)?.name} · {b.lot} · {availableQuantity(data,b.id,now)} {t('uygun','mövcud','доступно')}</option>)}</select></label>
 <label>{t('Kutu','Qutu','Упаковок')}<Input required type="number" min={1} max={10000} value={qty} onChange={e=>setQty(e.target.value)}/></label>
 <label>{t('Sipariş referansı','Sifariş istinadı','Номер заказа')}<Input required maxLength={100} value={reference} onChange={e=>setReference(e.target.value)}/></label>
 <label>{t('Son tarih (en fazla 30 gün)','Son tarix (ən çox 30 gün)','Срок (до 30 дней)')}<Input required type="datetime-local" value={expires} onChange={e=>setExpires(e.target.value)}/></label><Button>{t('Stok ayır','Stok ayır','Зарезервировать')}</Button></fieldset></form>}
 {batch&&<p>{t('Fiziksel / ayrılan / kullanılabilir','Fiziki / ayrılan / mövcud','Физически / резерв / доступно')}: {data.batches.find(b=>b.id===batch)?.qty} / {reservedQuantity(data,batch,now)} / {availableQuantity(data,batch,now)}</p>}
 <div className="operations-cards">{[...(data.reservations||[])].reverse().map(r=>{const b=data.batches.find(b=>b.id===r.batchId),active=activeReservation(r,now);return <article key={r.id}><h3>{r.reference}</h3><p>{data.products.find(p=>p.id===b?.productId)?.name} · {b?.lot} · {r.qty}</p><strong>{active?t('Ayrıldı','Ayrıldı','В резерве'):r.status==='fulfilled'?t('Teslim edildi','Təhvil verildi','Выдано'):r.status==='cancelled'?t('İptal edildi','Ləğv edildi','Отменено'):t('Süresi doldu','Müddəti bitdi','Истёк')}</strong><p>{new Date(r.expiresAt).toLocaleString()}</p>{active&&can('out.write')&&<Button variant="outline" disabled={busy} onClick={()=>void save({kind:'reservation-cancel',targetId:r.id})}>{t('Rezervasyonu kaldır','Rezervi ləğv et','Снять резерв')}</Button>}</article>})}</div></>;
}
