'use client';

import * as React from 'react';
import {Dialog as Primitive} from 'radix-ui';
import {X} from 'lucide-react';
import {DialogOverlay} from '@/components/ui/dialog';
import {cn} from '@/lib/utils';

/** App dialogs use viewport bounds instead of translate-based centering. */
export function AppDialogContent({children,className,showCloseButton=true,onOpenAutoFocus,...props}:React.ComponentProps<typeof Primitive.Content>&{showCloseButton?:boolean}){
 return <Primitive.Portal><DialogOverlay/><Primitive.Content {...props} data-slot="dialog-content" className={cn('app-dialog-surface',className)} onOpenAutoFocus={event=>{onOpenAutoFocus?.(event);if(!event.defaultPrevented&&window.matchMedia('(max-width:767px)').matches){event.preventDefault();requestAnimationFrame(()=>document.querySelector<HTMLElement>('.app-dialog-surface[data-state="open"]')?.focus());}}}>
 {children}{showCloseButton&&<Primitive.Close className="app-dialog-close" aria-label="Kapat / Bağla / Закрыть"><X size={20}/></Primitive.Close>}
 </Primitive.Content></Primitive.Portal>;
}
