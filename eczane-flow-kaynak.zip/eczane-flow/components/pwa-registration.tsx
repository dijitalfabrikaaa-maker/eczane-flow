'use client';
import {useEffect,useState} from 'react';
export function PwaRegistration(){
 const [waiting,setWaiting]=useState(false),[dismissed,setDismissed]=useState(false),[lang,setLang]=useState('tr');
 useEffect(()=>{if(!('serviceWorker' in navigator))return;let disposed=false,registration:ServiceWorkerRegistration|undefined;const cleanups:(()=>void)[]=[];
 const notice=()=>{if(!disposed){setLang(document.documentElement.lang);setWaiting(true)}};
 const online=()=>{void registration?.update().catch(()=>{})};window.addEventListener('online',online);
 navigator.serviceWorker.register('/sw.js',{updateViaCache:'none'}).then(r=>{if(disposed)return;registration=r;if(r.waiting)notice();const found=()=>{const worker=r.installing;if(!worker)return;const changed=()=>{if(worker.state==='installed'&&navigator.serviceWorker.controller)notice()};worker.addEventListener('statechange',changed);cleanups.push(()=>worker.removeEventListener('statechange',changed))};r.addEventListener('updatefound',found);cleanups.push(()=>r.removeEventListener('updatefound',found));found();void r.update().catch(()=>{})}).catch(()=>{});
 return()=>{disposed=true;window.removeEventListener('online',online);cleanups.forEach(fn=>fn())};},[]);
 if(!waiting||dismissed)return null;
 return <aside className="pwa-update-notice" role="status"><p>{lang==='az'?'Yeni versiya hazırdır. Əməliyyatınızı tamamlayın, tətbiqin bütün pəncərələrini bağlayıb yenidən açın.':lang==='ru'?'Доступна новая версия. Завершите операцию, закройте все окна приложения и откройте его снова.':'Yeni sürüm hazır. İşleminizi tamamlayın, uygulamanın tüm pencerelerini kapatıp yeniden açın.'}</p><button type="button" onClick={()=>setDismissed(true)}>{lang==='az'?'Anladım':lang==='ru'?'Понятно':'Anladım'}</button></aside>;
}
