'use client';
import {useState} from 'react';
import {Button} from '@/components/ui/button';
import {Input} from '@/components/ui/input';
import {type Product} from '@/lib/inventory';
export function ProductPrices({product,currency,saving,lang,onSave}:{product:Product;currency:string;saving:boolean;lang:string;onSave:(cost:number,price:number)=>Promise<boolean>}){
 const t=(tr:string,az:string,ru:string)=>lang==='ru'?ru:lang==='az'?az:tr;
 const [cost,setCost]=useState(product.cost===undefined?'':String(product.cost/100)),[price,setPrice]=useState(String(product.price/100));
 const valid=[cost,price].every(v=>v!==''&&Number.isFinite(Number(v))&&Number(v)>=0&&Number(v)<=1000000);
 return <form className="product-price-form" onSubmit={async e=>{e.preventDefault();if(valid)await onSave(Math.round(Number(cost)*100),Math.round(Number(price)*100))}}><h3>{t('Alış ve satış fiyatları','Alış və satış qiymətləri','Закупка и продажа')} · {currency}</h3><label>{t('Son birim alış maliyeti','Son vahid alış maya dəyəri','Последняя закупочная цена')}<Input type="number" step="0.01" min="0" required disabled={saving} value={cost} onChange={e=>setCost(e.target.value)}/></label><label>{t('Birim satış fiyatı','Vahid satış qiyməti','Цена продажи')}<Input type="number" step="0.01" min="0" required disabled={saving} value={price} onChange={e=>setPrice(e.target.value)}/></label><Button disabled={saving||!valid}>{t('Fiyatları kaydet','Qiymətləri saxla','Сохранить цены')}</Button><small>{t('Yeni işlemler için kullanılır. Geçmiş kayıtların fiyatları değişmez.','Yeni əməliyyatlarda istifadə olunur. Keçmiş qiymətlər dəyişmir.','Для новых операций. Цены в истории не меняются.')}</small></form>
}
