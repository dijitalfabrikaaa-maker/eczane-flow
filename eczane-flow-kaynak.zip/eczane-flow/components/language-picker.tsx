'use client';
import {Select,SelectContent,SelectItem,SelectTrigger} from '@/components/ui/select';
export type Language='tr'|'az'|'ru';
const languages=[{code:'tr',name:'Türkçe',region:'Türkiye'},{code:'az',name:'Azərbaycanca',region:'Azərbaycan'},{code:'ru',name:'Русский',region:'Русский язык'}] as const;
export function LanguagePicker({value,onChange,label,compact=false,dark=false}:{value:Language;onChange:(v:Language)=>void;label:string;compact?:boolean;dark?:boolean}){
 const active=languages.find(l=>l.code===value)!;
 return <Select value={value} onValueChange={v=>onChange(v as Language)}><SelectTrigger className={'locale-trigger '+(dark?'locale-on-dark':'')+(compact?' locale-compact':'')} aria-label={`${label}: ${active.name}`}><span className="locale-current"><img src={`/flags/${value}.svg`} alt="" width={24} height={16}/><span className="locale-full-name">{active.name}</span><span className="locale-code">{value.toUpperCase()}</span></span></SelectTrigger><SelectContent className="locale-popover" position="popper" align="end" sideOffset={10}>{languages.map(l=><SelectItem className="locale-option" key={l.code} value={l.code} textValue={l.name}><span className="locale-option-body"><img src={`/flags/${l.code}.svg`} alt="" width={27} height={18}/><span lang={l.code}><strong>{l.name}</strong><small>{l.code.toUpperCase()}</small></span></span></SelectItem>)}</SelectContent></Select>
}
