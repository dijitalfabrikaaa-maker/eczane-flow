'use client';
import {Input} from '@/components/ui/input';
import type {Shelf} from '@/lib/inventory';
import type {Language} from '@/components/language-picker';
export function ShelfLocation({shelves=[],value,onChange,disabled,lang}:{shelves?:Shelf[];value:string;onChange:(v:string)=>void;disabled?:boolean;lang:Language}){
 const known=shelves.some(s=>s.code===value);
 const t=(tr:string,az:string,ru:string)=>lang==='az'?az:lang==='ru'?ru:tr;
 return <span className="shelf-location-field">{shelves.length>0&&<select aria-label={t('Tanımlı raf seç','Təyin edilmiş rəf seç','Выберите полку')} disabled={disabled} value={known?value:'__custom'} onChange={e=>onChange(e.target.value==='__custom'?'':e.target.value)}><option value="__custom">{t('Diğer konum / elle yaz','Digər yer / əl ilə yaz','Другое расположение')}</option>{shelves.map(s=><option key={s.id} value={s.code}>{s.code} · {s.name}{s.zone?' · '+s.zone:''}</option>)}</select>}{!known&&<Input required aria-label={t('Raf konumu','Rəf yeri','Расположение')} maxLength={120} value={value} onChange={e=>onChange(e.target.value)} disabled={disabled}/>}</span>
}
