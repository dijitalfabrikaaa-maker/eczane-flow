CREATE TABLE `operation_drafts` (
	`scope` text NOT NULL,
	`user` text NOT NULL,
	`key` text NOT NULL,
	`body` text NOT NULL,
	`version` integer DEFAULT 1 NOT NULL,
	`updated_at` text NOT NULL,
	PRIMARY KEY(`scope`, `user`, `key`)
);
