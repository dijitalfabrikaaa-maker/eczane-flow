CREATE TABLE `company_audits` (
	`id` text PRIMARY KEY NOT NULL,
	`company` text NOT NULL,
	`actor` text NOT NULL,
	`action` text NOT NULL,
	`note` text NOT NULL,
	`date` text NOT NULL,
	`revision` integer NOT NULL
);
--> statement-breakpoint
CREATE INDEX `audits_company` ON `company_audits` (`company`,`revision`);--> statement-breakpoint
CREATE TABLE `company_backups` (
	`id` text PRIMARY KEY NOT NULL,
	`company` text NOT NULL,
	`key` text NOT NULL,
	`date` text NOT NULL,
	`revision` integer NOT NULL
);
--> statement-breakpoint
CREATE INDEX `backups_company` ON `company_backups` (`company`,`date`);--> statement-breakpoint
CREATE TABLE `company_documents` (
	`id` text PRIMARY KEY NOT NULL,
	`company` text NOT NULL,
	`name` text NOT NULL,
	`mime` text NOT NULL,
	`date` text NOT NULL
);
--> statement-breakpoint
CREATE INDEX `documents_company` ON `company_documents` (`company`);--> statement-breakpoint
CREATE TABLE `company_members` (
	`company` text NOT NULL,
	`user` text NOT NULL,
	`name` text NOT NULL,
	`permissions` text NOT NULL,
	`active` integer DEFAULT 1 NOT NULL,
	PRIMARY KEY(`company`, `user`)
);
--> statement-breakpoint
CREATE INDEX `members_user` ON `company_members` (`user`);