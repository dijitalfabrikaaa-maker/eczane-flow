CREATE TABLE `scan_quality` (
 `scope` text NOT NULL,
 `id` text NOT NULL,
 `actor` text NOT NULL,
 `date` text NOT NULL,
 `source` text NOT NULL,
 `mode` text NOT NULL,
 `outcome` text NOT NULL,
 `elapsed_ms` integer NOT NULL,
 PRIMARY KEY(`scope`, `id`)
);
--> statement-breakpoint
CREATE INDEX `scan_quality_scope_date` ON `scan_quality` (`scope`, `date`);
