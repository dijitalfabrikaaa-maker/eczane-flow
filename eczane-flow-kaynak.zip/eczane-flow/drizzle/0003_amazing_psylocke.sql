CREATE TABLE `ai_usage` (
	`company` text NOT NULL,
	`day` text NOT NULL,
	`requests` integer DEFAULT 0 NOT NULL,
	PRIMARY KEY(`company`, `day`)
);
