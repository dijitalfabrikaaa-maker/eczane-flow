const CACHE='katvio-shell-v2';
self.addEventListener('install',event=>event.waitUntil(caches.open(CACHE).then(cache=>cache.addAll(['/offline.html','/brand/icon-192.png','/brand/icon-512.png']))));
self.addEventListener('activate',event=>event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k.startsWith('katvio-shell-')&&k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim())));
self.addEventListener('fetch',event=>{const url=new URL(event.request.url);if(url.origin!==self.location.origin||event.request.method!=='GET')return;
// Never cache account data, APIs, or authenticated HTML.
if(event.request.mode==='navigate')event.respondWith(fetch(event.request).catch(async()=>await caches.match('/offline.html')||new Response('Bağlantı yok. İnternete bağlanıp yeniden deneyin.',{status:503,headers:{'Content-Type':'text/plain; charset=utf-8'}})));
else if(['/brand/icon-192.png','/brand/icon-512.png'].includes(url.pathname))event.respondWith(caches.match(event.request).then(cached=>cached||fetch(event.request)));
});
self.addEventListener('notificationclick',event=>{event.notification.close();event.waitUntil(self.clients.matchAll({type:'window',includeUncontrolled:true}).then(async clients=>{const existing=clients.find(c=>new URL(c.url).origin===self.location.origin);if(existing)return existing.focus();return self.clients.openWindow('/eczane')}))});
