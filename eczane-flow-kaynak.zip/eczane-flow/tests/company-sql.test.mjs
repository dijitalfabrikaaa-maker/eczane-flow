import test from 'node:test';import assert from 'node:assert/strict';import {DatabaseSync} from 'node:sqlite';import {readFileSync,readdirSync} from 'node:fs';
test('Migrations preserve legacy records and DB write guard rejects wrong firm, stale revision and revoked membership',()=>{
 const db=new DatabaseSync(':memory:');for(const f of readdirSync(new URL('../drizzle/',import.meta.url)).filter(x=>x.endsWith('.sql')).sort()){db.exec(readFileSync(new URL('../drizzle/'+f,import.meta.url),'utf8'));if(f.startsWith('0000'))db.prepare('INSERT INTO inventory_workspaces VALUES(?,?,?,?)').run('owner-a','{"legacy":true}',7,'2026-09-09')}
 assert.equal(db.prepare('SELECT state FROM inventory_workspaces').get().state,'{"legacy":true}');
 db.prepare('INSERT INTO inventory_workspaces VALUES(?,?,?,?)').run('owner-b','{"other":true}',1,'2026-09-09');
 db.prepare('INSERT INTO company_members VALUES(?,?,?,?,?)').run('owner-a','employee','Ada','["stock.read","out.write"]',1);
 const source=readFileSync(new URL('../lib/company-server.ts',import.meta.url),'utf8'),condition=source.match(/const condition='([^']+)'/)[1];
 const update=db.prepare('UPDATE inventory_workspaces SET revision=revision+1 WHERE '+condition),args=['owner-a',7,'employee','employee','["stock.read","out.write"]'];
 assert.equal(update.run(...args).changes,1);assert.equal(update.run(...args).changes,0);
 assert.equal(update.run('owner-b',1,'employee','employee',args[4]).changes,0);
 db.prepare('UPDATE company_members SET active=0 WHERE user=?').run('employee');assert.equal(update.run('owner-a',8,'employee','employee',args[4]).changes,0);
 assert.equal(update.run('owner-a',8,'owner-a','owner-a','').changes,1);assert.equal(db.prepare('SELECT revision FROM inventory_workspaces WHERE owner=?').get('owner-b').revision,1);db.close();
});
