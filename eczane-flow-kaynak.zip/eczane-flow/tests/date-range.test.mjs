import test from 'node:test';
import assert from 'node:assert/strict';
import {localDateKey,countryZone,inDateRange,shiftDay} from '../lib/date-range.ts';
test('Country local dates keep late-night movements on the displayed date',()=>{const stamp='2026-09-08T20:30:00Z';assert.equal(localDateKey(stamp,countryZone('TR')),'2026-09-08');assert.equal(localDateKey(stamp,countryZone('AZ')),'2026-09-09')});
test('Range includes both boundary days and rejects reversed dates',()=>{const r={from:'2026-09-01',to:'2026-09-08'};assert.ok(inDateRange(r.from,r));assert.ok(inDateRange(r.to,r));assert.equal(inDateRange('2026-08-31',r),false);assert.equal(inDateRange('2026-09-05',{from:r.to,to:r.from}),false);assert.ok(inDateRange('2026-09-05',{from:'',to:''}))});
test('Day offsets handle month and leap year boundaries',()=>{assert.equal(shiftDay('2026-03-01',-1),'2026-02-28');assert.equal(shiftDay('2024-03-01',-1),'2024-02-29');assert.equal(shiftDay('2026-12-31',1),'2027-01-01')});
