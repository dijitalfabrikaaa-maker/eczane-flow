import test from 'node:test';
import assert from 'node:assert/strict';
import {initialInventory,applyCommand} from '../lib/inventory.ts';
import {addOperationScan} from '../lib/operation-scan.ts';
const now=new Date('2026-09-09T10:00:00Z');
function state(){const s=initialInventory(now);s.products=[{...s.products[0],code:'09506000134352',price:500}];s.batches=[];return s}
const raw=serial=>`(01)09506000134352(17)271231(10)NEW(21)${serial}`;
test('Continuous receipt retains different serials, rejects duplicates and only commits on approval',()=>{
 const s=state();let lines=[];for(const serial of ['A','B','C'])lines=addOperationScan(s,lines,raw(serial),'receive',now);
 assert.equal(lines.length,3);assert.equal(s.batches.length,0);
 assert.throws(()=>addOperationScan(s,lines,raw('B'),'receive',now),/DUPLICATE/);
 const next=applyCommand(s,{id:'receipt-test',revision:0,kind:'receive',note:'Depot',lines},now);
 assert.equal(next.batches[0].qty,3);assert.deepEqual(next.batches[0].serials,['A','B','C']);
 assert.throws(()=>addOperationScan(next,[],raw('A'),'receive',now),/DUPLICATE/);
 let exits=[];for(const serial of ['B','A','C'])exits=addOperationScan(next,exits,raw(serial),'out',now);
 assert.throws(()=>addOperationScan(next,exits,raw('A'),'out',now),/DUPLICATE/);
 assert.equal(applyCommand(next,{id:'exit-test',revision:0,kind:'out',note:'Dispatch',lines:exits},now).batches[0].qty,0);
});
test('Receipt rejects unknown or incomplete codes and mismatched expiry without changing input',()=>{
 const s=state();assert.throws(()=>addOperationScan(s,[],'09506000134352','receive',now),/BATCH/);
 assert.throws(()=>addOperationScan(s,[],'12345678','receive',now),/UNKNOWN_PRODUCT/);
 const lines=addOperationScan(s,[],raw('A'),'receive',now);
 assert.throws(()=>addOperationScan(s,lines,raw('B').replace('271231','281231'),'receive',now),/BATCH/);
 assert.equal(lines.length,1);
});
