import test from 'node:test';
import assert from 'node:assert/strict';
import {initialInventory,applyCommand,shelfQR,parseShelfQR} from '../lib/inventory.ts';
import {QRCodeWriter,BarcodeFormat,EncodeHintType,RGBLuminanceSource,HybridBinarizer,BinaryBitmap,MultiFormatReader} from '@zxing/library';
const shelf={id:'shelf-test-001',code:'a-01',name:'İlaçlar',zone:'Ana depo'};
const cmd=(kind,extra,id='shelf-command-001')=>({id,revision:0,kind,...extra});
test('Register legacy shelf, assign products, rename without changing stock or QR identity',()=>{
 const original=initialInventory(),s=applyCommand(original,cmd('shelf',{shelf}));
 assert.equal(s.shelves[0].code,'A-01');assert.equal(s.products[0].location,'A-01');
 const assigned=applyCommand(s,cmd('shelf-assign',{assignment:{shelfId:shelf.id,productIds:['p2','p3']}},'shelf-command-002'));
 assert.equal(assigned.products[1].location,'A-01');assert.deepEqual(assigned.batches,original.batches);assert.deepEqual(assigned.movements,original.movements);
 const renamed=applyCommand(assigned,cmd('shelf',{shelf:{...shelf,code:'Z-09'}},'shelf-command-003'));
 assert.deepEqual(renamed.products.slice(0,3).map(p=>p.location),['Z-09','Z-09','Z-09']);assert.equal(parseShelfQR(shelfQR(shelf.id)),renamed.shelves[0].id);
 const c=cmd('shelf',{shelf:{...shelf,code:'Z-09'}},'shelf-command-003');assert.equal(applyCommand(renamed,c),renamed);assert.deepEqual(renamed.batches,original.batches);
});
test('Invalid or ambiguous shelf changes fail atomically',()=>{
 const s=applyCommand(initialInventory(),cmd('shelf',{shelf})),before=JSON.stringify(s);
 for(const c of [cmd('shelf',{shelf:{...shelf,id:'shelf-test-002',code:' A-01 '}},'shelf-invalid-001'),cmd('shelf',{shelf:{...shelf,code:'B-02'}},'shelf-invalid-002'),cmd('shelf-assign',{assignment:{shelfId:shelf.id,productIds:['p1','missing']}},'shelf-invalid-003'),cmd('shelf-assign',{assignment:{shelfId:'unknown',productIds:['p1']}},'shelf-invalid-004'),cmd('shelf',{shelf:{...shelf,code:''}},'shelf-invalid-005')])assert.throws(()=>applyCommand(s,c));
 assert.equal(JSON.stringify(s),before);
 for(const raw of ['https://evil.test','ECZANE:SHELF:bad','1234567890123','ECZANE:SHELF:../../other'])assert.equal(parseShelfQR(raw),null);
});
test('Printed shelf QR survives actual QR encode/decode including quiet zone',()=>{
 const text=shelfQR(shelf.id),hints=new Map([[EncodeHintType.MARGIN,4]]),m=new QRCodeWriter().encode(text,BarcodeFormat.QR_CODE,320,320,hints),pixels=new Int32Array(m.getWidth()*m.getHeight());
 for(let y=0;y<m.getHeight();y++)for(let x=0;x<m.getWidth();x++)pixels[y*m.getWidth()+x]=m.get(x,y)?0:0xffffff;
 const result=new MultiFormatReader().decodeWithState(new BinaryBitmap(new HybridBinarizer(new RGBLuminanceSource(pixels,m.getWidth(),m.getHeight()))));assert.equal(result.getText(),text);
 const small=new QRCodeWriter().encode(text,BarcodeFormat.QR_CODE,0,0,hints);assert.ok(small.getWidth()>20);
});
