import test from 'node:test';
import assert from 'node:assert/strict';
import Excel from 'exceljs';
import {readExcelSheets} from '../lib/read-excel.ts';
test('Excel keeps text barcodes, numeric zero masks, dates and saved formula values across sheets',async()=>{const book=new Excel.Workbook(),first=book.addWorksheet('Merkez'),second=book.addWorksheet('Şube');first.addRow(['code','expiry','qty']);first.addRow(['08691234567890',new Date('2027-02-28T00:00:00Z'),{formula:'2+3',result:5}]);second.addRow(['code','name']);second.addRow([123,'Ürün']);second.getCell('A2').numFmt='00000000';const buffer=await book.xlsx.writeBuffer();const sheets=await readExcelSheets(buffer);assert.equal(sheets[0].rows[1][0],'08691234567890');assert.equal(sheets[0].rows[1][1],'2027-02-28');assert.equal(sheets[0].rows[1][2],'5');assert.equal(sheets[1].rows[1][0],'00000123')});
test('Oversized worksheets are rejected before preview',async()=>{const book=new Excel.Workbook(),sheet=book.addWorksheet('Large');for(let i=0;i<102;i++)sheet.addRow(['x']);await assert.rejects(readExcelSheets(await book.xlsx.writeBuffer()))});
