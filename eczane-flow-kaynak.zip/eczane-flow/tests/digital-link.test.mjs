import test from 'node:test';
import assert from 'node:assert/strict';
import {gtinStatus} from '../lib/gtin.ts';
import {parseCode,initialInventory} from '../lib/inventory.ts';
import {inspectScan} from '../lib/scan-result.ts';
import {addOperationScan} from '../lib/operation-scan.ts';
const url='https://id.gs1.org/01/09506000134352/10/LOT%2F7/21/SERIAL42?17=271231';
test('GTIN lengths, leading zeroes and changed digits are checked while internal codes survive',()=>{
 for(const code of ['96385074','036000291452','4006381333931','09506000134352']){assert.equal(gtinStatus(code),'valid');assert.equal(gtinStatus(code.slice(0,-1)+(Number(code.at(-1))+1)%10),'invalid')}
 assert.equal(gtinStatus('DEMO001'),'internal');assert.equal(gtinStatus('123456789'),'internal');assert.equal(parseCode('12345678').code,'12345678');
});
test('Product Digital Link reaches receipt with lot, serial and expiry intact',()=>{
 const parsed=parseCode(url);assert.deepEqual(parsed,{code:'09506000134352',lot:'LOT/7',serial:'SERIAL42',expiry:'2027-12-31'});assert.equal(inspectScan(url).kind,'product');
 const state=initialInventory();state.products[0].code=parsed.code;state.batches=[];const lines=addOperationScan(state,[],url,'receive');assert.equal(lines[0].lot,'LOT/7');assert.equal(lines[0].serial,'SERIAL42');assert.equal(state.batches.length,0);
});
test('Unrelated links, ambiguous fields, malformed dates and invalid GTIN cannot become product QR data',()=>{
 for(const bad of ['https://example.com/hello',url.replace('134352','134353'),url+'&17=281231',url.replace('271231','271332'),url.replace('/10/LOT%2F7','/10/X/10/Y'),url.replace('SERIAL42','%ZZ'),url.replace('SERIAL42','%00'),url+'&21=OTHER',url+'#fragment','javascript:alert(1)'])assert.throws(()=>parseCode(bad));
});
