import test from 'node:test';
import assert from 'node:assert/strict';
import {parseCsv} from '../lib/stock-import.ts';
test('CSV preserves leading zeros, escaped quotes and multiline cells',()=>{assert.deepEqual(parseCsv('\uFEFFcode;name\r\n08691234;"Bir; iki"\r\n08691235;"A ""B""\nC"'),[['code','name'],['08691234','Bir; iki'],['08691235','A "B"\nC']])});
test('CSV rejects incomplete quoting and oversized batches',()=>{assert.throws(()=>parseCsv('code,name\n123,"abc'));assert.throws(()=>parseCsv('code,name\n'+'123,abc\n'.repeat(101)),/ROWS/)});
