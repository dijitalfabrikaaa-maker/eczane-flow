import test from 'node:test';
import assert from 'node:assert/strict';
import {createReadAcknowledgement} from '../lib/notification-read.ts';
import {personalNotifications} from '../lib/personal-notifications.ts';
import {initialInventory,applyCommand} from '../lib/inventory.ts';
import {activeAlertKeys} from '../lib/stock-alerts.ts';

test('Failed acknowledgement is retryable; overlapping requests do not race',async()=>{
 const read=createReadAcknowledgement();let release,calls=0;
 const first=read(['a','a'],keys=>{calls++;assert.deepEqual(keys,['a']);return new Promise(r=>release=r)});
 await Promise.resolve();assert.equal(await read(['b'],async()=>{calls++;return true}),false);
 release(false);assert.equal(await first,false);assert.equal(calls,1);
 assert.equal(await read(['a'],async()=>{throw Error('offline')}),false);
 assert.equal(await read(['a'],async()=>true),true);
});
test('Reading a task survives reload for its viewer without marking another employee read',()=>{
 const now=new Date(),s=initialInventory(now);s.products=[];s.batches=[];
 const task={id:'task-a',title:'Raf kontrolü',assignee:'one',createdBy:'owner',priority:'urgent',due:new Date(now.getTime()-1000).toISOString(),createdAt:now.toISOString()};
 s.tasks=[task,{...task,id:'task-b',assignee:'two'}];
 const view=user=>({...s,...personalNotifications(s,user,user==='owner')});
 assert.deepEqual(activeAlertKeys(view('one')),['task:task-a']);
 const n=applyCommand(view('one'),{id:'read-task-0001',kind:'read-alerts',revision:0,alertKeys:['task:task-a']},now);
 s.notificationReads={one:n.readAlerts};
 assert.deepEqual(activeAlertKeys(view('one')).filter(k=>!view('one').readAlerts.includes(k)),[]);
 assert.deepEqual(view('two').readAlerts,[]);assert.deepEqual(activeAlertKeys(view('two')),['task:task-b']);
 assert.equal(view('owner').tasks.length,2);
 s.tasks[0].completedAt=now.toISOString();assert.deepEqual(activeAlertKeys(view('one')),[]);
});
