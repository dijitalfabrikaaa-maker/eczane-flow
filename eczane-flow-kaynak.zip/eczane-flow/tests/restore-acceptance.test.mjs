import test from 'node:test';import assert from 'node:assert/strict';
import {initialInventory} from '../lib/inventory.ts';
import {restoreSnapshot} from '../lib/business.ts';
import {allowedBranches} from '../lib/network.ts';
import {restoreRequest} from '../lib/restore-request.ts';
test('An acknowledged restore retry succeeds with old revision; a new stale request cannot restore',()=>{
 const v={action:'restore',id:'backup-1',commandId:'restore-0001',revision:3,note:'Test',confirm:'GERİ YÜKLE'};
 assert.equal(restoreRequest(v,3,[]),'ready');assert.equal(restoreRequest(v,4,[v.commandId]),'completed');
 assert.throws(()=>restoreRequest({...v,commandId:'restore-0002'},4,[v.commandId]),/CONFLICT/);
 assert.throws(()=>restoreRequest({...v,confirm:''},4,[v.commandId]),/INVALID/);
});
test('Business recovery preserves current branch access and role templates, including explicit denial',()=>{
 const current=initialInventory(),old=structuredClone(current),inv=initialInventory();
 old.network={branches:[{id:'branch-001',name:'Şube',inventory:inv}],transfers:[],access:{revoked:['main','branch-001'],newuser:['branch-001']}};
 current.network={branches:[],transfers:[],access:{revoked:[],newuser:['main'],removed:['missing-branch']}};
 old.roleTemplates=[{id:'old-role',name:'Eski',description:'',permissions:['finance.write']}];current.roleTemplates=[];
 const saved={schema:1,company:'owner',state:old},before=JSON.stringify(current);
 const restored=restoreSnapshot(current,saved,'owner','restore-0001');
 assert.deepEqual(allowedBranches(restored,'revoked',false),[]);
 assert.deepEqual(allowedBranches(restored,'newuser',false),['main']);assert.deepEqual(allowedBranches(restored,'removed',false),[]);
 assert.deepEqual(restored.roleTemplates,[]);assert.deepEqual(restored.network.branches[0].inventory.roleTemplates,[]);
 assert.equal(JSON.stringify(current),before);assert.deepEqual(restored.batches,old.batches);
});
test('Restoring a pre-branch backup cannot grant default main access to a denied employee',()=>{
 const old=initialInventory(),current=structuredClone(old);current.network={branches:[],transfers:[],access:{revoked:[],employee:['branch-001']}};
 const restored=restoreSnapshot(current,{schema:1,company:'owner',state:old},'owner','restore-0001');
 assert.deepEqual(allowedBranches(restored,'revoked',false),[]);assert.deepEqual(allowedBranches(restored,'employee',false),[]);
});
