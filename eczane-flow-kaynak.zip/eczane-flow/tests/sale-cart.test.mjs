import test from 'node:test';
import assert from 'node:assert/strict';
import {initialInventory,quantity} from '../lib/inventory.ts';
import {addSaleLine,checkSaleCart} from '../lib/sale-cart.ts';
import {applyBusiness,cashBalance,supplierBalance} from '../lib/business.ts';
const now=new Date('2026-09-09T10:00:00Z');
const command=(kind,extra={})=>({id:crypto.randomUUID(),revision:0,kind,note:'Test',...extra});
function state(){const s=initialInventory(now);s.products=[{...s.products[0],code:'09506000134352',price:500}];s.batches=[{id:'early',productId:'p1',qty:2,serials:[],lot:'EARLY',expiry:'2026-10-01'},{id:'late',productId:'p1',qty:3,serials:[],lot:'LATE',expiry:'2026-12-31'}];s.suppliers=[{id:'supplier-001',name:'Depot',phone:'',email:'',contact:'',city:''}];return s}
test('Repeated scans merge and move to the next eligible lot without exceeding stock',()=>{
 const s=state();let cart=[];for(let i=0;i<5;i++)cart=addSaleLine(s,cart,s.products[0].code,now);
 assert.deepEqual(cart.map(l=>[l.lot,l.qty]),[['EARLY',2],['LATE',3]]);
 assert.throws(()=>addSaleLine(s,cart,s.products[0].code,now),/STOCK/);assert.equal(quantity(s,'p1'),5);
 assert.equal(checkSaleCart(s,[{...cart[0],qty:3}],now),'STOCK');
});
test('GS1 serial chooses its exact lot, duplicate or nonexistent serial cannot be sold',()=>{
 const s=state();s.batches[1].serials=['SER123'];
 const raw='(01)09506000134352(17)261231(10)LATE(21)SER123';
 const cart=addSaleLine(s,[],raw,now);assert.equal(cart[0].lot,'LATE');assert.equal(cart[0].serial,'SER123');
 assert.throws(()=>addSaleLine(s,cart,raw,now),/DUPLICATE/);
 assert.throws(()=>addSaleLine(s,[],raw.replace('SER123','MISSING'),now),/SERIAL/);
 assert.throws(()=>addSaleLine(s,[],raw.replace('261231','270131'),now),/SERIAL/);
 const n=applyBusiness(s,command('sale',{lines:cart,method:'card'}),now);assert.equal(n.batches[1].serials.length,0);assert.equal(n.batches[1].qty,2);
});
test('Expired lots and serial-only stock never turn into an untracked cart line',()=>{
 const s=state();s.batches[0].expiry='2026-09-08';s.batches[1].serials=['S1','S2','S3'];
 assert.throws(()=>addSaleLine(s,[],s.products[0].code,now),/SERIAL_REVIEW/);
 assert.throws(()=>addSaleLine(s,[],'99999999999999',now),/UNKNOWN_PRODUCT/);
});
test('Receipt → cart → sale → cash close → correction keeps stock, debt and cash consistent',()=>{
 let s=state();const initialQty=quantity(s,'p1');
 const receive=command('purchase',{supplierId:'supplier-001',reference:'FLOW-001',lines:[{productId:'p1',qty:4,lot:'EARLY',expiry:'2026-10-01',unitCost:200}]});
 s=applyBusiness(s,receive,now);assert.equal(quantity(s,'p1'),initialQty+4);assert.equal(supplierBalance(s,'supplier-001'),800);
 let cart=[];for(let i=0;i<3;i++)cart=addSaleLine(s,cart,s.products[0].code,now);
 const sale=command('sale',{lines:cart,method:'cash'});s=applyBusiness(s,sale,now);
 assert.equal(quantity(s,'p1'),initialQty+1);assert.equal(cashBalance(s),1500);assert.equal(applyBusiness(s,sale,now),s);
 s=applyBusiness(s,command('payment',{supplierId:'supplier-001',amount:800,method:'cash'}),now);
 assert.equal(supplierBalance(s,'supplier-001'),0);assert.equal(cashBalance(s),700);
 s=applyBusiness(s,command('close',{counted:700}),now);assert.equal(cashBalance(s),700);
 assert.throws(()=>applyBusiness(s,command('reverse',{targetId:sale.id}),now),/CASH/);
 assert.equal(quantity(s,'p1'),initialQty+1);
 s=applyBusiness(s,command('cash-adjustment',{amount:800}),now);
 s=applyBusiness(s,command('reverse',{targetId:sale.id}),now);assert.equal(quantity(s,'p1'),initialQty+4);assert.equal(cashBalance(s),0);
});
