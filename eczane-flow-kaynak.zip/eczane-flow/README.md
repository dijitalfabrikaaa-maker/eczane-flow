# Eczane Flow / Katvio

Türkiye ve Azerbaycan için geliştirilen, TR / AZ / RU arayüzlü eczane yönetim modülü. Katvio çok modüllü platformunun ilk modülüdür.

## Mevcut kapsam

- Mobil/PWA ve masaüstü kullanım; kamera, fotoğraf ve klavye modundaki USB/Bluetooth okuyucularla barkod/GS1 karekod işleme.
- Mal kabul, seri/lot/miat takibi, stok sayımı ve gerekçeli stok çıkışı.
- Hızlı satış, maliyet ve satış fiyatı, tahsilat, kasa, cari hesap, iadeler ve siparişler.
- Raf tanımları, raf QR etiketleri, kapasite, yerleşim ve planlı raf sayımı.
- Firma/personel yetkileri, şubeler, stok transferleri, onay merkezi ve denetim kayıtları.
- Kalıcı işlem taslakları, stok rezervasyonu, tedarikçi karşılaştırması, alım bütçesi.
- Tarihli fiyat planları, düşük marj onayı, raporlar ve dışa aktarma.
- Fotoğraf/belge yükleme, yedek kayıtları ve kontrollü geri yükleme altyapısı.

Bu liste uygulanan kod kapsamıdır; bütün cihaz ve üretim kabul senaryolarının tamamlandığı anlamına gelmez. Resmî reçete/İTS/ÜTS ve mali belge bağlantıları tamamlanmış değildir. Kart ödeme kaydı gerçek POS tahsilatı yapmaz. AI yorumları ayrıca sağlayıcı yapılandırması gerektirir; Resend ayrı alan adı belirlenene kadar beklemededir.

## Teknik yapı

React 19, TypeScript, Vinext/Vite, Tailwind ve Cloudflare Workers. SQL verileri D1, dosyalar R2 üzerinden tutulur. `.openai/hosting.json` mevcut Sites projesinin kimliğini ve mantıksal bağlantı adlarını içerir; bir erişim anahtarı değildir.

Stok ve ticari durum firma başına sürümlü JSON olarak `inventory_workspaces` içinde saklanır; şubeler bu durumun altındadır. Diğer tablolar personel, denetim, taslak ve belge metaverilerini tutar. Revizyon karşılaştırması ve işlem kimlikleri eşzamanlı çakışmaları ve tekrar yazmayı kontrol eder. Bu yapı sınırsız ölçek kabulü değildir.

Kimlik, mevcut barındırmanın doğruladığı kullanıcı üzerinden alınır. GitHub'a kopyalamak bağımsız bir kullanıcı giriş altyapısı kurmaz. Başka barındırmaya taşınırken kimlik doğrulama sınırı ayrıca uyarlanmalıdır; istemciden gelen kullanıcı başlıklarına güvenilmemelidir.

## Kurulum ve kontroller

Node.js 22.13 veya üstü, npm ve proje betikleri için Bash/Linux ortamı (Windows'ta WSL) gerekir. Paket sürümleri `package-lock.json` ile sabitlenmiştir.

```bash
npm ci
npx tsc --noEmit
node --test tests/*.test.mjs
npm run build
```

`npm run dev` geliştirme sunucusunu başlatır. Geliştirme çalıştırmak, Sites kimliğini veya canlı D1/R2 verilerini otomatik sağlamaz. `npm run db:generate` yalnızca veritabanı şeması değişikliklerinde kullanılır. Mevcut Sites dağıtımı Sites yayın akışıyla yönetilir; GitHub'a push tek başına canlıya yayın yapmaz.

## Kaynak dizinleri

| Dizin | İçerik |
| --- | --- |
| `app/` | Sayfalar, API yolları ve ortak stiller |
| `components/` | Eczane ekranları ve arayüz bileşenleri |
| `lib/` | Stok, satış, yetki, fiyat ve işlem kuralları |
| `db/` | SQL şema tanımları |
| `tests/` | İş kuralları testleri |
| `public/` | Marka, PWA ve statik dosyalar |
| `scripts/`, `build/`, `worker/` | Kurulum, derleme ve çalışma ortamı |
| `docs/` | Yol haritaları, denetimler ve kabul kayıtları |

## Dokümantasyon

- [Gelişim fazları](docs/gelisim-fazlari.md)
- [Okutma odaklı 30 geliştirme](docs/okutma-odakli-30-gelistirme.md)
- [Web/mobil kabul matrisi](docs/web-mobil-kabul-matrisi.md)
- [İşlev denetimi](docs/functional-audit.md)
- [Düzeltme ve kabul kayıtları](docs/2026-09-10-duzeltme-kabul.md)
- [20 geliştirme önerisi](docs/2026-09-10-yeni-20-oneri.md)
- [20 maddenin uygulama durumu](docs/2026-09-10-yirmi-madde-uygulama.md)
- [GitHub aktarım ve geliştirme düzeni](docs/github-aktarim.md)

Tarihli belgeler önceki aşamaların kayıtlarını da içerir; güncel durum değerlendirilirken en yeni bölüm esas alınmalıdır.

## Doğrulama ve açık işler

Fiyat/marj paketinde 126 otomatik test geçti. Son mobil yerleşim değişikliğinde TypeScript ve üretim derlemesi geçti; gerçek telefon görsel kabulü yapılmadı. Gerçek okuyucu, iki gerçek kullanıcıyla eşzamanlı kullanım ve barındırılan sistemde yedekten dönüş kabulü açıktır.

20 özellik listesindeki kalan kapsam: fatura OCR, şubeler arası dengeleme, sezonluk stok hedefleri, kasiyer vardiya devri, konsinye stok, mükerrer kart birleştirme ve ürün birim dönüşümü.

## Kod ile canlı verinin ayrımı

Bu depo kaynak kodudur. Canlı veritabanı, kullanıcı kayıtları, yüklenen ilaç fotoğrafları, faturalar, yedekler ve servis anahtarları GitHub'a dahil edilmez. Bunlar için ayrı ve yetkili bir veri taşıma süreci gerekir. `.env*`, çalışma ortamı, bağımlılıklar ve derleme çıktıları `.gitignore` ile dışarıda tutulur.
