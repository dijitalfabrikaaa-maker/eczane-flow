import { integer, sqliteTable, text, primaryKey, index } from 'drizzle-orm/sqlite-core';
export const workspaces = sqliteTable('inventory_workspaces', {
 owner: text('owner').primaryKey(),
 state: text('state').notNull(),
 revision: integer('revision').notNull().default(0),
 updatedAt: text('updated_at').notNull(),
});

export const members=sqliteTable('company_members',{company:text('company').notNull(),user:text('user').notNull(),name:text('name').notNull(),permissions:text('permissions').notNull(),active:integer('active').notNull().default(1)},t=>[primaryKey({columns:[t.company,t.user]}),index('members_user').on(t.user)]);
export const audits=sqliteTable('company_audits',{id:text('id').primaryKey(),company:text('company').notNull(),actor:text('actor').notNull(),action:text('action').notNull(),note:text('note').notNull(),date:text('date').notNull(),revision:integer('revision').notNull()},t=>[index('audits_company').on(t.company,t.revision)]);
export const backups=sqliteTable('company_backups',{id:text('id').primaryKey(),company:text('company').notNull(),key:text('key').notNull(),date:text('date').notNull(),revision:integer('revision').notNull()},t=>[index('backups_company').on(t.company,t.date)]);
export const documents=sqliteTable('company_documents',{id:text('id').primaryKey(),company:text('company').notNull(),name:text('name').notNull(),mime:text('mime').notNull(),date:text('date').notNull()},t=>[index('documents_company').on(t.company)]);
export const operationDrafts=sqliteTable('operation_drafts',{scope:text('scope').notNull(),user:text('user').notNull(),key:text('key').notNull(),body:text('body').notNull(),version:integer('version').notNull().default(1),updatedAt:text('updated_at').notNull()},t=>[primaryKey({columns:[t.scope,t.user,t.key]})]);

export const aiUsage=sqliteTable('ai_usage',{company:text('company').notNull(),day:text('day').notNull(),requests:integer('requests').notNull().default(0)},t=>[primaryKey({columns:[t.company,t.day]})]);

export const scanQuality=sqliteTable('scan_quality',{scope:text('scope').notNull(),id:text('id').notNull(),actor:text('actor').notNull(),date:text('date').notNull(),source:text('source').notNull(),mode:text('mode').notNull(),outcome:text('outcome').notNull(),elapsedMs:integer('elapsed_ms').notNull()},t=>[primaryKey({columns:[t.scope,t.id]}),index('scan_quality_scope_date').on(t.scope,t.date)]);
