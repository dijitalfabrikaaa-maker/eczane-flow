import {getChatGPTUser,chatGPTSignInPath,chatGPTSignOutPath} from '@/app/chatgpt-auth';
import {PharmacyLogin} from '@/components/pharmacy-login';
export const dynamic='force-dynamic';
export default async function Login(){const user=await getChatGPTUser();return <PharmacyLogin email={user?.email||''} signIn={chatGPTSignInPath('/eczane')} signOut={chatGPTSignOutPath('/giris')}/>}
