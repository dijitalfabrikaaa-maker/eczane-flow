import {requireChatGPTUser} from '@/app/chatgpt-auth';
import PharmacyWorkspace from '@/components/pharmacy-workspace';
export const dynamic='force-dynamic';
export default async function Eczane(){await requireChatGPTUser('/eczane');return <PharmacyWorkspace/>}
