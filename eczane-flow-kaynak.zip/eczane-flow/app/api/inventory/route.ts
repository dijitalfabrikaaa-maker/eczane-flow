import {queueApproval} from '@/lib/approval-server';
import {applyCommand,type Command} from '@/lib/inventory';
import {commandPermission,requirePermission,recordStockSale} from '@/lib/business';
import {context,reply,result,failure,checkMutation,commit} from '@/lib/company-server';
export async function GET(r:Request){try{const c=await context(r);return reply({...result(c),viewer:{...result(c).viewer,email:r.headers.get('oai-authenticated-user-email')||''}})}catch(e){return failure(e)}}
export async function POST(r:Request){try{checkMutation(r);const raw=await r.text();if(raw.length>200000)throw Error('INVALID');const cmd=JSON.parse(raw) as Command,c=await context(r,commandPermission(cmd));
 if(cmd.product&&((cmd.product.price||0)!==0||cmd.product.cost!==undefined))requirePermission(c.permissions,'finance.write');
 if(cmd.draft?.lines.some(l=>l.sale||l.unitCost!==undefined||l.unitPrice!==undefined))requirePermission(c.permissions,'finance.write');
 if(cmd.lines?.some(l=>l.sale||l.unitCost!==undefined||l.unitPrice!==undefined)||cmd.settings?.cost!==undefined||cmd.settings?.price!==undefined)requirePermission(c.permissions,'finance.write');
 if(c.state.applied.includes(cmd.id))return reply(result(c));if(cmd.revision!==c.revision)return reply({error:'CONFLICT',...result(c)},409);
 const queued=await queueApproval(c,'inventory',cmd);if(queued)return queued;
 if(cmd.kind==='import'){const bytes=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(JSON.stringify(cmd.rows?.map(r=>[r.code,r.name,r.detail,r.category,r.location,r.lot,r.expiry,r.qty,r.min]))));cmd.importHash=Array.from(new Uint8Array(bytes)).map(b=>b.toString(16).padStart(2,'0')).join('')}
 const input=structuredClone(c.state);if(cmd.kind==='read-alerts')input.readAlerts=input.notificationReads?.[c.user]||[];const next=recordStockSale(applyCommand(input,cmd,new Date(),{actor:c.user}),cmd);if(cmd.kind==='read-alerts'){next.notificationReads||={};next.notificationReads[c.user]=next.readAlerts||[]}return reply(await commit(c,next,cmd.id,cmd.kind,cmd.note||cmd.hold?.note||cmd.settings?.productId||''));}catch(e){return failure(e)}}
