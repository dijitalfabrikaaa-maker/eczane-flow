import {context,reply,failure,checkMutation} from '@/lib/company-server';
import {database} from '@/lib/storage';
import {cleanScanQuality} from '@/lib/scan-quality';
export async function GET(r:Request){try{const c=await context(r),all=c.permissions.includes('reports.read'),cutoff=new Date(Date.now()-30*86400000).toISOString();
 const rows=await database().prepare('SELECT id,date,source,mode,outcome,elapsed_ms FROM scan_quality WHERE scope=? AND date>=? AND (?=1 OR actor=?) ORDER BY date DESC LIMIT 500').bind(c.scope,cutoff,all?1:0,c.user).all();
 return reply({rows:rows.results,all});}catch(e){return failure(e)}}
export async function POST(r:Request){try{checkMutation(r);const raw=await r.text();if(raw.length>1000)throw Error('INVALID');const v=cleanScanQuality(JSON.parse(raw)),c=await context(r),db=database(),date=new Date().toISOString();
 // Atomic daily limit; duplicate retries do not produce another row.
 const inserted=await db.prepare('INSERT OR IGNORE INTO scan_quality(scope,id,actor,date,source,mode,outcome,elapsed_ms) SELECT ?,?,?,?,?,?,?,? WHERE (SELECT COUNT(*) FROM scan_quality WHERE scope=? AND actor=? AND date>=?)<1000').bind(c.scope,v.id,c.user,date,v.source,v.mode,v.outcome,v.elapsedMs,c.scope,c.user,date.slice(0,10)).run();
 if(!inserted.meta.changes){const old=await db.prepare('SELECT id FROM scan_quality WHERE scope=? AND id=?').bind(c.scope,v.id).first();if(!old)return reply({error:'RATE_LIMIT'},429);}
 await db.prepare('DELETE FROM scan_quality WHERE scope=? AND (date<? OR id NOT IN (SELECT id FROM scan_quality WHERE scope=? ORDER BY date DESC LIMIT 10000))').bind(c.scope,new Date(Date.now()-30*86400000).toISOString(),c.scope).run();
 return reply({saved:true});}catch(e){return failure(e)}}
