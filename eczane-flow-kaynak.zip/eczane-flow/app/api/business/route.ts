import {isHeldSupplierReturn} from '@/lib/commerce';
import {queueApproval} from '@/lib/approval-server';
import {applyBusiness,type BusinessCommand} from '@/lib/business';
import {context,reply,result,failure,checkMutation,commit} from '@/lib/company-server';
import {database} from '@/lib/storage';
export async function POST(r:Request){try{checkMutation(r);const raw=await r.text();if(raw.length>200000)throw Error('INVALID');const cmd=JSON.parse(raw) as BusinessCommand,c=await context(r,cmd.kind==='company'?'team.write':'finance.write');if(c.state.applied.includes(cmd.id))return reply(result(c));if(cmd.revision!==c.revision)throw Error('CONFLICT');if(cmd.documentId&&!await database().prepare('SELECT id FROM company_documents WHERE company=? AND id=?').bind(c.scope,cmd.documentId).first())throw Error('INVALID');
 if((cmd.kind==='reverse'||cmd.kind==='reverse-stock')&&!c.permissions.includes('audit.read'))throw Error('FORBIDDEN');
 if(['sale','purchase-return'].includes(cmd.kind)&&!c.permissions.includes('out.write')||['purchase','sale-return','order','order-split'].includes(cmd.kind)&&!c.permissions.includes('receive.write'))throw Error('FORBIDDEN');
 if(isHeldSupplierReturn(c.state,cmd)&&!c.permissions.includes('approval.write'))throw Error('FORBIDDEN');
 const queued=await queueApproval(c,'business',cmd);if(queued)return queued;
 return reply(await commit(c,applyBusiness(c.state,cmd),cmd.id,cmd.kind,cmd.note||cmd.name||''));}catch(e){return failure(e)}}
