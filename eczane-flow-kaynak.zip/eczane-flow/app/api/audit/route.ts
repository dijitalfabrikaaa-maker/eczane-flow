import {context,reply,failure} from '@/lib/company-server';
import {database} from '@/lib/storage';
export async function GET(r:Request){try{const c=await context(r,'audit.read');const before=Number(new URL(r.url).searchParams.get('before')||Date.now()+1);if(!Number.isFinite(before))throw Error('INVALID');return reply({rows:(await database().prepare('SELECT * FROM company_audits WHERE company=? AND date<? ORDER BY date DESC LIMIT 100').bind(c.scope,new Date(before).toISOString()).all()).results})}catch(e){return failure(e)}}
