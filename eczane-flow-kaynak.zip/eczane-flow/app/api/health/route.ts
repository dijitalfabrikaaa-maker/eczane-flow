import {context,reply,failure} from '@/lib/company-server';import {inventoryHealth} from '@/lib/inventory-health';
export async function GET(r:Request){try{const c=await context(r,'audit.read');return reply({checkedAt:new Date().toISOString(),branch:c.branch,revision:c.revision,...inventoryHealth(c.state)})}catch(e){return failure(e)}}
