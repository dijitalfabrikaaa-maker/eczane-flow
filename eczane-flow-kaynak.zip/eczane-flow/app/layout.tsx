import {PwaRegistration} from "@/components/pwa-registration";
import type { Metadata, Viewport } from "next";
import "./globals.css";

export const viewport: Viewport = {width:"device-width",initialScale:1,viewportFit:"cover"};

export const metadata: Metadata = {
  title: "Katvio — İşinizin bütün parçaları",
  description: "Türkiye ve Azerbaycan için modüler işletme yönetimi. Eczane, stok ve günlük operasyonlarınız tek çalışma alanında.",
  manifest: "/manifest.webmanifest",
  appleWebApp: {capable: true, title: "Katvio", statusBarStyle: "default"},
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
    apple: "/brand/icon-192.png",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="tr">
      <body className="antialiased">{children}<PwaRegistration/></body>
    </html>
  );
}
