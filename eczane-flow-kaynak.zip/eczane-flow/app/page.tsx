import {KatvioFront} from '@/components/katvio-front';
export default function Page(){return <KatvioFront/>}
