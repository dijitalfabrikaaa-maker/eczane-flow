export type Task={id:string;title:string;assignee:string;priority:'normal'|'urgent';due:string;createdBy:string;createdAt:string;completedAt?:string;completedBy?:string};
export function dueTasks(tasks:Task[],now=new Date()){return tasks.filter(t=>!t.completedAt&&t.due<=now.toISOString()).sort((a,b)=>(a.priority==='urgent'?-1:1)-(b.priority==='urgent'?-1:1)||a.due.localeCompare(b.due))}
