import {personalNotifications} from './personal-notifications';
import {branchState,replaceBranch,allowedBranches,branchList} from './network';
import {database} from './storage';
import {images} from './product-image-storage';
import {initialInventory,type Inventory} from './inventory';
import {permissions,visibleInventory,type Permission} from './business';
export type Context={user:string;company:string;permissions:string[];memberPermissions:string|null;revision:number;state:Inventory;rootState:Inventory;branch:string;scope:string};
export const reply=(v:unknown,status=200)=>Response.json(v,{status,headers:{'Cache-Control':'no-store'}});
export function failure(e:unknown){const error=e instanceof Error?e.message:'UNAVAILABLE';const known=['MARGIN_APPROVAL','BUDGET_APPROVAL','RESERVED_STOCK','RESERVATION_EXPIRED','RESERVATION_LINES','SHELF_CAPACITY','LINE_LIMIT','ORDER_PRICE','SHELF_REQUIRED','SHELF_STOCK','HELD','REJECTED','DUPLICATE_IMPORT','BRANCH','LINKED','RETURN_QTY','ORDER','CUSTOMER','AUTH','FORBIDDEN','INVALID','AMOUNT','SUPPLIER','DUPLICATE_DOCUMENT','BALANCE','CASH','REVERSED','STOCK','SERIAL','EXPIRED','BATCH','DUPLICATE','NOTE','CONFLICT','COUNTRY_LOCKED','SERIAL_REVIEW','PHOTO_LIMIT','DRAFT_EXISTS'];if(!known.includes(error))console.error('Company operation failed',e);return reply({error:known.includes(error)?error:'UNAVAILABLE'},error==='AUTH'?401:error==='FORBIDDEN'?403:error==='CONFLICT'?409:known.includes(error)?400:503)}
export function checkMutation(r:Request){if(r.headers.get('sec-fetch-site')==='cross-site')throw Error('FORBIDDEN')}
export async function context(r:Request,p:Permission='stock.read',selectingBranch=false):Promise<Context>{
 const user=r.headers.get('oai-authenticated-user-id');if(!user)throw Error('AUTH');
 const cookie=r.headers.get('cookie')?.split(';').map(x=>x.trim()).find(x=>x.startsWith('eczane-company='))?.slice(15);const company=cookie?decodeURIComponent(cookie):user;
 let granted:string[]=permissions,memberPermissions:string|null=null;
 if(company!==user){const m=await database().prepare('SELECT permissions FROM company_members WHERE company=? AND user=? AND active=1').bind(company,user).first<{permissions:string}>();if(!m)throw Error('FORBIDDEN');memberPermissions=m.permissions;granted=JSON.parse(m.permissions)}
 if(!granted.includes(p))throw Error('FORBIDDEN');
 if(company===user){const empty=initialInventory();empty.products=[];empty.batches=[];await database().prepare('INSERT OR IGNORE INTO inventory_workspaces(owner,state,revision,updated_at) VALUES(?,?,0,?)').bind(user,JSON.stringify(empty),new Date().toISOString()).run()}
 const row=await database().prepare('SELECT state,revision FROM inventory_workspaces WHERE owner=?').bind(company).first<{state:string;revision:number}>();if(!row)throw Error('FORBIDDEN');const rootState=JSON.parse(row.state) as Inventory;const requested=r.headers.get('cookie')?.split(';').map(x=>x.trim()).find(x=>x.startsWith('eczane-branch='))?.slice(14);let branch=requested?decodeURIComponent(requested):'main';const branches=allowedBranches(rootState,user,user===company);if(!branches.includes(branch)){if(selectingBranch&&branches.length)branch=branches[0];else throw Error('FORBIDDEN')}if(p==='restore.write'&&user!==company)throw Error('FORBIDDEN');const state=branchState(rootState,branch);state.applied=[...new Set([...state.applied,...rootState.applied])];return {user,company,permissions:granted,memberPermissions,state,rootState,branch,scope:branch==='main'?company:company+':'+branch,revision:row.revision};
}
export function result(c:Context,state=c.state,revision=c.revision){const visible=visibleInventory(state,c.permissions);Object.assign(visible,personalNotifications(state,c.user,c.user===c.company));delete visible.notificationReads;return {state:visible,revision,viewer:{id:c.user,company:c.company,owner:c.user===c.company,permissions:c.permissions,branch:c.branch,branches:branchList(c.rootState).filter(b=>allowedBranches(c.rootState,c.user,c.user===c.company).includes(b.id))}}}
export async function snapshot(c:Context){const id=crypto.randomUUID(),date=new Date().toISOString(),key=`backups/${encodeURIComponent(c.company)}/${id}.json`;await images().put(key,new TextEncoder().encode(JSON.stringify({schema:1,company:c.company,state:c.rootState,revision:c.revision})),{httpMetadata:{contentType:'application/json'}});return {id,date,key}}
export async function commit(c:Context,next:Inventory,id:string,action:string,note:string,rootWrite=false){
 const full=rootWrite?next:replaceBranch(c.rootState,c.branch,next);
 const db=database(),backup=await snapshot(c),now=new Date().toISOString();
 const condition='owner=? AND revision=? AND (?=owner OR EXISTS(SELECT 1 FROM company_members WHERE company=owner AND user=? AND active=1 AND permissions=?))';
 const args=[c.company,c.revision,c.user,c.user,c.memberPermissions||''];
 const results=await db.batch([
 db.prepare(`INSERT INTO company_backups(id,company,key,date,revision) SELECT ?,?,?,?,? FROM inventory_workspaces WHERE ${condition}`).bind(backup.id,c.company,backup.key,backup.date,c.revision,...args),
 db.prepare(`INSERT INTO company_audits(id,company,actor,action,note,date,revision) SELECT ?,?,?,?,?,?,? FROM inventory_workspaces WHERE ${condition}`).bind(id,c.scope,c.user,action,note.slice(0,200),now,c.revision+1,...args),
 db.prepare(`UPDATE inventory_workspaces SET state=?,revision=revision+1,updated_at=? WHERE ${condition}`).bind(JSON.stringify(full),now,...args)
 ]);if(!results[2].meta.changes){await images().delete(backup.key);throw Error('CONFLICT')}return result({...c,rootState:full},branchState(full,c.branch),c.revision+1);
}
