/** Modulo 10 validates the identifier, not the authenticity of a medicine. */
export function gtinStatus(code:string):'valid'|'invalid'|'internal'{
 if(!/^(?:\d{8}|\d{12}|\d{13}|\d{14})$/.test(code))return 'internal';
 let sum=0;for(let i=code.length-2,weight=3;i>=0;i--,weight=4-weight)sum+=Number(code[i])*weight;
 return (10-sum%10)%10===Number(code.at(-1))?'valid':'invalid';
}
/** Supported uncompressed Digital Link subset. No URL is fetched or opened. */
export function digitalLinkElements(raw:string):string|null{
 if(!/^https?:\/\//i.test(raw))return null;
 if(raw.length>1000||/[\s\\]/.test(raw)||/%(?![\da-f]{2})/i.test(raw))throw Error('CODE');
 const url=new URL(raw);if(url.username||url.password||url.hash)throw Error('CODE');
 const path=url.pathname.split('/'),start=path.indexOf('01');if(start<0)throw Error('UNRELATED_QR');
 const parts=path.slice(start);if(parts.length%2)throw Error('CODE');
 const fields:Record<string,string>={};let last=-1;
 for(let i=0;i<parts.length;i+=2){const ai=parts[i],order=['01','10','21'].indexOf(ai);if(order<0||order<=last)throw Error('CODE');last=order;fields[ai]=decodeURIComponent(parts[i+1]);}
 for(const [ai,value] of url.searchParams){if(ai!=='17'||fields[ai]!==undefined)throw Error('CODE');fields[ai]=value;}
 if(!/^\d{14}$/.test(fields['01']||'')||gtinStatus(fields['01'])!=='valid')throw Error('GTIN');
 for(const [ai,value] of Object.entries(fields))if(!value||/[()\x00-\x1f]/.test(value)||(ai==='10'||ai==='21')&&value.length>20)throw Error('CODE');
 return ['01','17','10','21'].filter(ai=>fields[ai]!==undefined).map(ai=>`(${ai})${fields[ai]}`).join('');
}
