import {protectReservations} from './reservations.ts';
import {MAX_OPERATION_LINES} from './operation-limits.ts';
import {inventoryHealth} from './inventory-health.ts';
import {consumeShelf} from './stock-controls.ts';
import {reconcilePlacements} from './network.ts';
import {paymentTotals,type Reconciliation} from './reconciliation.ts';
import {applyCommerce,enrichTrade,type Payment,type TradeLine,type Order} from './commerce.ts';
import {applyCommand,type Inventory,type Command,type Line} from './inventory.ts';
export type Permission='approval.write'|'stock.read'|'receive.write'|'count.write'|'out.write'|'catalog.write'|'suppliers.write'|'reports.read'|'reports.export'|'finance.write'|'finance.read'|'audit.read'|'restore.write'|'team.write';
export const permissions:Permission[]=['approval.write','stock.read','receive.write','count.write','out.write','catalog.write','suppliers.write','reports.read','reports.export','finance.write','finance.read','audit.read','restore.write','team.write'];
export type PaymentMethod='cash'|'card'|'bank';
export type Entry={id:string;date:string;kind:'sale'|'purchase'|'payment'|'cash-adjustment'|'stock-correction'|'sale-return'|'purchase-return'|'collection';amount:number;payments?:Payment[];customer?:string;parentId?:string;tradeLines?:TradeLine[];orderId?:string;method?:PaymentMethod;supplierId?:string;reference?:string;due?:string;documentId?:string;note:string;movementIds?:string[];reversedBy?:string;reversalOf?:string};
export type Close={id:string;date:string;opening:number;expected:number;counted:number;difference:number;note:string;lastEntryId:string};
export type Business={reconciliations?:Reconciliation[];company?:{name:string;registration:string};entries:Entry[];closes:Close[];orders?:Order[]};
export type BusinessCommand={marginAcknowledged?:boolean;budgetAcknowledged?:boolean;expectedAt?:string;groups?:{supplierId:string;reference:string;expectedAt:string;lines:Line[]}[];reservationId?:string;id:string;revision:number;from?:string;to?:string;actual?:{cash:number;card:number;bank:number};acceptPriceDifference?:boolean;kind:'order-split'|'reconcile'|'company'|'sale'|'purchase'|'payment'|'cash-adjustment'|'close'|'reverse'|'reverse-stock'|'collection'|'invoice-payment'|'sale-return'|'purchase-return'|'order';payments?:Payment[];customer?:string;orderId?:string;returns?:{lineId:string;qty:number;shelfId?:string}[];name?:string;registration?:string;lines?:Line[];amount?:number;method?:PaymentMethod;supplierId?:string;reference?:string;due?:string;documentId?:string;note?:string;counted?:number;targetId?:string};
export const business=(s:Inventory):Business=>s.business||{entries:[],closes:[]};
export function commandPermission(c:Command):Permission{
 const map:Record<string,Permission>={'hold':'approval.write','receive':'receive.write',count:'count.write',out:'out.write',country:'team.write',supplier:'suppliers.write',profile:'team.write',import:'receive.write',product:'catalog.write','product-settings':'catalog.write','product-photo':'catalog.write','role-template':'team.write','shelf':'catalog.write','shelf-assign':'catalog.write','read-alerts':'stock.read'};
 if(c.kind==='draft')return commandPermission({...c,kind:c.draft?.kind||'receive'});return map[c.kind]||'team.write';
}
export function requirePermission(granted:string[],p:Permission){if(!granted.includes(p))throw Error('FORBIDDEN')}
const text=(v:unknown,max=200,required=false)=>{if(typeof v!=='string'||v.length>max||(required&&!v.trim()))throw Error('INVALID');return v.trim()};
const amount=(n:unknown)=>{if(typeof n!=='number'||!Number.isSafeInteger(n)||n<0||n>100000000)throw Error('AMOUNT');return n};
const method=(m:unknown):PaymentMethod=>{if(m!=='cash'&&m!=='card'&&m!=='bank')throw Error('INVALID');return m};
export function cashBalance(s:Inventory){const b=business(s),last=b.closes.at(-1),idx=last?b.entries.findIndex(e=>e.id===last.lastEntryId):-1;return (last?.counted||0)+b.entries.slice(idx+1).reduce((n,e)=>n+(e.payments?e.payments.filter(p=>p.method==='cash').reduce((n,p)=>n+p.amount,0):e.method==='cash'?e.amount:0),0)}
export function supplierBalance(s:Inventory,id:string){return business(s).entries.filter(e=>e.supplierId===id).reduce((n,e)=>n+(['purchase','purchase-return','payment'].includes(e.kind)?e.amount:0),0)}
export function applyBusiness(state:Inventory,c:BusinessCommand,now=new Date()):Inventory{
 if(!/^[-\w]{8,80}$/.test(c.id))throw Error('INVALID');if(state.applied.includes(c.id))return state;
 if(['order-split','collection','invoice-payment','sale-return','purchase-return','order'].includes(c.kind))return applyCommerce(state,c,now);
 let next=structuredClone(state);next.business=structuredClone(business(next));const b=next.business,date=now.toISOString(),note=text(c.note||'',200,c.kind!=='company');
 if(c.kind==='reconcile'){const validDate=(v:string)=>/^\d{4}-\d{2}-\d{2}$/.test(v)&&Number.isFinite(Date.parse(v))&&new Date(v).toISOString().slice(0,10)===v;if(!c.from||!c.to||!validDate(c.from)||!validDate(c.to)||!/^\d{4}-\d{2}-\d{2}$/.test(c.from)||!/^\d{4}-\d{2}-\d{2}$/.test(c.to)||c.from>c.to||!c.actual||Object.keys(c.actual).length!==3||['cash','card','bank'].some(k=>!Number.isSafeInteger(c.actual![k as 'cash'])||Math.abs(c.actual![k as 'cash'])>100000000))throw Error('INVALID');b.reconciliations||=[];b.reconciliations.push({id:c.id,date,from:c.from,to:c.to,expected:paymentTotals(state,c.from,c.to),actual:c.actual,note})}else if(c.kind==='company'){b.company={name:text(c.name,120,true),registration:text(c.registration||'',80)};}
 else if(c.kind==='sale'||c.kind==='purchase'){
  if(!c.lines?.length||c.lines.length>MAX_OPERATION_LINES)throw Error('INVALID');
  const sale=c.kind==='sale',pay=sale&&c.payments===undefined?method(c.method):undefined;
  if(!sale&&!next.suppliers?.some(s=>s.id===c.supplierId))throw Error('SUPPLIER');
  const ref=!sale?text(c.reference,80,true):'';
  if(!sale&&b.entries.some(e=>e.kind==='purchase'&&!e.reversedBy&&e.supplierId===c.supplierId&&e.reference?.toLocaleLowerCase()===ref.toLocaleLowerCase()))throw Error('DUPLICATE_DOCUMENT');
  if(c.due&&(!/^\d{4}-\d{2}-\d{2}$/.test(c.due)||new Date(c.due).toISOString().slice(0,10)!==c.due))throw Error('INVALID');
  const total=c.lines.reduce((n,l)=>n+l.qty*amount(sale?l.unitPrice:l.unitCost),0);amount(total);
  next=applyCommand(next,{id:c.id,revision:c.revision,kind:sale?'out':'receive',reservationId:sale?c.reservationId:undefined,note,lines:c.lines.map(l=>({...l,sale,supplierId:sale?undefined:c.supplierId}))},now);
  next.business!.entries.push({id:c.id,date,kind:c.kind,amount:total,method:pay,supplierId:sale?undefined:c.supplierId,reference:ref,due:c.due,documentId:c.documentId,note,movementIds:next.movements.filter(m=>m.id.startsWith(c.id+'-')).map(m=>m.id)});
  return enrichTrade(state,next,c);
 }else if(c.kind==='payment'){
  if(!next.suppliers?.some(s=>s.id===c.supplierId))throw Error('SUPPLIER');const n=amount(c.amount);if(!n||n>supplierBalance(next,c.supplierId!))throw Error('BALANCE');
  if(c.method==='cash'&&n>cashBalance(next))throw Error('CASH');b.entries.push({id:c.id,date,kind:'payment',amount:-n,supplierId:c.supplierId,method:method(c.method),note});
 }else if(c.kind==='cash-adjustment'){
  if(typeof c.amount!=='number'||c.amount===0)throw Error('AMOUNT');amount(Math.abs(c.amount));if(c.amount<0&&-c.amount>cashBalance(next))throw Error('CASH');b.entries.push({id:c.id,date,kind:'cash-adjustment',amount:c.amount,method:'cash',note});
 }else if(c.kind==='close'){
  const expected=cashBalance(next),counted=amount(c.counted);if(expected!==counted&&!note)throw Error('NOTE');
  b.closes.push({id:c.id,date,opening:b.closes.at(-1)?.counted||0,expected,counted,difference:counted-expected,note,lastEntryId:b.entries.at(-1)?.id||''});
 }else if(c.kind==='reverse-stock'){
  const m=next.movements.find(m=>m.id===c.targetId);if(!m||next.movements.find(v=>v.productId===m.productId&&v.lot===m.lot)?.id!==m.id||b.entries.some(e=>e.movementIds?.includes(m.id)))throw Error('REVERSED');
  if(m.note.startsWith('Düzeltme:'))throw Error('REVERSED');
  const synthetic={id:'source-'+c.id,date:m.date,kind:'stock-correction' as const,amount:0,note:m.note,movementIds:[m.id]};b.entries.push(synthetic);
  return applyBusiness(next,{...c,kind:'reverse',targetId:synthetic.id},now);
 }else if(c.kind==='reverse'){
  const original=b.entries.find(e=>e.id===c.targetId);if(!original||original.reversedBy||original.reversalOf)throw Error('REVERSED');
  if(original.payments||b.entries.some(e=>e.parentId===original.id)||original.parentId)throw Error('LINKED');
  const moves=next.movements.filter(m=>original.movementIds?.includes(m.id));

  for(const m of moves){const batch=next.batches.find(v=>v.productId===m.productId&&v.lot===m.lot);if(!batch||batch.qty-m.qty<0)throw Error('STOCK');protectReservations(next,batch.id,batch.qty-m.qty,now);if(m.countBefore&&m.countAfter){if(JSON.stringify([...batch.serials].sort())!==JSON.stringify([...m.countAfter].sort())||m.countBefore.some(serial=>next.batches.some(v=>v.id!==batch.id&&v.productId===batch.productId&&v.serials.includes(serial)))||m.countBefore.length>batch.qty-m.qty)throw Error('SERIAL');batch.serials=[...m.countBefore]}else if(m.serial){if(m.qty>0){if(!batch.serials.includes(m.serial))throw Error('SERIAL');batch.serials=batch.serials.filter(x=>x!==m.serial)}else{if(next.batches.some(v=>v.productId===m.productId&&v.serials.includes(m.serial!)))throw Error('SERIAL');batch.serials.push(m.serial)}}else if(m.qty>0&&batch.qty-batch.serials.length<m.qty)throw Error('SERIAL');if(m.kind!=='count'&&m.qty>0)consumeShelf(next,batch.id,{productId:batch.productId,lot:batch.lot,expiry:batch.expiry,qty:m.qty});if(m.qty<0&&m.shelfId&&next.shelves?.some(s=>s.id===m.shelfId)){next.placements||=[];const placement=next.placements.find(p=>p.batchId===batch.id&&p.shelfId===m.shelfId);if(placement)placement.qty-=m.qty;else next.placements.push({batchId:batch.id,shelfId:m.shelfId,qty:-m.qty})}batch.qty-=m.qty;reconcilePlacements(next);next.movements.unshift({...m,id:`${c.id}-${m.id}`,date,qty:-m.qty,kind:m.kind==='count'?'count':m.kind==='receive'?'out':'receive',sale:false,note:`Düzeltme: ${note}`})}
  if(original.method==='cash'&&original.amount>cashBalance(next))throw Error('CASH');
  if(original.kind==='purchase'&&supplierBalance(next,original.supplierId!)<original.amount)throw Error('BALANCE');
  original.reversedBy=c.id;b.entries.push({...original,id:c.id,date,amount:-original.amount,note,reversalOf:original.id,reversedBy:undefined,movementIds:[]});
 }else throw Error('INVALID');next.applied.push(c.id);return next;
}
export function visibleInventory(s:Inventory,granted:string[]):Inventory{
 const n=structuredClone(s);delete n.approvals;if(!granted.includes('finance.read')){delete n.priceSchedules;delete n.purchaseBudgets;if(n.operations)n.operations.offers=[];for(const p of n.products){delete p.cost;p.price=0}for(const b of n.batches)delete b.unitCost;for(const m of n.movements){delete m.unitCost;delete m.unitPrice}if(n.draft)for(const l of n.draft.lines){delete l.unitCost;delete l.unitPrice}delete n.business}
 if(!granted.includes('suppliers.write')&&!granted.includes('finance.read'))n.suppliers=[];return n;
}

export function recordStockSale(next:Inventory,c:Command,now=new Date()){
 if(c.kind!=='out'||!c.lines?.some(l=>l.sale))return next;
 const paid=c.lines.filter(l=>l.sale).reduce((n,l)=>n+l.qty*amount(l.unitPrice),0);amount(paid);
 next.business=structuredClone(business(next));next.business.entries.push({id:c.id,date:now.toISOString(),kind:'sale',amount:paid,method:method(c.paymentMethod),note:c.note||'',movementIds:next.movements.filter(m=>m.id.startsWith(c.id+'-')&&m.sale).map(m=>m.id)});return next;
}

export function restoreSnapshot(current:Inventory,saved:unknown,company:string,id:string):Inventory{
 if(!saved||typeof saved!=='object')throw Error('INVALID');const v=saved as {schema:number;company:string;state:Inventory};
 if(v.schema!==1||v.company!==company||!v.state||!Array.isArray(v.state.products)||!Array.isArray(v.state.batches)||!Array.isArray(v.state.movements)||!Array.isArray(v.state.applied)||!['TR','AZ'].includes(v.state.country))throw Error('INVALID');
 const next=structuredClone(v.state);if([next,...(next.network?.branches||[]).map(b=>b.inventory)].some(s=>inventoryHealth(s).issues.length))throw Error('INVALID');// Restore business records without reviving historical access grants or role templates.
 if(next.network){const valid=new Set(['main',...next.network.branches.map(b=>b.id)]);next.network.access=Object.fromEntries(Object.entries(current.network?.access||{}).map(([user,ids])=>[user,ids.filter(id=>valid.has(id))]));for(const branch of next.network.branches)branch.inventory.roleTemplates=structuredClone(current.network?.branches.find(b=>b.id===branch.id)?.inventory.roleTemplates||[])}
 else if(current.network?.access)next.network={branches:[],transfers:[],access:Object.fromEntries(Object.entries(current.network.access).map(([user,ids])=>[user,ids.filter(id=>id==='main')]))};
 next.roleTemplates=structuredClone(current.roleTemplates||[]);
 next.applied=[...new Set([...current.applied,...(current.network?.branches.flatMap(b=>b.inventory.applied)||[]),...next.applied,id])];return next;
}
