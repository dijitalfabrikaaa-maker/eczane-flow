import {requireOperationCapacity} from './operation-limits.ts';
import {shelfRemaining} from './stock-controls.ts';
import {applyCommand,parseCode,type Inventory,type Line} from './inventory.ts';
import {saleBatches,untrackedAvailable} from './sale-cart.ts';
export function addOperationScan(data:Inventory,lines:Line[],raw:string,kind:'receive'|'out',now=new Date(),options:{financial?:boolean}={}):Line[]{
 const parsed=parseCode(raw),p=data.products.find(p=>p.code.padStart(14,'0')===parsed.code.padStart(14,'0'));
 if(!p)throw Error('UNKNOWN_PRODUCT');
 if(parsed.serial&&(lines.some(l=>l.productId===p.id&&l.serial===parsed.serial)||kind==='receive'&&data.batches.some(b=>b.productId===p.id&&b.serials.includes(parsed.serial!))))throw Error('DUPLICATE');
 if(kind==='out'){
 const eligible=saleBatches(data,p.id,now).filter(b=>(!parsed.lot||b.lot===parsed.lot)&&(!parsed.expiry||b.expiry===parsed.expiry));
 const batch=eligible.find(b=>parsed.serial?b.serials.includes(parsed.serial):untrackedAvailable(b,lines)>0);
 if(!batch)throw Error(parsed.serial?'SERIAL':'STOCK');
 const next=structuredClone(lines),same=next.find(l=>l.productId===p.id&&l.lot===batch.lot&&!l.serial&&!parsed.serial&&(!l.shelfId||shelfRemaining(data,l,next)>0));
 if(same)same.qty++;else next.push({productId:p.id,qty:1,lot:batch.lot,expiry:batch.expiry,serial:parsed.serial});
 requireOperationCapacity(next);
 try{applyCommand(data,{id:'scan-validation',revision:0,kind:'out',note:'Scan validation',lines:next},now)}catch(e){if((e as Error).message!=='SHELF_REQUIRED')throw e}return next;
 }
 // Receipt must not invent a lot or expiry from an arbitrary existing batch.
 if(!parsed.lot||!parsed.expiry)throw Error('BATCH');
 const next=structuredClone(lines),same=next.find(l=>l.productId===p.id&&l.lot===parsed.lot&&!l.serial&&!parsed.serial);
 if(same){if(same.expiry!==parsed.expiry)throw Error('BATCH');same.qty++}else next.push({productId:p.id,qty:1,lot:parsed.lot,expiry:parsed.expiry,serial:parsed.serial,...(options.financial?{unitCost:p.cost}:{})});
 requireOperationCapacity(next);
 applyCommand(data,{id:'scan-validation',revision:0,kind:'receive',note:'Scan validation',lines:next},now);
 return next;
}
