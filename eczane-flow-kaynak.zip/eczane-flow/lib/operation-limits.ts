/** Shared limit for a single atomic receipt, sale, count or draft. */
export const MAX_OPERATION_LINES=100;
export function requireOperationCapacity(lines:unknown[]){if(lines.length>MAX_OPERATION_LINES)throw Error('LINE_LIMIT')}
