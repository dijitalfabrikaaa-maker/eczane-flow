export type DateRange={from:string;to:string};
export const countryZone=(country:string)=>country==='AZ'?'Asia/Baku':'Europe/Istanbul';
export function localDateKey(value:string|Date,zone:string){return new Intl.DateTimeFormat('sv-SE',{timeZone:zone,year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date(value))}
export function shiftDay(day:string,amount:number){const d=new Date(day+'T12:00:00Z');d.setUTCDate(d.getUTCDate()+amount);return d.toISOString().slice(0,10)}
export function inDateRange(day:string,range:DateRange){return !(range.from&&range.to&&range.from>range.to)&&(!range.from||day>=range.from)&&(!range.to||day<=range.to)}
