import {jsPDF} from 'jspdf';
import {autoTable} from 'jspdf-autotable';
export function buildReportPdf({font,title,subtitle,pharmacy,headers,rows,footer}:{font:string;title:string;subtitle:string;pharmacy:string;headers:string[];rows:string[][];footer:string}){
 const doc=new jsPDF({orientation:headers.length>5?'landscape':'portrait',unit:'mm',format:'a4'});
 doc.addFileToVFS('DejaVuSans.ttf',font);doc.addFont('DejaVuSans.ttf','DejaVu','normal');doc.setFont('DejaVu');doc.setProperties({title,subject:subtitle,creator:'Eczane'});
 const width=doc.internal.pageSize.getWidth();doc.setFontSize(10);doc.setTextColor('#52647c');doc.text(pharmacy,14,16);doc.setFontSize(18);doc.setTextColor('#152d4b');const titleLines=doc.splitTextToSize(title,width-28);doc.text(titleLines,14,27);const subY=27+titleLines.length*7;doc.setFontSize(9);const subLines=doc.splitTextToSize(subtitle,width-28);doc.text(subLines,14,subY);
 autoTable(doc,{head:[headers],body:rows,startY:subY+subLines.length*4+6,margin:{left:14,right:14,bottom:20},styles:{font:'DejaVu',fontStyle:'normal',fontSize:8,cellPadding:3,overflow:'linebreak'},headStyles:{fillColor:[40,91,215],fontStyle:'normal',textColor:255},alternateRowStyles:{fillColor:[245,247,251]},rowPageBreak:'avoid'});
 const n=doc.getNumberOfPages();for(let page=1;page<=n;page++){doc.setPage(page);doc.setFont('DejaVu');doc.setFontSize(8);doc.setTextColor('#52647c');const y=doc.internal.pageSize.getHeight()-10;doc.text(footer,14,y);doc.text(`${page} / ${n}`,width-14,y,{align:'right'})}return doc;
}
export async function downloadReportPdf(args:Omit<Parameters<typeof buildReportPdf>[0],'font'>){const r=await fetch('/fonts/DejaVuSans.ttf');if(!r.ok)throw Error('FONT');const bytes=new Uint8Array(await r.arrayBuffer());let binary='';for(let i=0;i<bytes.length;i+=8192)binary+=String.fromCharCode(...bytes.subarray(i,i+8192));buildReportPdf({...args,font:btoa(binary)}).save('eczane-raporu.pdf')}
