/** One acknowledgement request at a time. Failed requests remain retryable. */
export function createReadAcknowledgement(){
 let pending:Promise<boolean>|null=null;
 return async (keys:string[],send:(keys:string[])=>Promise<boolean>):Promise<boolean>=>{
  if(pending)return false;
  const unique=[...new Set(keys)];if(!unique.length)return true;
  const work=Promise.resolve().then(()=>send(unique)).then(v=>v===true,()=>false);
  pending=work;try{return await work}finally{if(pending===work)pending=null}
 };
}
