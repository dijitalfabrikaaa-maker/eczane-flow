export const scanOutcomes=['decoded','invalid','unrelated','permission','missing','busy','unsupported','failed','photo','no-code','cancelled'] as const;
export type ScanOutcome=typeof scanOutcomes[number];
export type ScanQuality={id:string;source:'camera'|'photo'|'reader'|'manual';mode:'auto'|'medicine'|'linear'|'qr';outcome:ScanOutcome;elapsedMs:number};
export function cleanScanQuality(v:unknown):ScanQuality{
 const x=v as ScanQuality;
 if(!x||typeof x.id!=='string'||!/^[-\w]{8,80}$/.test(x.id)||!['camera','photo','reader','manual'].includes(x.source)||!['auto','medicine','linear','qr'].includes(x.mode)||!scanOutcomes.includes(x.outcome)||!Number.isInteger(x.elapsedMs)||x.elapsedMs<0||x.elapsedMs>3600000)throw Error('INVALID');
 return {id:x.id,source:x.source,mode:x.mode,outcome:x.outcome,elapsedMs:x.elapsedMs};
}
export async function recordScanQuality(source:ScanQuality['source'],mode:ScanQuality['mode'],outcome:ScanOutcome,started:number){
 const event=cleanScanQuality({id:crypto.randomUUID(),source,mode,outcome,elapsedMs:Math.min(3600000,Math.max(0,Math.round(performance.now()-started)))});
 try{const r=await fetch('/api/scan-quality',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(event),keepalive:true});window.dispatchEvent(new CustomEvent('scan-quality-status',{detail:r.ok}));}catch{window.dispatchEvent(new CustomEvent('scan-quality-status',{detail:false}));}
}
