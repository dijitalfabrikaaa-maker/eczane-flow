import {isHeld} from './stock-controls.ts';
import {daysLeft,type Inventory} from './inventory.ts';
export function replenishment(state:Inventory,now=new Date()){
 return state.products.map(product=>{const usable=state.batches.filter(b=>b.productId===product.id&&daysLeft(b.expiry,now)>0&&!isHeld(state,b.id)).reduce((n,b)=>n+b.qty,0);return {product,usable,shortage:Math.max(0,product.min-usable)}}).filter(r=>r.shortage>0);
}
export function csvCell(value:string){return '"'+(/^[\s]*[=+@\-]/.test(value)?"'"+value:value).replace(/"/g,'""')+'"'}
