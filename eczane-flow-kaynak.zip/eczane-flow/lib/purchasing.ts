import type {Inventory} from './inventory.ts';
export function purchaseMonth(s:Inventory,now=new Date()){return new Intl.DateTimeFormat('en-CA',{timeZone:s.country==='AZ'?'Asia/Baku':'Europe/Istanbul',year:'numeric',month:'2-digit'}).format(now)}
export function purchaseBudget(s:Inventory,now=new Date()){
 const month=purchaseMonth(s,now),entries=s.business?.entries||[],orders=s.business?.orders||[];
 const spent=entries.filter(e=>['purchase','purchase-return'].includes(e.kind)&&purchaseMonth(s,new Date(e.date))===month).reduce((n,e)=>n+e.amount,0);
 const committed=orders.filter(o=>o.status==='open'&&purchaseMonth(s,new Date(o.date))===month).reduce((n,o)=>n+o.lines.reduce((a,l)=>a+(l.qty-l.received)*l.unitCost,0),0);
 const limit=s.purchaseBudgets?.[month];return {month,spent,committed,used:spent+committed,limit};
}
export function exceedsBudget(before:Inventory,after:Inventory,now=new Date()){const a=purchaseBudget(before,now),b=purchaseBudget(after,now);return b.limit!==undefined&&b.used>b.limit&&b.used>a.used}
export function supplierPerformance(s:Inventory,from='',to='',now=new Date()){
 return (s.business?.orders||[]).filter(o=>(!from||o.date.slice(0,10)>=from)&&(!to||o.date.slice(0,10)<=to)).map(o=>{
 const receipts=(s.business?.entries||[]).filter(e=>e.kind==='purchase'&&e.orderId===o.id&&!e.reversedBy);
 const last=receipts.map(e=>e.date).sort().at(-1),expected=o.expectedAt,finish=o.status==='closed'?last:now.toISOString();
 const lateDays=expected&&finish?Math.max(0,Math.ceil((Date.parse(finish)-Date.parse(expected+'T23:59:59Z'))/86400000)):null;
 const priceDifference=receipts.reduce((n,e)=>n+(e.tradeLines||[]).reduce((a,l)=>a+l.qty*((l.unitCost||0)-(o.lines.find(v=>v.productId===l.productId)?.unitCost||0)),0),0);
 return {order:o,lateDays,priceDifference,remaining:o.lines.reduce((n,l)=>n+l.qty-l.received,0),received:o.lines.reduce((n,l)=>n+l.received,0)};
 });
}
