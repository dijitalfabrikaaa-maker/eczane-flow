import type {Inventory,Line} from './inventory.ts';
export type PriceSchedule={id:string;effectiveAt:string;rows:{productId:string;price:number}[];status:'pending'|'applied'|'cancelled';actor:string;createdAt:string};
export type PricingCommand={id:string;revision:number;kind:'price-schedule'|'price-cancel'|'margin-policy';effectiveAt?:string;rows?:PriceSchedule['rows'];targetId?:string;threshold?:number;enabled?:boolean};
export function effectivePrices(s:Inventory,now=new Date()):Inventory{
 const due=(s.priceSchedules||[]).filter(p=>p.status==='pending'&&Date.parse(p.effectiveAt)<=+now).sort((a,b)=>a.effectiveAt.localeCompare(b.effectiveAt)||a.createdAt.localeCompare(b.createdAt));if(!due.length)return s;
 const n=structuredClone(s);for(const schedule of due){for(const row of schedule.rows){const p=n.products.find(p=>p.id===row.productId);if(p)p.price=row.price}n.priceSchedules!.find(p=>p.id===schedule.id)!.status='applied'}return n;
}
export function applyPricing(s:Inventory,c:PricingCommand,actor:string,now=new Date()):Inventory{
 if(!/^[-\w]{8,80}$/.test(c.id))throw Error('INVALID');if(s.applied.includes(c.id))return s;const n=structuredClone(effectivePrices(s,now));
 if(c.kind==='margin-policy'){if(typeof c.enabled!=='boolean'||!Number.isInteger(c.threshold)||c.threshold!<0||c.threshold!>9999)throw Error('INVALID');n.marginPolicy={enabled:c.enabled,threshold:c.threshold!}}
 else if(c.kind==='price-schedule'){
 const date=Date.parse(c.effectiveAt||'');if(!Number.isFinite(date)||date<=+now||date>+now+366*86400000||!Array.isArray(c.rows)||!c.rows.length||c.rows.length>100||new Set(c.rows.map(r=>r.productId)).size!==c.rows.length||c.rows.some(r=>!n.products.some(p=>p.id===r.productId)||!Number.isSafeInteger(r.price)||r.price<0||r.price>100000000))throw Error('INVALID');
 n.priceSchedules||=[];if(n.priceSchedules.length>=1000)throw Error('INVALID');n.priceSchedules.push({id:c.id,effectiveAt:new Date(date).toISOString(),rows:structuredClone(c.rows),status:'pending',actor,createdAt:now.toISOString()});
 }else if(c.kind==='price-cancel'){const p=n.priceSchedules?.find(p=>p.id===c.targetId);if(!p||p.status!=='pending')throw Error('INVALID');p.status='cancelled'}else throw Error('INVALID');n.applied.push(c.id);return n;
}
export function lowMarginLines(s:Inventory,lines:Line[]){if(!s.marginPolicy?.enabled)return [];return lines.filter(l=>{const b=s.batches.find(b=>b.productId===l.productId&&b.lot===l.lot&&b.expiry===l.expiry);if(b?.unitCost===undefined||l.unitPrice===undefined)return false;return l.unitPrice===0?b.unitCost>0:(l.unitPrice-b.unitCost)*10000<l.unitPrice*s.marginPolicy!.threshold})}
export function marginAction(s:Inventory,lines:Line[],owner:boolean,acknowledged:boolean):'allow'|'queue'|'confirm'{return !lowMarginLines(s,lines).length?'allow':!owner?'queue':acknowledged?'allow':'confirm'}
