import type {Inventory} from './inventory.ts';
export type Offer={id:string;productId:string;supplierId:string;unitCost:number;leadDays:number;termDays:number;validUntil:string;date:string;actor:string};
export type Temperature={id:string;batchId:string;location:string;value:number;min:number;max:number;note:string;date:string;actor:string;outside:boolean};
export type Operations={offers:Offer[];temperatures:Temperature[]};
export type OperationCommand={id:string;revision:number;kind:'offer'|'temperature';productId?:string;supplierId?:string;unitCost?:number;leadDays?:number;termDays?:number;validUntil?:string;batchId?:string;location?:string;value?:number;min?:number;max?:number;note?:string};
export const operations=(s:Inventory):Operations=>s.operations||{offers:[],temperatures:[]};
export const operationPermission=(kind:string)=>kind==='offer'?'finance.write':kind==='temperature'?'catalog.write':null;
function integer(n:unknown,max:number){if(typeof n!=='number'||!Number.isSafeInteger(n)||n<0||n>max)throw Error('INVALID');return n}
function text(s:unknown,max:number){if(typeof s!=='string'||!s.trim()||s.length>max)throw Error('INVALID');return s.trim()}
export function applyOperation(state:Inventory,c:OperationCommand,actor:string,now=new Date()):Inventory{
 if(!/^[-\w]{8,80}$/.test(c.id)||!operationPermission(c.kind))throw Error('INVALID');if(state.applied.includes(c.id))return state;
 const next=structuredClone(state),o=next.operations=structuredClone(operations(state)),date=now.toISOString();
 if(c.kind==='offer'){
  if(!state.products.some(p=>p.id===c.productId)||!state.suppliers?.some(s=>s.id===c.supplierId))throw Error('INVALID');
  const validUntil=text(c.validUntil,10);if(!/^\d{4}-\d{2}-\d{2}$/.test(validUntil)||!Number.isFinite(Date.parse(validUntil))||new Date(validUntil).toISOString().slice(0,10)!==validUntil)throw Error('INVALID');
  if(o.offers.length>=2000)throw Error('INVALID');o.offers.push({id:c.id,productId:c.productId!,supplierId:c.supplierId!,unitCost:integer(c.unitCost,100000000),leadDays:integer(c.leadDays,365),termDays:integer(c.termDays,730),validUntil,date,actor});
 }else{
  if(!state.batches.some(b=>b.id===c.batchId)||[c.value,c.min,c.max].some(v=>typeof v!=='number'||!Number.isFinite(v)||Math.abs(v)>200)||c.min!>=c.max!)throw Error('INVALID');
  if(o.temperatures.length>=10000)throw Error('INVALID');o.temperatures.push({id:c.id,batchId:c.batchId!,location:text(c.location,80),value:c.value!,min:c.min!,max:c.max!,note:text(c.note,200),date,actor,outside:c.value!<c.min!||c.value!>c.max!});
 }
 next.applied.push(c.id);return next;
}
export function compareOffers(s:Inventory,productId:string,day:string){return operations(s).offers.filter(v=>v.productId===productId&&v.validUntil>=day).sort((a,b)=>a.unitCost-b.unitCost||a.leadDays-b.leadDays||b.termDays-a.termDays)}
/** Unknown history is shown separately, never labelled as an old unsold product. */
export function dormantStock(s:Inventory,days:number,now=new Date()){
 const last=new Map<string,string>();for(const m of s.movements)if(m.date<=now.toISOString()&&Number.isFinite(Date.parse(m.date))&&m.date>(last.get(m.productId)||''))last.set(m.productId,m.date);
 return s.products.flatMap(p=>{const batches=s.batches.filter(b=>b.productId===p.id&&b.qty>0),qty=batches.reduce((n,b)=>n+b.qty,0);if(!qty)return [];const date=last.get(p.id),age=date?Math.floor((now.getTime()-Date.parse(date))/86400000):null;if(age!==null&&age<days)return [];const known=batches.filter(b=>b.unitCost!==undefined);return [{product:p,qty,last:date||null,days:age,knownCost:known.reduce((n,b)=>n+b.qty*b.unitCost!,0),missingCostQty:batches.filter(b=>b.unitCost===undefined).reduce((n,b)=>n+b.qty,0)}]});
}
