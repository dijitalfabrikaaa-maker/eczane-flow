/** Validate an explicit restore; acknowledged retries ignore the stale revision. */
export function restoreRequest(v:any,revision:number,applied:string[]){
 if(v.action!=='restore'||typeof v.note!=='string'||!v.note.trim()||v.note.length>200||v.confirm!=='GERİ YÜKLE'||typeof v.commandId!=='string'||!/^[-\w]{8,80}$/.test(v.commandId)||typeof v.id!=='string'||!v.id)throw Error('INVALID');
 if(applied.includes(v.commandId))return 'completed';
 if(v.revision!==revision)throw Error('CONFLICT');
 return 'ready';
}
