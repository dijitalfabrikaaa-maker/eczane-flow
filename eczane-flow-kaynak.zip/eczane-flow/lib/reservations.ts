import type {Inventory,Line} from './inventory.ts';
import {isHeld} from './stock-controls.ts';
export type Reservation={id:string;batchId:string;qty:number;reference:string;expiresAt:string;status:'active'|'cancelled'|'fulfilled';actor:string;date:string;closedAt?:string;closedBy?:string;commandId?:string};
export type ReservationCommand={id:string;revision:number;kind:'reservation-create'|'reservation-cancel';batchId?:string;qty?:number;reference?:string;expiresAt?:string;targetId?:string};
export const activeReservation=(r:Reservation,now=new Date())=>r.status==='active'&&Date.parse(r.expiresAt)>now.getTime();
export const reservedQuantity=(s:Inventory,batchId:string,now=new Date())=>(s.reservations||[]).filter(r=>r.batchId===batchId&&activeReservation(r,now)).reduce((n,r)=>n+r.qty,0);
export const availableQuantity=(s:Inventory,batchId:string,now=new Date())=>Math.max(0,(s.batches.find(b=>b.id===batchId)?.qty||0)-reservedQuantity(s,batchId,now));
export function protectReservations(s:Inventory,batchId:string,remaining:number,now=new Date()){if(reservedQuantity(s,batchId,now)>0&&remaining<reservedQuantity(s,batchId,now))throw Error('RESERVED_STOCK')}
export function fulfilReservation(s:Inventory,id:string,lines:Line[],commandId:string,actor:string,now=new Date()){
 const r=s.reservations?.find(v=>v.id===id),b=s.batches.find(b=>b.id===r?.batchId);
 if(!r||!b||!activeReservation(r,now))throw Error('RESERVATION_EXPIRED');
 const matched=lines.filter(l=>l.productId===b.productId&&l.lot===b.lot);
 if(!matched.length||matched.reduce((n,l)=>n+l.qty,0)!==r.qty)throw Error('RESERVATION_LINES');
 r.status='fulfilled';r.closedAt=now.toISOString();r.closedBy=actor;r.commandId=commandId;
}
export function applyReservation(state:Inventory,c:ReservationCommand,actor:string,now=new Date()):Inventory{
 if(!/^[-\w]{8,80}$/.test(c.id))throw Error('INVALID');if(state.applied.includes(c.id))return state;
 const n=structuredClone(state);n.reservations||=[];
 if(c.kind==='reservation-create'){
 const b=n.batches.find(b=>b.id===c.batchId),expiry=Date.parse(c.expiresAt||'');
 if(!b||!Number.isInteger(c.qty)||c.qty!<1||c.qty!>10000||typeof c.reference!=='string'||!c.reference.trim()||c.reference.length>100||!Number.isFinite(expiry)||expiry<=now.getTime()||expiry>now.getTime()+30*86400000||n.reservations.length>=10000)throw Error('INVALID');
 if(isHeld(n,b.id)||Date.parse(b.expiry+'T00:00:00Z')<=now.getTime())throw Error('HELD');
 if(c.qty!>availableQuantity(n,b.id,now))throw Error('RESERVED_STOCK');
 n.reservations.push({id:c.id,batchId:b.id,qty:c.qty!,reference:c.reference.trim(),expiresAt:new Date(expiry).toISOString(),status:'active',actor,date:now.toISOString()});
 }else if(c.kind==='reservation-cancel'){
 const r=n.reservations.find(r=>r.id===c.targetId);if(!r||r.status!=='active')throw Error('INVALID');
 r.status='cancelled';r.closedAt=now.toISOString();r.closedBy=actor;
 }else throw Error('INVALID');
 n.applied.push(c.id);return n;
}
