export type DraftEnvelope={body:any;version:number;completed?:boolean;completedCommandId?:string};
export function emptyOperationDraft(current:any){return {...current,lines:[],note:'',pending:null,commandId:undefined,supplier:'',reference:'',due:'',doc:null,orderId:'',checkout:{parts:{cash:'',card:'',bank:''},customer:'',tender:''}}}
/** Empty saved drafts are authoritative too; completed commands must never revive. */
export function recoverOperationDraft(remote:DraftEnvelope,local:DraftEnvelope|null,current:any){
 const empty=emptyOperationDraft(current),server=remote.completed?empty:remote.body;
 if(local&&Array.isArray(local.body?.lines)){
  if(remote.completed){if(remote.completedCommandId&&local.body.commandId===remote.completedCommandId)return {body:empty,conflict:null,discardLocal:true};return {body:local.body,conflict:{local:local.body,remote:empty,version:remote.version,completed:true},discardLocal:false};}
  if(local.version!==remote.version)return {body:local.body,conflict:{local:local.body,remote:server,version:remote.version},discardLocal:false};
  return {body:local.body,conflict:null,discardLocal:false};
 }
 return {body:server??current,conflict:null,discardLocal:!!remote.completed};
}
