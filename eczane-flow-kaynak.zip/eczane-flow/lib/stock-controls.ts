import type {Inventory,Line} from './inventory.ts';
export type Hold={actor?:string;releasedBy?:string;batchId:string;status:'quarantine'|'recall';note:string;date:string;releasedAt?:string;releaseNote?:string};
export function isHeld(s:Inventory,batchId:string){return s.holds?.some(h=>h.batchId===batchId&&!h.releasedAt)||false}
export function serialDifference(expected:string[],observed:string[]){return {missing:expected.filter(s=>!observed.includes(s)),extra:observed.filter(s=>!expected.includes(s)),matched:observed.filter(s=>expected.includes(s))}}
export function scanMismatch(s:Inventory,productId:string,code:{lot?:string;serial?:string;expiry?:string}){
 const batches=s.batches.filter(b=>b.productId===productId),bySerial=code.serial?batches.find(b=>b.serials.includes(code.serial!)):undefined,byLot=code.lot?batches.find(b=>b.lot===code.lot):undefined;
 if(bySerial&&code.lot&&bySerial.lot!==code.lot)return {field:'Lot',scanned:code.lot,stored:bySerial.lot};
 const b=bySerial||byLot;if(b&&code.expiry&&b.expiry!==code.expiry)return {field:'Miat',scanned:code.expiry,stored:b.expiry};return null;
}
export function consumeShelf(s:Inventory,batchId:string,line:Line){const rows=(s.placements||[]).filter(p=>p.batchId===batchId),batch=s.batches.find(b=>b.id===batchId)!;
 if(line.shelfId){const row=rows.find(p=>p.shelfId===line.shelfId);if(!row||row.qty<line.qty)throw Error('SHELF_STOCK');row.qty-=line.qty}
 else if(line.qty>batch.qty-rows.reduce((n,p)=>n+p.qty,0))throw Error('SHELF_REQUIRED');
}

/** Capacity left in the chosen physical location after all staged lines. */
export function shelfRemaining(s:Inventory,line:Line,staged:Line[]){
 const b=s.batches.find(b=>b.productId===line.productId&&b.lot===line.lot);if(!b)return 0;
 const rows=(s.placements||[]).filter(p=>p.batchId===b.id),capacity=line.shelfId?rows.find(p=>p.shelfId===line.shelfId)?.qty||0:b.qty-rows.reduce((n,p)=>n+p.qty,0);
 return capacity-staged.filter(l=>l.productId===line.productId&&l.lot===line.lot&&l.shelfId===line.shelfId).reduce((n,l)=>n+l.qty,0);
}
