import {isHeld} from './stock-controls.ts';
import {applyCommand,type Inventory,type Line} from './inventory.ts';
import {business,cashBalance,type BusinessCommand,type Entry,type PaymentMethod} from './business.ts';
export type Payment={method:PaymentMethod;amount:number};
export type TradeLine=Line&{id:string;name:string;total:number;cost?:number;listPrice?:number;discount?:number};
export type Order={expectedAt?:string;id:string;date:string;supplierId:string;reference:string;note:string;status:'open'|'closed';lines:{productId:string;qty:number;received:number;unitCost:number}[]};
export const cents=(n:unknown)=>{if(typeof n!=='number'||!Number.isSafeInteger(n)||n<0||n>100000000)throw Error('AMOUNT');return n};
export function paid(e:Entry){return e.payments?e.payments.reduce((n,p)=>n+p.amount,0):e.method?e.amount:0}
export function invoiceBalance(s:Inventory,e:Entry){
 const entries=business(s).entries;if(e.kind==='sale'){const linked=entries.filter(v=>v.parentId===e.id&&!v.reversedBy);return Math.max(0,e.amount-paid(e)+linked.reduce((n,v)=>n+(v.kind==='sale-return'?v.amount-paid(v):v.kind==='collection'?-paid(v):0),0))}
 // Legacy account-level payments and excess supplier credit cover oldest open invoices.
 const invoices=entries.filter(v=>v.kind==='purchase'&&v.supplierId===e.supplierId&&!v.reversedBy&&!v.reversalOf).sort((a,b)=>a.date.localeCompare(b.date)),balances=new Map(invoices.map(v=>[v.id,v.amount]));let credit=0;
 for(const v of entries.filter(v=>v.supplierId===e.supplierId)){if(v.parentId&&balances.has(v.parentId)&&['payment','purchase-return'].includes(v.kind))balances.set(v.parentId,balances.get(v.parentId)!+v.amount);else if(v.kind==='payment'&&!v.parentId)credit-=v.amount}
 for(const [id,amount] of balances)if(amount<0){credit-=amount;balances.set(id,0)}
 for(const invoice of invoices){const amount=balances.get(invoice.id)!,use=Math.min(amount,Math.max(0,credit));balances.set(invoice.id,amount-use);credit-=use}return balances.get(e.id)||0;
}
export function returnedQty(s:Inventory,entryId:string,lineId:string){return business(s).entries.filter(e=>e.parentId===entryId&&e.kind.endsWith('-return')).flatMap(e=>e.tradeLines||[]).filter(l=>l.id===lineId).reduce((n,l)=>n+l.qty,0)}
function validPayments(value:unknown,max:number):Payment[]{if(!Array.isArray(value)||value.length>3)throw Error('AMOUNT');const seen=new Set<string>();return value.map(p=>{if(!p||!['cash','card','bank'].includes(p.method)||seen.has(p.method))throw Error('INVALID');seen.add(p.method);return {method:p.method,amount:cents(p.amount)}}).filter(p=>p.amount>0).map((p,_,all)=>{if(all.reduce((n,p)=>n+p.amount,0)>max)throw Error('AMOUNT');return p})}
export function enrichTrade(before:Inventory,next:Inventory,c:BusinessCommand){
 const e=next.business!.entries.find(e=>e.id===c.id)!;if(!e)return next;
 e.tradeLines=(c.lines||[]).map((l,i)=>{const p=before.products.find(p=>p.id===l.productId)!;const total=l.qty*(c.kind==='sale'?l.unitPrice!:l.unitCost!);return {...l,id:`${c.id}-line-${i}`,name:p.name,total,listPrice:c.kind==='sale'?p.price:undefined,discount:c.kind==='sale'?Math.max(0,p.price-(l.unitPrice||0))*l.qty:undefined,cost:c.kind==='purchase'?l.unitCost:before.batches.find(b=>b.productId===l.productId&&b.lot===l.lot)?.unitCost}});
 if(c.kind==='sale'&&c.payments!==undefined){e.payments=validPayments(c.payments,e.amount);delete e.method;e.customer=(c.customer||'').trim().slice(0,120);if(paid(e)<e.amount&&!e.customer)throw Error('CUSTOMER')}
 if(c.orderId){const order=next.business!.orders?.find(o=>o.id===c.orderId);if(!order||order.status!=='open'||order.supplierId!==c.supplierId||c.kind!=='purchase')throw Error('ORDER');for(const l of c.lines||[]){const line=order.lines.find(v=>v.productId===l.productId);if(!line||line.received+l.qty>line.qty)throw Error('ORDER');if(l.unitCost!==line.unitCost&&!c.acceptPriceDifference)throw Error('ORDER_PRICE');line.received+=l.qty}if(order.lines.every(l=>l.received===l.qty))order.status='closed';e.orderId=order.id}
 return next;
}
export function applyCommerce(s:Inventory,c:BusinessCommand,now=new Date()):Inventory{
 if(s.applied.includes(c.id))return s;let next=structuredClone(s);next.business=structuredClone(business(next));const b=next.business,date=now.toISOString(),note=(c.note||'').trim();if(!note||note.length>200)throw Error('NOTE');
 if(c.kind==='order-split'){
 if(!Array.isArray(c.groups)||!c.groups.length||c.groups.length>20||c.groups.reduce((n,g)=>n+(g.lines?.length||0),0)>100||new Set(c.groups.map(g=>g.supplierId)).size!==c.groups.length)throw Error('ORDER');
 for(const [i,g] of c.groups.entries()){if(!g.expectedAt)throw Error('ORDER');next=applyCommerce(next,{id:c.id+'-'+i,revision:c.revision,kind:'order',supplierId:g.supplierId,reference:g.reference,expectedAt:g.expectedAt,lines:g.lines,note},now);}
 next.applied.push(c.id);return next;
 }else if(c.kind==='order'){
  if(!next.suppliers?.some(v=>v.id===c.supplierId)||!c.reference?.trim()||c.reference.length>80||!c.lines?.length||c.lines.length>100)throw Error('ORDER');
  if(c.expectedAt&&(!/^\d{4}-\d{2}-\d{2}$/.test(c.expectedAt)||!Number.isFinite(Date.parse(c.expectedAt))||new Date(c.expectedAt).toISOString().slice(0,10)!==c.expectedAt))throw Error('ORDER');
  const seen=new Set<string>();const lines=c.lines.map(l=>{if(!next.products.some(p=>p.id===l.productId)||!Number.isInteger(l.qty)||l.qty<1||l.qty>10000||seen.has(l.productId))throw Error('ORDER');seen.add(l.productId);return {productId:l.productId,qty:l.qty,received:0,unitCost:cents(l.unitCost)}});
  b.orders||=[];if(b.orders.some(o=>o.reference===c.reference&&o.supplierId===c.supplierId))throw Error('DUPLICATE_DOCUMENT');b.orders.push({id:c.id,date,supplierId:c.supplierId!,reference:c.reference,expectedAt:c.expectedAt,note,status:'open',lines});
 }else{
  const original=b.entries.find(e=>e.id===c.targetId&&!e.reversedBy&&!e.reversalOf);if(!original)throw Error('INVALID');
  if(c.kind==='collection'){
   if(original.kind!=='sale')throw Error('INVALID');const amount=cents(c.amount);if(!amount||amount>invoiceBalance(next,original))throw Error('BALANCE');const payments=validPayments([{method:c.method,amount}],amount);b.entries.push({id:c.id,date,kind:'collection',amount,payments,parentId:original.id,note,customer:original.customer});
  }else if(c.kind==='invoice-payment'){
   if(original.kind!=='purchase')throw Error('INVALID');const amount=cents(c.amount);if(!amount||amount>invoiceBalance(next,original))throw Error('BALANCE');const payments=validPayments([{method:c.method,amount}],amount);if(c.method==='cash'&&amount>cashBalance(next))throw Error('CASH');b.entries.push({id:c.id,date,kind:'payment',amount:-amount,method:payments[0].method,parentId:original.id,supplierId:original.supplierId,note});
  }else if(c.kind==='sale-return'||c.kind==='purchase-return'){
   if(original.kind!==(c.kind==='sale-return'?'sale':'purchase')||!original.tradeLines||!c.returns?.length||c.returns.length>100)throw Error('INVALID');
   const seen=new Set<string>();const lines:TradeLine[]=c.returns.map(r=>{const line=original.tradeLines!.find(l=>l.id===r.lineId);if(!line||seen.has(r.lineId)||!Number.isInteger(r.qty)||r.qty<1||line.serial&&r.qty!==1)throw Error('INVALID');seen.add(r.lineId);const prev=returnedQty(next,original.id,line.id);if(r.qty+prev>line.qty)throw Error('RETURN_QTY');return {...line,shelfId:r.shelfId,qty:r.qty,total:Math.round(line.total*(prev+r.qty)/line.qty)-Math.round(line.total*prev/line.qty)}});
   const total=lines.reduce((n,l)=>n+l.total,0),sale=c.kind==='sale-return',balance=invoiceBalance(next,original);let payments:Payment[]=[];
   if(sale){const refund=Math.max(0,total-balance);if(refund){validPayments([{method:c.method,amount:refund}],refund);if(c.method==='cash'&&refund>cashBalance(next))throw Error('CASH');payments=[{method:c.method!,amount:-refund}]}}
   // Supplier credits stay on the supplier account, including fully paid invoices.
   next=applyCommand(next,{id:c.id,revision:c.revision,kind:sale?'receive':'out',note,lines:lines.map(l=>({...l,sale:false,unitCost:sale?l.cost:undefined,unitPrice:undefined,supplierId:undefined}))},now,{allowExpired:!sale,supplierReturn:!sale});
   next.business!.entries.push({id:c.id,date,kind:c.kind,amount:-total,parentId:original.id,supplierId:sale?undefined:original.supplierId,customer:original.customer,tradeLines:lines,payments,note,movementIds:next.movements.filter(m=>m.id.startsWith(c.id+'-')).map(m=>m.id)});return next;
  }else throw Error('INVALID');
 }
 next.applied.push(c.id);return next;
}
export function commerceReport(s:Inventory,from='',to=''){
 const entries=business(s).entries.filter(e=>{const day=new Intl.DateTimeFormat('en-CA',{timeZone:s.country==='AZ'?'Asia/Baku':'Europe/Istanbul',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date(e.date));return (!from||day>=from)&&(!to||day<=to)});
 let revenue=0,cost=0,missing=0,collection=0;for(const e of entries){if(e.kind==='sale'||e.kind==='sale-return'){revenue+=e.amount;const sign=e.amount<0?-1:1;if(e.tradeLines)for(const l of e.tradeLines){if(l.cost===undefined)missing+=l.qty;else cost+=sign*l.qty*l.cost}else missing+=Math.abs(s.movements.filter(m=>e.movementIds?.includes(m.id)).reduce((n,m)=>n+m.qty,0));collection+=paid(e)}else if(e.kind==='collection')collection+=paid(e)}return {entries,revenue,cost,missing,collection,profit:missing?null:revenue-cost};
}

export function isHeldSupplierReturn(s:Inventory,c:BusinessCommand){
 if(c.kind!=='purchase-return')return false;const source=business(s).entries.find(e=>e.id===c.targetId);
 return (c.returns||[]).some(r=>{const l=source?.tradeLines?.find(l=>l.id===r.lineId);return !!l&&s.batches.some(b=>b.productId===l.productId&&b.lot===l.lot&&isHeld(s,b.id))});
}
