import type {Inventory} from './inventory.ts';
/** Read-only structural checks; linear in records and placements. */
export function inventoryHealth(s:Inventory){
 const issues=new Set<string>(),products=Array.isArray(s.products)?s.products:[],lots=Array.isArray(s.batches)?s.batches:[],moves=Array.isArray(s.movements)?s.movements:[];
 if(products!==s.products||lots!==s.batches||moves!==s.movements)issues.add('STRUCTURE');
 const ids=new Set(products.map(p=>p?.id));if(ids.size!==products.length)issues.add('PRODUCT_DUPLICATE');
 const batches=new Map<string,number>(),serials=new Set<string>();
 for(const b of lots){if(!b){issues.add('STRUCTURE');continue}if(batches.has(b.id))issues.add('BATCH_DUPLICATE');batches.set(b.id,b.qty);if(!ids.has(b.productId))issues.add('PRODUCT_MISSING');if(!Number.isSafeInteger(b.qty)||b.qty<0||!Array.isArray(b.serials)||b.serials.length>b.qty)issues.add('QUANTITY');for(const serial of Array.isArray(b.serials)?b.serials:[]){const key=b.productId+'\x1d'+serial;if(serials.has(key))issues.add('SERIAL_DUPLICATE');serials.add(key)}}
 const shelves=new Set((s.shelves||[]).map(v=>v.id)),allocated=new Map<string,number>(),pairs=new Set<string>();
 for(const p of s.placements||[]){if(!batches.has(p.batchId)||!shelves.has(p.shelfId)||!Number.isSafeInteger(p.qty)||p.qty<0)issues.add('PLACEMENT');const pair=p.batchId+'\x1d'+p.shelfId;if(pairs.has(pair))issues.add('PLACEMENT_DUPLICATE');pairs.add(pair);allocated.set(p.batchId,(allocated.get(p.batchId)||0)+p.qty)}
 for(const [id,qty] of allocated)if(qty>(batches.get(id)??0))issues.add('PLACEMENT_EXCESS');
 const reserved=new Map<string,number>(),reservationIds=new Set<string>();
 for(const r of s.reservations||[]){if(!r||!batches.has(r.batchId)||reservationIds.has(r.id)||!Number.isInteger(r.qty)||r.qty<1||!['active','cancelled','fulfilled'].includes(r.status)||!Number.isFinite(Date.parse(r.expiresAt))){issues.add('RESERVATION');continue}reservationIds.add(r.id);if(r.status==='active'&&Date.parse(r.expiresAt)>Date.now())reserved.set(r.batchId,(reserved.get(r.batchId)||0)+r.qty)}
 for(const [id,qty] of reserved)if(qty>(batches.get(id)||0))issues.add('RESERVATION_EXCESS');
 return {products:products.length,batches:lots.length,movements:moves.length,serializedBytes:new TextEncoder().encode(JSON.stringify(s)).byteLength,issues:[...issues]};
}
