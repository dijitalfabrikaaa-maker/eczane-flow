import {dueTasks} from './tasks.ts';
import {quantity,daysLeft,type Inventory,type Product,type Batch} from './inventory.ts';
import {business} from './business.ts';import {invoiceBalance} from './commerce.ts';
export const stockAlertKey=(data:Inventory,p:Product)=>`stock:${p.id}:${quantity(data,p.id)}:${p.min}`;
export const expiryAlertKey=(b:Batch)=>`expiry:${b.id}:${b.expiry}:${daysLeft(b.expiry)<=0?'expired':'soon'}`;
export const notificationPreferences=(s:Inventory)=>Object.values(s.notificationSettings||{})[0]||{stock:true,expiry:true,payments:true};
export function duePayments(s:Inventory,now=new Date()){const day=new Intl.DateTimeFormat('en-CA',{timeZone:s.country==='AZ'?'Asia/Baku':'Europe/Istanbul',year:'numeric',month:'2-digit',day:'2-digit'}).format(now);return business(s).entries.filter(e=>e.kind==='purchase'&&!e.reversedBy&&!e.reversalOf&&e.due&&e.due<=day&&invoiceBalance(s,e)>0)}
export const paymentAlertKey=(s:Inventory,e:{id:string;due?:string})=>`payment:${e.id}:${e.due}:${invoiceBalance(s,business(s).entries.find(v=>v.id===e.id)!)}`;
export function activeAlertKeys(data:Inventory){const p=notificationPreferences(data);return [...dueTasks(data.tasks||[]).map(t=>'task:'+t.id),...(p.stock?data.products.filter(p=>quantity(data,p.id)<p.min).map(p=>stockAlertKey(data,p)):[]),...(p.expiry?data.batches.filter(b=>b.qty>0&&daysLeft(b.expiry)<=90).map(expiryAlertKey):[]),...(p.payments?duePayments(data).map(e=>paymentAlertKey(data,e)):[])]}
