import {env} from 'cloudflare:workers';
export function images(){if(!env.BUCKET)throw Error('UNAVAILABLE');return env.BUCKET}
export function imageKey(owner:string,id:string){if(!/^[a-f0-9-]{36}$/.test(id))throw Error('INVALID');return `product-images/${encodeURIComponent(owner)}/${id}.webp`}
