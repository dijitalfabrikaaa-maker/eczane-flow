import type {Inventory} from './inventory.ts';
export type ShelfJob={id:string;kind:'pick'|'cycle';name:string;due:string;actor:string;date:string;status:'open'|'completed'|'cancelled';lines:{batchId:string;shelfId:string;qty:number;observed?:number;done?:boolean;baseline:string}[];completedAt?:string};
export type ShelfWorkCommand={id:string;revision:number;kind:'shelf-capacity'|'shelf-job'|'shelf-observe'|'shelf-finish'|'shelf-cancel';shelfId?:string;capacity?:number;jobKind?:'pick'|'cycle';name?:string;due?:string;lines?:{batchId:string;shelfId:string;qty:number}[];targetId?:string;line?:number;observed?:number};
export function shelfCapacity(s:Inventory,id:string){const shelf=s.shelves?.find(v=>v.id===id),used=(s.placements||[]).filter(p=>p.shelfId===id).reduce((n,p)=>n+p.qty,0);return {used,capacity:shelf?.capacity??null,free:shelf?.capacity===undefined?null:Math.max(0,shelf.capacity-used),excess:shelf?.capacity===undefined?0:Math.max(0,used-shelf.capacity)}}
export function shelfBaseline(s:Inventory,batchId:string,shelfId:string){const b=s.batches.find(v=>v.id===batchId);return JSON.stringify([b?.qty,b?.serials.length,s.placements?.filter(p=>p.batchId===batchId),s.movements.filter(m=>m.productId===b?.productId&&m.lot===b?.lot).slice(0,1).map(m=>m.id),shelfId])}
export function applyShelfWork(state:Inventory,c:ShelfWorkCommand,actor:string,now=new Date()):Inventory{
 if(!/^[-\w]{8,80}$/.test(c.id))throw Error('INVALID');if(state.applied.includes(c.id))return state;const s=structuredClone(state),date=now.toISOString();s.shelfJobs||=[];
 if(c.kind==='shelf-capacity'){const shelf=s.shelves?.find(v=>v.id===c.shelfId);if(!shelf||!Number.isSafeInteger(c.capacity)||c.capacity!<0||c.capacity!>1000000)throw Error('INVALID');shelf.capacity=c.capacity;
 }else if(c.kind==='shelf-job'){
  if(!['pick','cycle'].includes(c.jobKind||'')||!c.name?.trim()||c.name.length>120||!c.due||!Number.isFinite(Date.parse(c.due))||!c.lines?.length||c.lines.length>100||s.shelfJobs.length>=1000)throw Error('INVALID');
  const seen=new Set<string>(),rows=c.lines.map(l=>{const b=s.batches.find(b=>b.id===l.batchId),shelf=s.shelves?.find(r=>r.id===l.shelfId),p=s.placements?.find(p=>p.batchId===l.batchId&&p.shelfId===l.shelfId),key=l.batchId+':'+l.shelfId;if(!b||!shelf||!p||!Number.isSafeInteger(l.qty)||l.qty<0||c.jobKind==='pick'&&(!l.qty||l.qty>p.qty)||seen.has(key))throw Error('INVALID');seen.add(key);return {...l,qty:c.jobKind==='cycle'?p.qty:l.qty,baseline:shelfBaseline(s,l.batchId,l.shelfId)}});
  rows.sort((a,b)=>(s.shelves!.find(v=>v.id===a.shelfId)!.code).localeCompare(s.shelves!.find(v=>v.id===b.shelfId)!.code,'tr',{numeric:true})||a.batchId.localeCompare(b.batchId));s.shelfJobs.push({id:c.id,kind:c.jobKind!,name:c.name.trim(),due:new Date(c.due).toISOString(),actor,date,status:'open',lines:rows});
 }else{
  const job=s.shelfJobs.find(v=>v.id===c.targetId);if(!job||job.status!=='open')throw Error('INVALID');
  if(c.kind==='shelf-cancel')job.status='cancelled';
  else if(c.kind==='shelf-observe'){if(!Number.isInteger(c.line)||!job.lines[c.line!])throw Error('INVALID');const row=job.lines[c.line!];if(row.baseline!==shelfBaseline(s,row.batchId,row.shelfId))throw Error('CONFLICT');if(job.kind==='pick')row.done=true;else{if(!Number.isSafeInteger(c.observed)||c.observed!<0||c.observed!>1000000)throw Error('INVALID');row.observed=c.observed}}
  else if(c.kind==='shelf-finish'){if(job.lines.some(l=>l.baseline!==shelfBaseline(s,l.batchId,l.shelfId)))throw Error('CONFLICT');if(job.lines.some(l=>job.kind==='pick'?!l.done:l.observed===undefined))throw Error('INVALID');job.status='completed';job.completedAt=date}
  else throw Error('INVALID');
 }
 s.applied.push(c.id);return s;
}
