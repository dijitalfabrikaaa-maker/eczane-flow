export type StockImportRow={code:string;name:string;detail:string;category:string;location:string;lot:string;expiry:string;qty:number;min:number};
export const importColumns=['code','name','detail','category','location','lot','expiry','qty','min'] as const;
export function parseCsv(text:string):string[][]{
 if(text.length>200000)throw Error('SIZE');
 text=text.replace(/^\uFEFF/,'');const head=text.split(/\r?\n/)[0];const sep=head.includes(';')?';':',';
 const rows:string[][]=[];let row:string[]=[],cell='',quoted=false;
 for(let i=0;i<text.length;i++){const c=text[i];if(c==='"'){if(quoted&&text[i+1]==='"'){cell+='"';i++}else if(quoted)quoted=false;else if(cell==='')quoted=true;else throw Error('CSV')}else if(c===sep&&!quoted){row.push(cell);cell=''}else if((c==='\n'||c==='\r')&&!quoted){if(c==='\r'&&text[i+1]==='\n')i++;row.push(cell);if(row.some(v=>v.trim()))rows.push(row);row=[];cell=''}else cell+=c}
 if(quoted)throw Error('CSV');row.push(cell);if(row.some(v=>v.trim()))rows.push(row);if(rows.length>101)throw Error('ROWS');return rows;
}
export function validImportRow(v:StockImportRow):boolean{
 if(!v)return false;
 for(const k of ['code','name','detail','category','location','lot','expiry'] as const)if(typeof v[k]!=='string'||v[k].length>120)return false;
 if(!/^(?:\d{8,14}|DEMO\d{3})$/.test(v.code)||!v.name.trim()||!v.location.trim()||!v.lot.trim()||v.lot.length>40)return false;
 if(!/^\d{4}-\d{2}-\d{2}$/.test(v.expiry)||!Number.isFinite(new Date(v.expiry+'T00:00:00Z').getTime())||new Date(v.expiry+'T00:00:00Z').toISOString().slice(0,10)!==v.expiry)return false;
 return Number.isInteger(v.qty)&&v.qty>0&&v.qty<=10000&&Number.isInteger(v.min)&&v.min>=0&&v.min<=10000;
}
