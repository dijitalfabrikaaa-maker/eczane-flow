import {protectReservations,fulfilReservation,type Reservation} from './reservations.ts';
import {MAX_OPERATION_LINES} from './operation-limits.ts';
import type {Task} from './tasks.ts';
import {isHeld,consumeShelf,type Hold} from './stock-controls.ts';
import {digitalLinkElements} from './gtin.ts';
import type {Approval} from './approvals.ts';
import {reconcilePlacements,type Network} from './network.ts';
import type {Business} from './business.ts';
import {validRoleTemplate,type RoleTemplate} from './role-templates.ts';
import {validImportRow,type StockImportRow} from './stock-import.ts';
export type Product = { cost?:number; photo?:string; id: string; name: string; detail: string; category: string; code: string; min: number; price: number; location: string };
export type Batch = { unitCost?:number; id: string; productId: string; lot: string; expiry: string; qty: number; serials: string[] };
export type Movement = { reason?:string; shelfId?:string; countBefore?:string[]; countAfter?:string[]; id: string; date: string; kind: 'receive'|'count'|'out'; productId: string; qty: number; lot: string; note: string; supplierName?:string; unitCost?:number; unitPrice?:number; sale?:boolean; serial?:string };
export type Supplier = { id: string; name: string; contact: string; phone: string; email: string; city: string };
export type WorkspaceProfile = { name: string; pharmacy: string; phone: string };
export type OperationDraft = { id:string; kind:"receive"|"count"|"out"; lines:Line[]; note:string; updatedAt?:string };
export type Shelf = {capacity?:number;id:string;code:string;name:string;zone:string};
export const shelfKey=(code:string)=>code.trim().toLocaleUpperCase('tr-TR');
export function shelfQR(id:string){return `ECZANE:SHELF:${id}`}
export function parseShelfQR(raw:string){const m=/^ECZANE:SHELF:([-\w]{8,80})$/.exec(raw.trim());return m?.[1]||null}
export type Inventory = {priceSchedules?:import('./pricing.ts').PriceSchedule[];marginPolicy?:{enabled:boolean;threshold:number};purchaseBudgets?:Record<string,number>;reservations?:Reservation[];shelfJobs?:import('./shelf-work.ts').ShelfJob[];operations?:import('./operations.ts').Operations;tasks?:Task[]; holds?:Hold[]; importHashes?:string[];notificationReads?:Record<string,string[]>;notificationSettings?:Record<string,{stock:boolean;expiry:boolean;payments:boolean}>; approvals?:Approval[];approvalPolicy?:{stock:boolean;finance:boolean}; network?:Network; placements?:{batchId:string;shelfId:string;qty:number}[]; business?:Business; shelves?:Shelf[]; readAlerts?:string[]; roleTemplates?:RoleTemplate[]; draft?:OperationDraft; profile?: WorkspaceProfile; suppliers?: Supplier[]; products: Product[]; batches: Batch[]; movements: Movement[]; applied: string[]; country: 'TR'|'AZ' };
export type Line = { countSerials?:string[]; shelfId?:string; reason?:'damage'|'loss'|'sample'|'other'; productId: string; qty: number; lot: string; expiry: string; serial?: string; supplierId?:string; unitCost?:number; unitPrice?:number; sale?:boolean };
export type Command = {marginAcknowledged?:boolean;reservationId?:string; importHash?:string; paymentMethod?:'cash'|'card'|'bank'; id: string; revision: number; hold?:{batchId:string;status:'quarantine'|'recall'|'release';note:string}; kind: 'hold'|'shelf'|'shelf-assign'|'receive'|'count'|'out'|'country'|'supplier'|'profile'|'import'|'product'|'draft'|'product-settings'|'product-photo'|'role-template'|'read-alerts'; shelf?:Shelf; assignment?:{shelfId:string;productIds:string[]}; alertKeys?:string[]; roleTemplate?:RoleTemplate; photo?:{productId:string;value:string}; draft?:OperationDraft; draftId?:string; settings?:{productId:string;min:number;location:string;cost?:number;price?:number}; product?:Product; rows?:StockImportRow[]; profile?: WorkspaceProfile; supplier?: Supplier; lines?: Line[]; note?: string; country?: 'TR'|'AZ' };
export function initialInventory(now = new Date()): Inventory {
 const rows = [
  ['Parasetamol','500 mg · 20 tablet','İlaç',24,28,68,'A-01',250],
  ['D Vitamini','1.000 IU · 60 kapsül','Takviye',12,8,245,'B-02',42],
  ['C Vitamini','1.000 mg · 20 efervesan','Takviye',15,36,189,'B-01',180],
  ['İbuprofen','200 mg · 20 tablet','İlaç',20,14,92,'A-02',65],
  ['Serum Fizyolojik','100 ml · izotonik','Medikal',10,44,48,'C-01',300],
  ['Güneş Koruyucu','SPF 50+ · 50 ml','Dermokozmetik',8,19,620,'D-01',360],
  ['Magnezyum','200 mg · 30 tablet','Takviye',12,6,310,'B-03',150],
  ['Antiseptik Solüsyon','100 ml','Medikal',10,32,85,'C-02',90],
  ['Nemlendirici Krem','Hassas cilt · 50 ml','Dermokozmetik',6,17,385,'D-02',230],
  ['Çinko','15 mg · 30 tablet','Takviye',10,23,165,'B-04',22],
  ['Steril Gaz Kompres','10 × 10 cm · 10 adet','Medikal',15,52,42,'C-03',420],
  ['Omega 3','1.000 mg · 60 kapsül','Takviye',8,4,425,'B-05',-7],
 ] as const;
 const date=(days:number)=>new Date(now.getTime()+days*86400000).toISOString().slice(0,10);
 const products: Product[]=rows.map((r,i)=>({id:`p${i+1}`,name:r[0],detail:r[1],category:r[2],min:r[3],price:r[5]*100,location:r[6],code:`DEMO${String(i+1).padStart(3,'0')}`}));
 return {products,batches:rows.map((r,i)=>({id:`b${i+1}`,productId:`p${i+1}`,lot:`LOT26-${String(i+1).padStart(3,'0')}`,expiry:date(r[7]),qty:r[4],serials:[]})),movements:[],applied:[],country:'TR'};
}
export function daysLeft(expiry:string, now=new Date()) {return Math.ceil((new Date(expiry+'T00:00:00Z').getTime()-Date.UTC(now.getUTCFullYear(),now.getUTCMonth(),now.getUTCDate()))/86400000)}
export function quantity(s:Inventory,id:string) {return s.batches.filter(b=>b.productId===id).reduce((a,b)=>a+b.qty,0)}
/** Known reader transport markers only; never guess missing GS1 separators. */
export function normalizeScanInput(input:string){if(typeof input!=='string'||input.length>1000)throw Error('CODE');return input.trim().replace(/^\](?:d2|C1|Q3)/,'').replace(/<GS>|\{GS\}/g,'\x1d')}
export function parseCode(input:string): {code:string;serial?:string;lot?:string;expiry?:string} {
 let value=normalizeScanInput(input);
 value=digitalLinkElements(value)??value;
 if(!value || value.length>300) throw new Error('CODE');
 if(/^DEMO\d{3,8}$/i.test(value)) return {code:value.toUpperCase()};
 if(/^\d{8,14}$/.test(value)) return {code:value};
 const fields:Record<string,string>={};
 if(value.startsWith('(')) {
  const parts=[...value.matchAll(/\((01|21|10|17)\)([^()]*)/g)];
  if(parts.map(p=>p[0]).join('')!==value) throw new Error('CODE');
  for(const p of parts) {if(Object.hasOwn(fields,p[1])) throw new Error('CODE');fields[p[1]]=p[2]}
 } else {
  while(value.length) {
   value=value.replace(/^\x1d/,''); if(!value) break;
   const ai=value.slice(0,2);value=value.slice(2);
   if(ai==='01'||ai==='17'){const n=ai==='01'?14:6; if(value.length<n||fields[ai]) throw new Error('CODE');fields[ai]=value.slice(0,n);value=value.slice(n)}
   else if(ai==='10'||ai==='21'){const idx=value.indexOf('\x1d');const n=idx<0?value.length:idx;if(!n||Object.hasOwn(fields,ai)) throw new Error('CODE');fields[ai]=value.slice(0,n);value=value.slice(n)}
   else throw new Error('CODE');
  }
 }
 if(!/^\d{14}$/.test(fields['01']||'')) throw new Error('CODE');
 for(const key of ['10','21']) if(fields[key]!==undefined && (!fields[key]||fields[key].length>20 || /[\x00-\x1f]/.test(fields[key]))) throw new Error('CODE');
 let expiry:string|undefined;
 if(fields['17']) {const d=fields['17'];if(!/^\d{6}$/.test(d)) throw new Error('CODE');const year=2000+Number(d.slice(0,2)),month=Number(d.slice(2,4)),day=Number(d.slice(4));if(month<1||month>12) throw new Error('CODE');const dt=new Date(Date.UTC(year,month-1,day===0?new Date(Date.UTC(year,month,0)).getUTCDate():day));if(dt.getUTCMonth()!==month-1)throw new Error('CODE');expiry=dt.toISOString().slice(0,10)}
 return {code:fields['01'],serial:fields['21'],lot:fields['10'],expiry};
}
export function applyCommand(state:Inventory, command:Command, now=new Date(), options:{allowExpired?:boolean;actor?:string;supplierReturn?:boolean}={}):Inventory {
 if(!command || typeof command.id!=='string'||!/^[-\w]{8,80}$/.test(command.id))throw new Error('INVALID');
 if(state.applied.includes(command.id)) return state;
 const next=structuredClone(state);
 if(command.reservationId){if(command.kind!=='out'||!Array.isArray(command.lines))throw Error('INVALID');fulfilReservation(next,command.reservationId,command.lines,command.id,options.actor||'',now);}
 if(command.kind==='hold'){const h=command.hold;if(!h||!next.batches.some(b=>b.id===h.batchId)||!['quarantine','recall','release'].includes(h.status)||typeof h.note!=='string'||h.note.trim().length<3||h.note.length>200)throw Error('INVALID');next.holds||=[];const active=next.holds.find(v=>v.batchId===h.batchId&&!v.releasedAt);if(h.status==='release'){if(!active)throw Error('INVALID');active.releasedAt=now.toISOString();active.releaseNote=h.note.trim();active.releasedBy=options.actor}else{if(active)throw Error('DUPLICATE');next.holds.push({batchId:h.batchId,status:h.status,note:h.note.trim(),date:now.toISOString(),actor:options.actor})}}else if(command.kind==='shelf'){
  const v=command.shelf;
  if(!v||typeof v.id!=='string'||!/^[-\w]{8,80}$/.test(v.id))throw Error('INVALID');
  for(const key of ['code','name','zone'] as const)if(typeof v[key]!=='string'||v[key].length>(key==='code'?24:80)||/[\x00-\x1f]/.test(v[key]))throw Error('INVALID');
  if(!v.code.trim()||!v.name.trim())throw Error('INVALID');
  const rows=next.shelves||[],old=rows.find(r=>r.id===v.id),code=shelfKey(v.code);
  if(rows.some(r=>r.id!==v.id&&shelfKey(r.code)===code))throw Error('DUPLICATE');
  if(rows.length>=500&&!old)throw Error('INVALID');
  if(old&&shelfKey(old.code)!==code&&next.products.some(p=>shelfKey(p.location)===code))throw Error('DUPLICATE');
  const shelf={capacity:old?.capacity,id:v.id,code,name:v.name.trim(),zone:v.zone.trim()};
  next.shelves=old?rows.map(r=>r.id===v.id?shelf:r):[...rows,shelf];
  for(const p of next.products)if(shelfKey(p.location)===shelfKey(old?.code||code))p.location=code;
 } else if(command.kind==='shelf-assign'){
  const v=command.assignment,shelf=next.shelves?.find(r=>r.id===v?.shelfId);
  if(!v||!shelf||!Array.isArray(v.productIds)||!v.productIds.length||v.productIds.length>500||new Set(v.productIds).size!==v.productIds.length||v.productIds.some(id=>!next.products.some(p=>p.id===id)))throw Error('INVALID');
  for(const p of next.products)if(v.productIds.includes(p.id))p.location=shelf.code;
 } else if(command.kind==='read-alerts'){
  if(!Array.isArray(command.alertKeys)||command.alertKeys.length>2000||command.alertKeys.some(k=>typeof k!=='string'||k.length>250))throw Error('INVALID');
  next.readAlerts=[...new Set([...(next.readAlerts||[]),...command.alertKeys])].slice(-5000);
 } else if(command.kind==='role-template'){
  const r=command.roleTemplate;if(!validRoleTemplate(r))throw new Error('INVALID');
  const rows=next.roleTemplates||[];if(rows.some(v=>v.id!==r.id&&v.name.trim().toLocaleLowerCase()===r.name.trim().toLocaleLowerCase())||(rows.length>=30&&!rows.some(v=>v.id===r.id)))throw new Error('INVALID');
  const role={id:r.id,name:r.name.trim(),description:r.description.trim(),permissions:[...r.permissions]};
  next.roleTemplates=rows.some(v=>v.id===r.id)?rows.map(v=>v.id===r.id?role:v):[...rows,role];
 } else if(command.kind==='draft') {
  const d=command.draft;
  if(!d||typeof d.id!=='string'||!/^[-\w]{8,80}$/.test(d.id)||!['receive','count','out'].includes(d.kind)||typeof d.note!=='string'||d.note.length>200||!Array.isArray(d.lines)||!d.lines.length||d.lines.length>MAX_OPERATION_LINES)throw new Error('INVALID');
  if(next.draft&&next.draft.id!==d.id)throw new Error('DRAFT_EXISTS');
  for(const l of d.lines)if(!l||!next.products.some(p=>p.id===l.productId)||!Number.isInteger(l.qty)||l.qty<0||l.qty>10000||typeof l.lot!=='string'||l.lot.length>40||typeof l.expiry!=='string'||l.expiry.length>10||(l.serial!==undefined&&(typeof l.serial!=='string'||l.serial.length>20)))throw new Error('INVALID');
  next.draft={id:d.id,kind:d.kind,note:d.note,lines:d.lines.map(l=>({productId:l.productId,qty:l.qty,lot:l.lot,expiry:l.expiry,...(l.serial?{serial:l.serial}:{}),supplierId:l.supplierId,unitCost:l.unitCost,unitPrice:l.unitPrice,sale:l.sale})),updatedAt:now.toISOString()};
 } else if(command.kind==='product-photo') {
  const v=command.photo,p=next.products.find(p=>p.id===v?.productId);
  if(!v||!p||typeof v.value!=='string'||v.value.length>100000||(v.value!==''&&!/^\/api\/product-images\/[a-f0-9-]{36}$/.test(v.value)&&!/^data:image\/webp;base64,UklGR[A-Za-z0-9+/]+=*$/.test(v.value)))throw new Error('INVALID');
  if(v.value.startsWith('data:')&&next.products.reduce((n,q)=>n+(q.id===p.id?v.value.length:(q.photo?.length||0)),0)>1500000)throw new Error('PHOTO_LIMIT');
  p.photo=v.value;
 } else if(command.kind==='product-settings') {
  const v=command.settings,p=next.products.find(p=>p.id===v?.productId);
  if(!v||!p||!Number.isInteger(v.min)||v.min<0||v.min>10000||typeof v.location!=='string'||!v.location.trim()||v.location.length>120)throw new Error('INVALID');
  for(const key of ['cost','price'] as const){if(v[key]!==undefined){if(!Number.isSafeInteger(v[key])||v[key]!<0||v[key]!>100000000)throw Error('INVALID');p[key]=v[key]}}
  p.min=v.min;p.location=v.location.trim();
 } else if(command.kind==='product') {
  const v=command.product;
  if(!v||typeof v.id!=='string'||!/^[-\w]{8,80}$/.test(v.id)||typeof v.code!=='string'||!/^\d{8,14}$/.test(v.code))throw new Error('INVALID');
  for(const key of ['name','detail','category','location'] as const)if(typeof v[key]!=='string'||v[key].length>120)throw new Error('INVALID');
  if(!v.name.trim()||!v.location.trim()||!Number.isInteger(v.min)||v.min<0||v.min>10000||!Number.isInteger(v.price)||v.price<0)throw new Error('INVALID');
  if(next.products.some(p=>p.code===v.code||p.id===v.id))throw new Error('DUPLICATE');
  next.products.push({id:v.id,code:v.code,name:v.name.trim(),detail:v.detail.trim(),category:v.category.trim(),location:v.location.trim(),min:v.min,price:v.price});
 } else if(command.kind==='import') {
  if(command.importHash){if(next.importHashes?.includes(command.importHash))throw Error('DUPLICATE_IMPORT');next.importHashes=[...(next.importHashes||[]),command.importHash]}
  if(command.note!==undefined&&(typeof command.note!=='string'||command.note.length>200))throw new Error('INVALID');
  if(!Array.isArray(command.rows)||!command.rows.length||command.rows.length>100||!command.rows.every(validImportRow))throw new Error('INVALID');
  const seen=new Set<string>();
  for(const [i,row] of command.rows.entries()){
   const key=row.code+'|'+row.lot;if(seen.has(key))throw new Error('DUPLICATE');seen.add(key);
   let product=next.products.find(p=>p.code===row.code);
   if(!product){product={id:`p-${command.id}-${i}`,code:row.code,name:row.name.trim(),detail:row.detail.trim(),category:row.category.trim()||'İlaç',location:row.location.trim(),min:row.min,price:0};next.products.push(product)}
   let batch=next.batches.find(b=>b.productId===product!.id&&b.lot===row.lot);
   if(batch&&(batch.expiry!==row.expiry||batch.serials.length))throw new Error('BATCH');
   if(!batch){batch={id:`b-${command.id}-${i}`,productId:product.id,lot:row.lot,expiry:row.expiry,qty:0,serials:[]};next.batches.push(batch)}
   batch.qty+=row.qty;
   next.movements.unshift({id:`m-${command.id}-${i}`,date:now.toISOString(),kind:'receive',productId:product.id,qty:row.qty,lot:row.lot,note:'CSV · '+(command.note||'Stok aktarımı').slice(0,160)});
  }
 } else if(command.kind==='profile') {
  const v=command.profile;
  if(!v) throw new Error('INVALID');
  for(const key of ['name','pharmacy','phone'] as const) if(typeof v[key]!=='string'||v[key].length>120) throw new Error('INVALID');
  if(!v.name.trim()||!v.pharmacy.trim()) throw new Error('INVALID');
  next.profile={name:v.name.trim(),pharmacy:v.pharmacy.trim(),phone:v.phone.trim()};
 } else if(command.kind==='supplier') {
  const v=command.supplier;
  if(!v || typeof v.id!=='string' || !/^[-\w]{8,80}$/.test(v.id)) throw new Error('INVALID');
  for(const key of ['name','contact','phone','email','city'] as const) if(typeof v[key]!=='string'||v[key].length>120) throw new Error('INVALID');
  if(!v.name.trim() || (v.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v.email))) throw new Error('INVALID');
  const supplier:Supplier={id:v.id,name:v.name.trim(),contact:v.contact.trim(),phone:v.phone.trim(),email:v.email.trim(),city:v.city.trim()};
  const rows=next.suppliers||[];
  next.suppliers=rows.some(x=>x.id===v.id)?rows.map(x=>x.id===v.id?supplier:x):[...rows,supplier];
 } else if(command.kind==='country') {
  if(!['TR','AZ'].includes(command.country||'') || state.movements.length) throw new Error('COUNTRY_LOCKED');
  next.country=command.country!;
 } else {
  if(!['receive','count','out'].includes(command.kind)||!Array.isArray(command.lines)||!command.lines.length||command.lines.length>MAX_OPERATION_LINES)throw new Error('INVALID');
  if(!command.note?.trim()||command.note.length>200)throw new Error('NOTE');
  const counted=new Set<string>();
  for(const line of command.lines) {
   const product=next.products.find(p=>p.id===line.productId);
   if(!product||!Number.isInteger(line.qty)||line.qty<0||line.qty>10000||(command.kind!=='count'&&!line.qty))throw new Error('INVALID');
   if(typeof line.lot!=='string'||!line.lot.trim()||line.lot.length>40||!/^\d{4}-\d{2}-\d{2}$/.test(line.expiry)||!Number.isFinite(new Date(line.expiry+'T00:00:00Z').getTime())||new Date(line.expiry+'T00:00:00Z').toISOString().slice(0,10)!==line.expiry)throw new Error('BATCH');
   if(line.serial && (line.serial.length>20||line.qty!==1))throw new Error('SERIAL');
   for(const value of [line.unitCost,line.unitPrice])if(value!==undefined&&(!Number.isSafeInteger(value)||value<0||value>100000000))throw Error('INVALID');
   if(line.sale!==undefined&&typeof line.sale!=='boolean')throw Error('INVALID');
   const supplier=line.supplierId?next.suppliers?.find(s=>s.id===line.supplierId):undefined;
   if(line.supplierId&&!supplier)throw Error('INVALID');
   if(line.sale&&(command.kind!=='out'||line.unitPrice===undefined))throw Error('INVALID');
   let batch=next.batches.find(b=>b.productId===line.productId&&b.lot===line.lot);
   if(batch&&batch.expiry!==line.expiry)throw new Error('BATCH');
   if(command.kind==='receive') {
    if(line.serial && next.batches.some(b=>b.productId===line.productId&&b.serials.includes(line.serial!)))throw new Error('DUPLICATE');
    if(!batch){batch={id:`b-${command.id}-${next.batches.length}`,productId:line.productId,lot:line.lot,expiry:line.expiry,qty:0,serials:[]};next.batches.push(batch)}
    if(line.unitCost!==undefined){batch.unitCost=batch.qty===0?line.unitCost:batch.unitCost===undefined?undefined:Math.round((batch.qty*batch.unitCost+line.qty*line.unitCost)/(batch.qty+line.qty))}else batch.unitCost=undefined;
    batch.qty+=line.qty;if(line.serial)batch.serials.push(line.serial);
   } else if(!batch) throw new Error('BATCH');
   let delta=line.qty;
   if(command.kind==='out') {
    if(line.reason&&!['damage','loss','sample','other'].includes(line.reason))throw Error('INVALID');if(line.sale&&line.reason)throw Error('INVALID');
    if(isHeld(next,batch!.id)&&!(options.supplierReturn&&!line.sale)&&!['damage','loss'].includes(line.reason||''))throw Error('HELD');
    protectReservations(next,batch!.id,batch!.qty-line.qty,now);
    if(batch!.qty<line.qty)throw Error('STOCK');
    consumeShelf(next,batch!.id,line);
    if(daysLeft(line.expiry,now)<=0&&!options.allowExpired&&!['damage','loss'].includes(line.reason||''))throw new Error('EXPIRED');
    if(batch!.qty<line.qty)throw Error('STOCK');
    if(line.serial){if(!batch!.serials.includes(line.serial))throw Error('SERIAL');batch!.serials=batch!.serials.filter(s=>s!==line.serial)}else if(line.qty>batch!.qty-batch!.serials.length)throw Error('SERIAL_REVIEW');
    if(batch!.qty<line.qty)throw new Error('STOCK');batch!.qty-=line.qty;delta=-line.qty;
   }
   if(command.kind==='count') {
    if(counted.has(batch!.id))throw new Error('DUPLICATE');counted.add(batch!.id);
    if(line.countSerials!==undefined){if(!Array.isArray(line.countSerials)||line.countSerials.length>10000||new Set(line.countSerials).size!==line.countSerials.length||line.countSerials.some(v=>typeof v!=='string'||!v||v.length>20||/[\x00-\x1f]/.test(v))||line.qty<line.countSerials.length)throw Error('SERIAL');if(line.countSerials.some(v=>next.batches.some(b=>b.id!==batch!.id&&b.productId===batch!.productId&&b.serials.includes(v))))throw Error('DUPLICATE');}else if(batch!.serials.length)throw new Error('SERIAL_REVIEW');
    protectReservations(next,batch!.id,line.qty,now);delta=line.qty-batch!.qty;batch!.qty=line.qty;
   }
   if(command.kind==='receive'&&line.unitCost!==undefined)product.cost=line.unitCost;
   next.movements.unshift({id:`${command.id}-${next.movements.length}`,date:now.toISOString(),kind:command.kind,productId:line.productId,qty:delta,lot:line.lot,note:command.note.trim(),...(line.reason?{reason:line.reason}:{}),...(line.shelfId?{shelfId:line.shelfId}:{}),...(line.countSerials?{countBefore:[...batch!.serials],countAfter:[...line.countSerials]}:{}),...(supplier?{supplierName:supplier.name}:{}),...(line.unitCost!==undefined?{unitCost:line.unitCost}:product.cost!==undefined?{unitCost:product.cost}:{}),...(line.sale?{sale:true,unitPrice:line.unitPrice}:{}),...(line.serial?{serial:line.serial}:{})});
   if(command.kind==='count'&&line.countSerials)batch!.serials=[...line.countSerials];
  }
 }
 if(['receive','count','out'].includes(command.kind)&&command.draftId&&command.draftId===next.draft?.id)delete next.draft;
 for(const p of next.products){const shelf=next.shelves?.find(r=>shelfKey(r.code)===shelfKey(p.location));if(shelf)p.location=shelf.code;}
 reconcilePlacements(next);
 next.applied.push(command.id);
 return next;
}
