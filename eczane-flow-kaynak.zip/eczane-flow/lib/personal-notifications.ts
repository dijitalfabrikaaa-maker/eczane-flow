import type {Inventory} from './inventory.ts';
/** Return only the current viewer's acknowledgement and task scope. */
export function personalNotifications(state:Inventory,user:string,owner:boolean){
 return {
  tasks:state.tasks?.filter(t=>owner||t.assignee===user||t.createdBy===user),
  readAlerts:[...(state.notificationReads?.[user]||[])],
  notificationSettings:state.notificationSettings?.[user]?{[user]:{...state.notificationSettings[user]}}:{},
 };
}
