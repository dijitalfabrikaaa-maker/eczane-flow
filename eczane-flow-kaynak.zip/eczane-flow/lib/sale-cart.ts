import {activeReservation,availableQuantity} from './reservations.ts';
import {requireOperationCapacity} from './operation-limits.ts';
import {isHeld,shelfRemaining} from './stock-controls.ts';
import {applyCommand,daysLeft,parseCode,type Inventory,type Line,type Batch} from './inventory.ts';

/** Quantities in a cart are not reservations. The server rechecks them at commit. */
export function saleBatches(state:Inventory,productId:string,now=new Date()):Batch[]{
 return state.batches.filter(b=>b.productId===productId&&!isHeld(state,b.id)&&b.qty>0&&daysLeft(b.expiry,now)>0).sort((a,b)=>a.expiry.localeCompare(b.expiry)||a.lot.localeCompare(b.lot));
}
export function untrackedAvailable(batch:Batch,lines:Line[]){
 return batch.qty-batch.serials.length-lines.filter(l=>l.productId===batch.productId&&l.lot===batch.lot&&!l.serial).reduce((n,l)=>n+l.qty,0);
}
export function checkSaleCart(state:Inventory,lines:Line[],now=new Date(),reservationId?:string):string|null{
 if(!lines.length)return 'EMPTY';
 if(lines.some(l=>!Number.isSafeInteger(l.unitPrice)||(l.unitPrice??-1)<0))return 'AMOUNT';
 try{applyCommand(state,{id:'validate-sale-'+now.getTime(),revision:0,kind:'out',reservationId,note:'Sale validation',lines:lines.map(l=>({...l,sale:true}))},now);return null}catch(e){return e instanceof Error?e.message:'INVALID'}
}
export function addSaleLine(state:Inventory,lines:Line[],raw:string,now=new Date(),reservationId?:string):Line[]{
 const selected=state.reservations?.find(r=>r.id===reservationId);
 if(reservationId){if(!selected||!activeReservation(selected,now))throw Error('RESERVATION_EXPIRED');state=structuredClone(state);state.reservations!.find(r=>r.id===reservationId)!.status='fulfilled';}

 const parsed=parseCode(raw),product=state.products.find(p=>p.code===parsed.code||p.code.padStart(14,'0')===parsed.code.padStart(14,'0'));
 if(!product)throw Error('UNKNOWN_PRODUCT');
 if(parsed.serial&&lines.some(l=>l.productId===product.id&&l.serial===parsed.serial))throw Error('DUPLICATE');
 const eligible=saleBatches(state,product.id,now).filter(b=>(!parsed.lot||b.lot===parsed.lot)&&(!parsed.expiry||b.expiry===parsed.expiry));
 eligible.sort((a,b)=>Number(b.id===selected?.batchId)-Number(a.id===selected?.batchId));
 const batch=eligible.find(b=>availableQuantity(state,b.id,now)>lines.filter(l=>l.productId===b.productId&&l.lot===b.lot).reduce((n,l)=>n+l.qty,0)&&(parsed.serial?b.serials.includes(parsed.serial):untrackedAvailable(b,lines)>0));
 if(!batch)throw Error(parsed.serial?'SERIAL':eligible.some(b=>b.serials.length)?'SERIAL_REVIEW':'STOCK');
 const next=structuredClone(lines),existing=next.find(l=>l.productId===product.id&&l.lot===batch.lot&&!l.serial&&!parsed.serial&&l.unitPrice===product.price&&(!l.shelfId||shelfRemaining(state,l,next)>0));
 if(existing)existing.qty++;else next.push({productId:product.id,qty:1,lot:batch.lot,expiry:batch.expiry,serial:parsed.serial,unitPrice:product.price});
 requireOperationCapacity(next);
 const error=checkSaleCart(state,next,now);if(error&&error!=='SHELF_REQUIRED')throw Error(error);return next;
}
