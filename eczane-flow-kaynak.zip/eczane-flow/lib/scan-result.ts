import {normalizeScanInput,parseCode,parseShelfQR} from './inventory.ts';
export type ScanResult={raw:string;kind:'product';code:string;serial?:string;lot?:string;expiry?:string}|{raw:string;kind:'shelf';shelfId:string};
export function inspectScan(raw:string):ScanResult{const value=normalizeScanInput(raw),shelfId=parseShelfQR(value);if(shelfId)return {raw:value,kind:'shelf',shelfId};if(/^WIFI:|^BEGIN:VCARD|^mailto:/i.test(value))throw Error('UNRELATED_QR');return {raw:value,kind:'product',...parseCode(value)}}
